		package com.cg.appl.junit;
		
		import static org.junit.Assert.assertNotNull;
		
		import org.junit.After;
		import org.junit.Before;
		import org.junit.Test;
		
		import com.cg.appl.daos.HotelDaoImpl;
		import com.cg.appl.entities.BookingDetails;
		import com.cg.appl.entities.Hotel;
		import com.cg.appl.entities.RoomDetails;
		import com.cg.appl.entities.Users;
		import com.cg.appl.exception.BookingException;
		
		public class TestHotelDaoInsert {
		
			HotelDaoImpl h;
			Hotel hotelBean;
			BookingDetails book;
			RoomDetails room;
			Users user;
		
			@Before
			public void setUp() throws Exception {
				h = new HotelDaoImpl();
				hotelBean = new Hotel();
				user = new Users();
			}
		
			@After
			public void tearDown() throws Exception {
				h = null;
				hotelBean = null;
				book = null;
				user = null;
				room = null;
		
			}
		
			@Test
			public void testaddHotel() throws BookingException {
		
				try {
					assertNotNull(h.AddHotel(hotelBean));
				} catch (Exception e) {
					// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		@Test
		public void testaddbook() throws BookingException {
		
			try {
				assertNotNull(h.addbook(book));
				// TODO Auto-generated catch block
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		@Test
		public void testaddRoom() throws BookingException {
		
			try {
				assertNotNull(h.addRoom(room));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		@Test
		public void testaddUser() throws BookingException {
		
			try {
				assertNotNull(h.addUser(user));
			} catch (Exception e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
			}
		
		}
