package com.cg.appl.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.appl.exception.BookingException;
import com.cg.appl.services.HotelServicesImpl;
import com.cg.appl.services.IHotelServices;

public class TestLogin {

	IHotelServices service;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		service=new HotelServicesImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testisUserAuthenticated() throws BookingException {
		System.out.println("Scott Password");
		System.out.println(service.getUserDetails("Scott"));
		assertNotNull(service.getUserDetails("Scott"));
		
	}

}