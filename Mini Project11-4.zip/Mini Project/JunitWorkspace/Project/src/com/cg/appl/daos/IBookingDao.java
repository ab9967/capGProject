package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.exception.BookingException;

public interface IBookingDao {
	//to be deleted while final review	
	
}
