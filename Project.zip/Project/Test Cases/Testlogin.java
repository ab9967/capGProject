package com.cg.appl.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.appl.daos.HotelDaoImpl;
import com.cg.appl.exception.BookingException;

public class Testlogin {

	HotelDaoImpl dao = new HotelDaoImpl();
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testisUserAuthenticated() throws BookingException {
		System.out.println("Scott Password");
		System.out.println(dao.getUserDetails("Scott"));
		assertNotNull(dao.getUserDetails("Scott"));
		
	}

}
