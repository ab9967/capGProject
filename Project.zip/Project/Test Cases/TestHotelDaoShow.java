		package com.cg.appl.junit;
		
		import static org.junit.Assert.assertEquals;
		


		import org.junit.After;
import org.junit.Before;
import org.junit.Test;
		


		import com.cg.appl.daos.HotelDaoImpl;
import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;
		
		public class TestHotelDaoShow {
		
			HotelDaoImpl h;
			Hotel hotelBean;
			BookingDetails book;
			RoomDetails room;
			Users user;
		
			@Before
			public void setUp() throws Exception {
				h = new HotelDaoImpl();
				hotelBean = new Hotel();
				user = new Users();
			}
		
			@After
			public void tearDown() throws Exception {
				h = null;
				hotelBean = null;
				book = null;
				user = null;
				room = null;
		
			}
		
		@Test
		public void testgetHotel() throws BookingException {		
				
			try {
				String hotelID = "1122";
				assertEquals(1, h.getHotel(hotelID));
			} catch (BookingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		@Test
		public void testviewHotelwiseBooking() throws BookingException {
		
			try {
				String hotel_id = "1101";
				assertEquals(1, h.viewHotelwiseBooking(hotel_id));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		@Test
		public void testviewGuestList() throws BookingException {
		
			try {
				String user_id = "1001";
				assertEquals(1, h.viewGuestList(user_id));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		@Test
		public void testGetHotelName() throws BookingException {
		
			try {
				String hotelID = "1101";
				assertEquals(1, h.GetHotelName(hotelID));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		@Test
		public void testGetHotelNames() throws BookingException {
		
			try {
				// String hotelID = "1101";
				assertEquals(1, h.GetHotelNames());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		@Test
		public void testviewBookingHistory() throws BookingException {
		
			try {
				String user_id = "1001";
				assertEquals(1, h.viewBookingHistory(user_id));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		@Test
		public void testviewBookingDatewise() throws BookingException {
		
			try {
				
				String fromDate="12-MAY-2017";
				String toDate = "21-MAY-2017";
				assertEquals(1, h.viewBookingDatewise(fromDate, toDate));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		@Test
		public void getUserDetails() throws BookingException {
		
			try {
				String userName = "Scott";
				assertEquals(1, h.getUserDetails(userName));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		@Test
		public void testshowAllRooms() throws BookingException {
		
			try {
				String hotel_id = "1122";
				assertEquals(1, h.showAllRooms(hotel_id));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		@Test
		public void testshowAllHotel() throws BookingException {
		
			try {
		
				assertEquals(1, h.showAllHotel());
			} catch (Exception e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		
		}
