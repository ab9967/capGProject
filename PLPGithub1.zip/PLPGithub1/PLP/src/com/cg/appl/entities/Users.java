package com.cg.appl.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;


@Entity(name="users")
@Table(name="Users")
@NamedQueries({
@NamedQuery(name="getUserDetails", query = "select e from users e  where user_name is :userNm"),
@NamedQuery(name="getUserPassword", query = "select password from users where user_name is :userNm")
})
@SequenceGenerator(name = "user_generate", sequenceName = "user_id_seq" , allocationSize=1, initialValue=1006)

public class Users implements Serializable{

	private static final long serialVersionUID = 1L;
	private String user_id;
	private String password;
	private String role;
	private String user_name;
	private String mobile_no;
	private String phone;
	private String address;
	private String email;
	private List<BookingDetails> book;
	public Users(String user_id, String password, String role,
			String user_name, String mobile_no, String phone, String address,
			String email) {
		super();
		this.user_id = user_id;
		this.password = password;
		this.role = role;
		this.user_name = user_name;
		this.mobile_no = mobile_no;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}
	public Users() {
		super();
	}
	@Id
	@Column(name="user_id")
	@GeneratedValue(generator="user_generate", strategy = GenerationType.SEQUENCE)
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	@Column(name="password")

	@NotNull(message="Password is required")
	//@Size(min=1, max=10, message="Name must be of size 1 to 10")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Column(name="role")
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Column(name="user_name")

	@NotNull(message="Name is required")
	@Size(min=1, max=10, message="Name must be of size 1 to 10")
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	@Column(name="mobile_no")
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	@Column(name="phone")
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	@Column(name="address")
	@NotNull(message="Address is required")
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Column(name="email")
	@Email(message="Invalid email format")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@OneToMany(mappedBy="user") 
	public List<BookingDetails> getBook() {
		return book;
	}
	public void setBook(List<BookingDetails> book) {
		this.book = book;
	}
	@Override
	public String toString() {
		return "Users [user_id=" + user_id + ", password=" + password
				+ ", role=" + role + ", user_name=" + user_name
				+ ", mobile_no=" + mobile_no + ", phone=" + phone
				+ ", address=" + address + ", email=" + email + "]";
	}
	
	
	
	
	

}
