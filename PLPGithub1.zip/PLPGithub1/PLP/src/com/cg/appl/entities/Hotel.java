package com.cg.appl.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity(name="hotel")
@Table(name="HOTEL")
@NamedQueries({
@NamedQuery(name="qryAllHotels", query = "select h from hotel h"),
//@NamedQuery(name="qryAllHotelRooms", query = "select h from room_details h where hotel_id is :hotelID"),
//@NamedQuery(name="delAllHotelRooms", query = "delete r from room_details r where hotel_id is :hotelID"),
@NamedQuery(name="qryAllHotelnm", query = "select hotel_name from hotel h"),
@NamedQuery(name="qryHotelOId", query = "select h from hotel h where hotel_id is :hotelid")
})
@SequenceGenerator(name = "hotel_generate", sequenceName = "seq_hotel_Id" , allocationSize=1, initialValue=5004)
public class Hotel implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String hotel_id;
	private String city;
	private String hotel_name;
	private String address;
	private String description;
	private int avg_rate_per_night;
	private String phone_no1;
	private String phone_no2;
	private int rating;
	private String email;
	private String fax;
	private List<BookingDetails> books;
	private List<RoomDetails> rooms;
	
	public Hotel() {
		super();
	}
	public Hotel(String hotel_id, String city, String hotel_name,
			String address, String description, int avg_rate_per_night,
			String phone_no1, String phone_no2, int rating, String email,
			String fax) {
		super();
		this.hotel_id = hotel_id;
		this.city = city;
		this.hotel_name = hotel_name;
		this.address = address;
		this.description = description;
		this.avg_rate_per_night = avg_rate_per_night;
		this.phone_no1 = phone_no1;
		this.phone_no2 = phone_no2;
		this.rating = rating;
		this.email = email;
		this.fax = fax;
	}
	@Id
	@Column(name="hotel_id  ")
	@GenericGenerator(name = "hotel_generate", strategy = "com.cg.appl.identifierGeneration.StringSequenceGenerator")
	@GeneratedValue(generator="hotel_generate", strategy = GenerationType.SEQUENCE)
	public String getHotel_id() {
		return hotel_id;
	}
	public void setHotel_id(String hotel_id) {
		this.hotel_id = hotel_id;
	}
	@Column(name="city  ")
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Column(name="hotel_name  ")
	public String getHotel_name() {
		return hotel_name;
	}
	public void setHotel_name(String hotel_name) {
		this.hotel_name = hotel_name;
	}
	@Column(name="address  ")
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Column(name="description  ")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Column(name="avg_rate_per_night  ")
	public int getAvg_rate_per_night() {
		return avg_rate_per_night;
	}
	public void setAvg_rate_per_night(int avg_rate_per_night) {
		this.avg_rate_per_night = avg_rate_per_night;
	}
	@Column(name="phone_no1  ")
	public String getPhone_no1() {
		return phone_no1;
	}
	public void setPhone_no1(String phone_no1) {
		this.phone_no1 = phone_no1;
	}
	@Column(name="phone_no2  ")
	public String getPhone_no2() {
		return phone_no2;
	}
	public void setPhone_no2(String phone_no2) {
		this.phone_no2 = phone_no2;
	}
	@Column(name="rating  ")
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	@Column(name="email  ")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Column(name="fax  ")
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	@OneToMany(mappedBy="hotel") 
	public List<BookingDetails> getBooks() {
		return books;
	}
	public void setBooks(List<BookingDetails> books) {
		this.books = books;
	}
	@OneToMany(mappedBy="hotel") 
	public List<RoomDetails> getRooms() {
		return rooms;
	}
	public void setRooms(List<RoomDetails> rooms) {
		this.rooms = rooms;
	}
	@Override
	public String toString() {
		return "Hotel [hotel_id=" + hotel_id + ", city=" + city
				+ ", hotel_name=" + hotel_name + ", address=" + address
				+ ", description=" + description + ", avg_rate_per_night="
				+ avg_rate_per_night + ", phone_no1=" + phone_no1
				+ ", phone_no2=" + phone_no2 + ", rating=" + rating
				+ ", email=" + email + ", fax=" + fax + "]";
	}
	

	
	
}