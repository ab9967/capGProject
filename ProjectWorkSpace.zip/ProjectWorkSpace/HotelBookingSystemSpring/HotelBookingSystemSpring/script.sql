create table userMP(
user_id number PRIMARY KEY, 
password varchar(7), 
role varchar(10),  
user_name varchar (20), 
mobile_no varchar(10), 
phone varchar(10), 
address varchar(25), 
email varchar(15) UNIQUE);

insert into userMP values(1,'123','admin','Rivu','123','123','abc','admin');

create table hotelMP( 
hotel_id number PRIMARY KEY, 
city  varchar(10), 
hotel_name varchar (20), 
address varchar(25), 
description varchar(50), 
avg_rate_per_night number(6,2), 
phone_no1 varchar(10), 
phone_no2 varchar(10), 
rating varchar(4), 
email varchar(15), 
fax varchar(15));


create table roomDetailsMP(   
room_id number PRIMARY KEY,  
hotel_id number references hotelMP(hotel_id),
room_no varchar(3), 
room_type varchar(20), 
per_night_rate number(6,2), 
availability varchar2(5), 
photo varchar2(100));


create table bookingDetails( 
booking_id number PRIMARY KEY, 
room_id number references roomDetailsMP(room_id),  
user_id number references userMP(user_id), 
booked_from  date, 
booked_to date, 
no_of_adults number, 
no_of_children number,
no_of_rooms number,
amount number(6,2));

alter table bookingDetails modify amount number(20,2);

SELECT * from userMP;
SELECT * FROM hotelMP;
SELECT * FROM roomDetailsMP;
SELECT * FROM bookingDetails;

drop table bookingDetails cascade constraints;
drop table roomDetailsMP cascade constraints;
drop table hotelMP cascade constraints;
drop table userMP cascade constraints;

create table login(username varchar2(20) primary key, password varchar2(20),role varchar2(10));

Select user_seq.nextVal from Dual;

create sequence hotel_seq start with 100;
create sequence user_seq start with 100;
create sequence room_seq start with 100;
create sequence booking_seq start with 100;

drop sequence user_seq;
drop sequence hotel_seq;
drop sequence room_seq;
drop sequence booking_seq;