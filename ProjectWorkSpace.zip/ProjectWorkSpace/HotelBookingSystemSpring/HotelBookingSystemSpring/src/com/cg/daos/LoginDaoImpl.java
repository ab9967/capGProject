package com.cg.daos;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.cg.entities.HotelBean;
import com.cg.entities.UserBean;
import com.cg.exception.CustomException;

@Repository
public class LoginDaoImpl implements ILoginDao{

	@PersistenceContext
	EntityManager entityManager;

/*	@Override
	public UserBean validateLogin(UserBean user)throws CustomException {
		System.out.println("DAO:");
		
		UserBean userValidate;
		TypedQuery<UserBean> query = entityManager.createQuery("SELECT u FROM UserBean u WHERE u.email=:email", UserBean.class);
		System.out.println(user.getEmail());
		query.setParameter("email", user.getEmail());
		userValidate = (UserBean) query.getSingleResult();
		System.out.println(userValidate);
		try{
			if(userValidate.equals(null)||(!(userValidate.getPassword().equalsIgnoreCase(user.getPassword()))))throw new Exception();			
		}catch(Exception e){
			throw new CustomException("Invalid Login Details");
		}
		System.out.println("In DAO\t"+userValidate);
		return userValidate;
	}*/

	@Override
public UserBean validateLogin(UserBean user)throws CustomException {
		
		try {
			TypedQuery<UserBean> query = entityManager.createQuery("SELECT u FROM UserBean u where u.email=:pemail and u.password=:ppass", UserBean.class);
			query.setParameter("pemail", user.getEmail());
			query.setParameter("ppass", user.getPassword());
			UserBean RegisteredUser=query.getSingleResult();
			if(RegisteredUser==null)
			{
				throw new CustomException("Wrong Log In credentials");
			}else
			return RegisteredUser;
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw new CustomException("Something went wrong while fetching details from database...");
		}
	
	}
	
	
}
