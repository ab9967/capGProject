package com.cg.daos;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.cg.entities.BookingDetailsBean;
import com.cg.entities.HotelBean;
import com.cg.entities.RoomDetailsBean;
import com.cg.entities.UserBean;
import com.cg.exception.CustomException;

@Repository
public class UserDaoImpl implements IUserDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public boolean addUser(UserBean user) throws CustomException {
		
		try {
			System.out.println("in dao"+user);
			entityManager.persist(user);		
			return true;
		} catch (DataAccessException e) {
			 
			throw new CustomException("Error adding user");
		}
	}
	
	
	@Override
	public List<HotelBean> getHotelsBasedOnCriteria(int numberOfRooms,
			Date bookFrom, Date bookTo, String city) throws CustomException {
		
			TypedQuery<HotelBean> query = entityManager.createQuery("SELECT h FROM HotelBean h WHERE city = :pCity and hotelId IN (SELECT hotel.hotelId from RoomDetailsBean where roomNo >= :proomNo )", HotelBean.class);
			query.setParameter("pCity", city);
			query.setParameter("proomNo", (Integer.toString(numberOfRooms)));
			List<HotelBean> hotelList = query.getResultList();
			if(hotelList.isEmpty()){
				throw new CustomException();
			}
			return hotelList;
		
		
	}

	@Override
	public int addBooking(BookingDetailsBean booking) throws CustomException {
		
			entityManager.persist(booking);
			
			return booking.getBookingId();
		
	}

	@Override
	public boolean deleteBooking(int bookingId) throws CustomException {
		try {
			entityManager.remove(getBooking(bookingId));
			
			return true;
		} catch (Exception e) {
			
			 
			throw new CustomException("error in deleting booking");
		}
	}

	@Override
	public BookingDetailsBean getBooking(int bookingId) throws CustomException {
		BookingDetailsBean bookingDetailsBean;
		
			bookingDetailsBean= entityManager.find(BookingDetailsBean.class, bookingId);
			try{
				if(bookingDetailsBean==null){
				throw new CustomException("Booking details not found");
			}
			else{
				return bookingDetailsBean;
			}
		}catch(Exception e){
			 
			throw new CustomException("BookingId not found");
			
		}
		
		
	}

	@Override
	public HotelBean getHotelById(int hotelId) throws CustomException {
		HotelBean hotelBeans;
		
			hotelBeans = entityManager.find(HotelBean.class, hotelId);
			try{
			if(hotelBeans ==null){
				throw new CustomException(" Hotel details not found");
			}
			else{
				return hotelBeans ;
			}
		}catch(Exception e){
			 
			throw new CustomException("Hotel not found");
		}
			
	}

	@Override
	public UserBean getUserByEmail(String email) throws CustomException {
		
		return null;
	}

	@Override
	public List<BookingDetailsBean> getBookingByUser(int userId)
			throws CustomException {
		
		TypedQuery<BookingDetailsBean> query = entityManager.createQuery("SELECT b FROM BookingDetailsBean b WHERE  user.userId = :puserId", BookingDetailsBean.class);
		query.setParameter("puserId", userId);
		List<BookingDetailsBean> bookingList = query.getResultList();
		
		if(bookingList.isEmpty())throw new CustomException("List is Empty");
		return bookingList;
	}

	
	
	@Override
	public HotelBean addHotel(HotelBean hotel) throws CustomException {
		if(hotel.equals(null))
			throw new CustomException("Value passed null");	
		try {
			entityManager.persist(hotel);
			return hotel;
		} 
		catch (Exception e) {
			throw new CustomException("Error adding hotel");
		}
	}

	

	@Override
	public boolean updateHotel(HotelBean hotel)
			throws CustomException {
		try {
			entityManager.merge(hotel);
		} 
		catch (Exception e) {
			
			 
			throw new CustomException("Error updating hotel details");
		}
		return true;
	}

	@Override
	public boolean removeHotel(int hotelId) throws CustomException {
		try {
			entityManager.remove(getHotelById(hotelId));
			return true;
		} 
		catch (Exception e) {
			throw new CustomException("Deletion failed... Booking already Exists");
		}
	}

	@Override
	public int addRoom(RoomDetailsBean room) throws CustomException {
		try {
			entityManager.persist(room);
			return room.getRoomId();
		} catch (DataAccessException e) {
		
			 
			throw new CustomException("Error adding room");
		}
	}

	@Override
	public boolean updateRoom(RoomDetailsBean room)
			throws CustomException {
		try {
			entityManager.merge(room);
			return true;
		} catch (Exception e) {
			
			 
			throw new CustomException("Error updating room");
		}
	}

	@Override
	public RoomDetailsBean getRoomById(int roomId) throws CustomException {
		RoomDetailsBean room;
		
			room = entityManager.find(RoomDetailsBean.class, roomId);
			try{
				if(room ==null){
				throw new CustomException(" room not found");
			}
			else{
				return room ;
			}
		}catch(Exception e){
			 
			throw new CustomException("room not found");
		}
	}

	@Override
	public void removeRoom(int roomId) throws CustomException {
		try {
			entityManager.remove(getRoomById(roomId));
		} catch (Exception e) {
			
			 
			throw new CustomException(" room cannot be deleted");
		}

	}

	@Override
	public List<RoomDetailsBean> getRoomList(int hotelId)
			throws CustomException {
		
			TypedQuery<RoomDetailsBean> query = entityManager.createQuery("SELECT r FROM RoomDetailsBean r WHERE hotel.hotelId = :photelId", RoomDetailsBean.class);
			query.setParameter("photelId", hotelId);
			List<RoomDetailsBean> roomList = query.getResultList();
			
			if(roomList.isEmpty())throw new CustomException("List is Empty");
			return roomList;
		
		
	}

	@Override
	public double getPayment(int roomId) throws CustomException {
		
		double payment = getRoomById(roomId).getPerNightRate();
		return payment;
	}

	@Override
	public List<HotelBean> getHotels() throws CustomException {
		try {
			TypedQuery<HotelBean> query = entityManager.createQuery("SELECT r FROM HotelBean r ", HotelBean.class);
			
			List<HotelBean> hotelList = query.getResultList();
			return hotelList;
		} catch (Exception e) {
			 
			throw new CustomException("Something went wrong while fetching hotel details from database...");
		}
	}

	@Override
	public List<BookingDetailsBean> getBookingByHotel(int hotelId)
			throws CustomException {
		try {
			TypedQuery<BookingDetailsBean> query = entityManager.createQuery("SELECT r FROM BookingDetailsBean r WHERE hotelId = :photelId", BookingDetailsBean.class);
			query.setParameter("photelId", hotelId);
			List<BookingDetailsBean> roomList = query.getResultList();
			return roomList;
		} catch (Exception e) {
			 
			throw new CustomException("Something went wrong while fetching booking details from database...");
		}
	}

	@Override
	public List<BookingDetailsBean> getBookingByDate(Date date)
			throws CustomException {
		try {
			TypedQuery<BookingDetailsBean> query = entityManager.createQuery("SELECT b FROM  BookingDetailsBean b where bookedFrom < :pdate and bookedTo > :pdate)", BookingDetailsBean.class);
			
			java.sql.Date dateSql = new java.sql.Date(date.getTime());
			query.setParameter("pdate", dateSql);
			List<BookingDetailsBean> roomList = query.getResultList();
			return roomList;
		} catch (Exception e) {
			 
			throw new CustomException("Something went wrong while fetching booking details from database...");
		}
	}

	@Override
	public List<UserBean> getCustomersByHotel(int hotelId)
			throws CustomException {
		try {
			TypedQuery<UserBean> query = entityManager.createQuery("SELECT u FROM UserBean u WHERE hotelId = :photelId", UserBean.class);
			query.setParameter("photelId", hotelId);
			List<UserBean> userList = query.getResultList();
			return userList;
		} catch (Exception e) {
			 
			throw new CustomException("Something went wrong while fetching user details from database...");
		}
	}

}
