package com.cg.daos;

import com.cg.entities.UserBean;
import com.cg.exception.CustomException;

public interface ILoginDao {

	UserBean validateLogin(UserBean user) throws CustomException;

}
