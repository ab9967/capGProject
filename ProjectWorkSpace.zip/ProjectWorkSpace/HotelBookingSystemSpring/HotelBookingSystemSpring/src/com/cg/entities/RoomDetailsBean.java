package com.cg.entities;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



@Entity
@Table(name="roomDetailsMP")
@SequenceGenerator(name="room_generator" ,sequenceName="room_seq", allocationSize=1, initialValue=100)
public class RoomDetailsBean implements Serializable{


	private static final long serialVersionUID = 1L;
	
	
	private int roomId;
    
    private String roomNo;
   
    private String roomType;
  
    private double perNightRate;
   
    private String availability;
   
    private String picture;
    
    
    private Set<BookingDetailsBean> booking;
    
  
    private HotelBean hotel;
    
	//Non parameterized Constructor 
	public RoomDetailsBean() {
		super();
		hotel = new HotelBean();
	}
	


	
	//Getter Setter Methods
	
	@Id
    @Column(name="room_id")
	@GeneratedValue(generator="room_generator", strategy=GenerationType.SEQUENCE)
	public int getRoomId() {
		return roomId;
	}
	



	@OneToMany(mappedBy="room")
	public Set<BookingDetailsBean> getBooking() {
		return booking;
	}




	public void setBooking(Set<BookingDetailsBean> booking) {
		this.booking = booking;
	}



	  @ManyToOne
	    @JoinColumn(name="hotel_id")
	public HotelBean getHotel() {
		return hotel;
	}




	public void setHotel(HotelBean hotel) {
		this.hotel = hotel;
	}




	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	@Column(name="room_no")
	public String getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}
	 @Column(name="room_type")
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	  @Column(name="per_night_rate")
	public double getPerNightRate() {
		return perNightRate;
	}
	public void setPerNightRate(double perNightRate) {
		this.perNightRate = perNightRate;
	}
	 @Column(name="availability")
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	 @Column(name="photo")
	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}




	@Override
	public String toString() {
		return "RoomDetailsBean [roomId=" + roomId + ", roomNo=" + roomNo
				+ ", roomType=" + roomType + ", perNightRate=" + perNightRate
				+ ", availability=" + availability + ", picture=" + picture
				+ ", booking=" + booking + ", hotel=" + hotel + "]";
	}

	


	
	
	
}
