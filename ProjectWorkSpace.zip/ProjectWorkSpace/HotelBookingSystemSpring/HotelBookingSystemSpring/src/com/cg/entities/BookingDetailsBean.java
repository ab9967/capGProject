package com.cg.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Pattern;


@Entity
@Table(name="bookingDetails")
@SequenceGenerator(name="booking_generator" ,sequenceName="booking_seq", allocationSize=1, initialValue=100)
public class BookingDetailsBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private int bookingId;
	 
	
	 private Date bookedFrom; 
	

	 private Date bookedTo; 
	
	 private int noOfAdults;
	
	 private int noOfChild; 
	
	 private int noOfrooms;
	 
	 private double amount;
	 
	
	 private RoomDetailsBean room;  
	 
	 
	
	 private UserBean user;
		 
	public BookingDetailsBean() {
		super();
		
	}
	public BookingDetailsBean(int bookingId, int roomId, int userId,
			Date bookedFrom, Date bookedTo, int noOfAdults, int noOfChild,int noOfrooms,
			double amount) {
		super();
		this.bookingId = bookingId;
		this.room = new RoomDetailsBean();
		room.setRoomId(roomId);
		this.user.setUserId(userId);
		this.bookedFrom = bookedFrom;
		this.bookedTo = bookedTo;
		this.noOfAdults = noOfAdults;
		this.noOfChild = noOfChild;
		this.noOfrooms = noOfrooms;
		this.amount = amount;
	}

	public BookingDetailsBean(RoomDetailsBean room, UserBean userId,
			Date bookedFrom, Date bookedTo, int noOfAdults, int noOfChild,
			double amount) {
		super();
		
		
		this.room=room;
		
		this.user=userId;
		
		this.bookedFrom = bookedFrom;
		
		this.bookedTo = bookedTo;
		
		this.noOfAdults = noOfAdults;
		
		this.noOfChild = noOfChild;
		
		this.amount = amount;
	}
	public BookingDetailsBean(int bookingId,
			RoomDetailsBean roomId, UserBean userId, Date bookedFrom,
			Date bookedTo, int noOfAdults, int noOfChild, double amount) {

		this.bookingId=bookingId;
		this.room=roomId;
		
		this.user=userId;
		
		this.bookedFrom = bookedFrom;
		
		this.bookedTo = bookedTo;
		
		this.noOfAdults = noOfAdults;
		
		this.noOfChild = noOfChild;
		
		this.amount = amount;
	}
	
	@Id
    @Column(name="booking_id")
	@GeneratedValue(generator="booking_generator", strategy=GenerationType.SEQUENCE)
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	 @OneToOne
	 @JoinColumn(name="room_id")
	public RoomDetailsBean getRoom() {
		return room;
	}
	public void setRoom(RoomDetailsBean room) {
		this.room = room;
	}
	 @OneToOne
	 @JoinColumn(name="user_id")
	public UserBean getUser() {
		return user;
	}
	 public void setUser(UserBean user) {
			this.user = user;
		}
	
	
	 @Column(name="booked_from")

	public Date getBookedFrom() {
		return bookedFrom;
	}
	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}


	 @Column(name="booked_to")
	
	public Date getBookedTo() {
		return bookedTo;
	}
	public void setBookedTo(Date bookedTo) {
		this.bookedTo = bookedTo;
	}
	 @Column(name="no_of_adults")
	public int getNoOfAdults() {
		return noOfAdults;
	}
	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}
	 @Column(name="no_of_children")
	public int getNoOfChild() {
		return noOfChild;
	}
	public void setNoOfChild(int noOfChild) {
		this.noOfChild = noOfChild;
	}
	@Column(name="amount")
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	 @Column(name="no_of_rooms")
	public int getNoOfrooms() {
		return noOfrooms;
	}
	public void setNoOfrooms(int noOfrooms) {
		this.noOfrooms = noOfrooms;
	}	
	@Override
	public String toString() {
		return "BookingDetailsBean [bookingId=" + bookingId + ", roomId="
				+ room.getRoomId() + ", userId=" + user.getUserId() + ", bookedFrom=" + bookedFrom
				+ ", bookedTo=" + bookedTo + ", noOfAdults=" + noOfAdults
				+ ", noOfChild=" + noOfChild + ", amount=" + amount + "]";
	}
	
	
}
