package com.cg.entities;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="hotelMP")
public class HotelBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int hotelId;
	private String city;
	private String hotelName;
	private String address;
	private String description;
	private double avgRatePerNight;
	private String phoneNo1;
	private String phoneNo2;
	private String rating;
	private String email;
	private String fax;
	private Set<RoomDetailsBean> rooms; 
	
	
	//Non parameterized constructor
	
	public HotelBean() {
		super();
	}
	
	@OneToMany(mappedBy="hotel",fetch=FetchType.EAGER)
	public Set<RoomDetailsBean> getRooms() {
		return rooms;
	}
	public void setRooms(Set<RoomDetailsBean> rooms) {
		this.rooms = rooms;
	}
	
	
	@Id
    @Column(name="hotel_id")
	@GeneratedValue(generator="hotel_generator", strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="hotel_generator" ,sequenceName="hotel_seq", allocationSize=1, initialValue=100)
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	
	@NotNull(message="City cannot be empty")
	@Column(name="city")
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	@NotNull(message="Hotel Name cannot be empty")
	@Column(name="hotel_name")
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	
	 @NotNull(message="Address cannot be empty")
	@Column(name="address")
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Column(name="description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	 @NotNull(message="Average rate per night cannot be empty")
	@Column(name="avg_rate_per_night")
	public double getAvgRatePerNight() {
		return avgRatePerNight;
	}
	public void setAvgRatePerNight(double avgRatePerNight) {
		this.avgRatePerNight = avgRatePerNight;
	}
	
	@NotNull(message="Phone number 1  cannot be empty")
	@Column(name="phone_no1")
	@Pattern(regexp="^[7-9][0-9]{9}$",message="Mobile must be 10 digits and start with 7/8/9  ")
	public String getPhoneNo1() {
		return phoneNo1;
	}
	public void setPhoneNo1(String phoneNo1) {
		this.phoneNo1 = phoneNo1;
	}
	@Column(name="phone_no2")
	public String getPhoneNo2() {
		return phoneNo2;
	}
	public void setPhoneNo2(String phoneNo2) {
		this.phoneNo2 = phoneNo2;
	}
	
	@Column(name="rating")
	@Pattern(regexp="^[1-5]$")
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	
	@Pattern(regexp="^[A-Za-z0-9_.]+[@][A-Za-z]+[.][a-z]{2,3}$")
	@NotNull(message="Email cannot be empty")
	@Column(name="email")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Column(name="fax")
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	@Override
	public String toString() {
		return "HotelBean [hotelId=" + hotelId + ", city=" + city
				+ ", hotelName=" + hotelName + ", address=" + address
				+ ", description=" + description + ", avgRatePerNight="
				+ avgRatePerNight + ", phoneNo1=" + phoneNo1 + ", phoneNo2="
				+ phoneNo2 + ", rating=" + rating + ", email=" + email
				+ ", fax=" + fax +"]";
	}
	
	
	

}
