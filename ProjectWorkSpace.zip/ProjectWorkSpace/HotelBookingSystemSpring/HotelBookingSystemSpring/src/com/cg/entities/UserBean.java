package com.cg.entities;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


@Entity
@Table(name="userMP")
public class UserBean implements Serializable{
	

	private static final long serialVersionUID = 1L;
	
	
	private int userId; 
	private String password;
    private String role;
    private String userName;
	private String mobileNo;
	private String phone;
    private String address;
    private String email;
	private Set<BookingDetailsBean> bookingList;
	
	public UserBean() {
		super();
	}
	public UserBean(int userId, String password, String role,
			String userName, String mobileNo, String phone, String address,
			String email) {
		super();
		this.userId = userId;
		this.password = password;
		this.role = role;
		this.userName = userName;
		this.mobileNo = mobileNo;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}
	
	@Id
 	@GeneratedValue(generator="user_generator", strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="user_generator" ,sequenceName="user_seq", allocationSize=1, initialValue=100)
	@Column(name="user_id")
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	
    @NotNull(message="Password cannot be empty")
    @Column(name="password")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	@NotNull(message="Role cannot be empty")
	@Column(name="role")
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	 @Size(min=4,max=10, message="Username must be between 4 and 10 characters")
	    @NotNull(message="UserName cannot be empty")
	    @Column(name="user_name")
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	 
    @NotNull(message="MobileNo cannot be empty")
    @Pattern(regexp="^[7-9][0-9]{9}$",message="Mobile must be 10 digits and start with 7/8/9  ")
    @Column(name="mobile_no")
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	
	 @Pattern(regexp="^[0-9]{3}[-][0-9]{6}$",message="Must be in xxx-xxxxxx format")
	    @Column(name="phone")
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
    @NotNull(message="Address cannot be empty")
    @Column(name="address")
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	 @NotNull(message="Email cannot be empty")
	    @Pattern(regexp="^[A-Za-z0-9_.]+[@][A-Za-z]+[.][a-z]{2,3}$")
	    @Column(name="email")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@OneToMany(mappedBy="user")
	public Set<BookingDetailsBean> getBookingList() {
		return bookingList;
	}
	public void setBookingList(Set<BookingDetailsBean> bookingList) {
		this.bookingList = bookingList;
	}
	@Override
	public String toString() {
		return "UserBean [userId=" + userId + ", password=" + password
				+ ", role=" + role + ", userName=" + userName + ", mobileNo="
				+ mobileNo + ", phone=" + phone + ", address=" + address
				+ ", email=" + email + ", bookingList=" + bookingList + "]";
	}
	
	

	
	
}
