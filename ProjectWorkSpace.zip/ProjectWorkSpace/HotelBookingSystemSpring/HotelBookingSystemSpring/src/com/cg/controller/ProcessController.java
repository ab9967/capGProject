package com.cg.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.BookingDetailsBean;
import com.cg.entities.HotelBean;
import com.cg.entities.RoomDetailsBean;
import com.cg.entities.UserBean;
import com.cg.exception.CustomException;
import com.cg.service.IUserService;
import com.cg.utility.HotelBookingConstants;

/**
 * @author usanyal
 *
 */
@Controller
public class ProcessController {
	
	@Autowired
	private IUserService service;
	
	HttpSession session;
	
	/**
	 * @param model Used to store and pass data between jsp and controller in string format     
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping(value="/loginform",method=RequestMethod.GET)
	public String showHome(Model model)
	{
		model.addAttribute("login",new UserBean());
		return "Login";
	}
	

	/**	Validates login for two type of users: customer and admin
	 * @param p Used to accept user credentials from jsp 
	 * @param model model Used to store and pass data between jsp and controller in string format   
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/login")
		public String loginUser(@ModelAttribute("login") UserBean p, Model model, HttpServletRequest request)
		{
			session=request.getSession();
				try{
					UserBean validatedUser=service.validateLogin(p);
					if(validatedUser.getRole().equalsIgnoreCase("admin"))
					{
							model.addAttribute("user",validatedUser);
							model.addAttribute("loggedUserName","Admin");
							session.setAttribute("user", validatedUser);
							return "AdminHome";
					}
									
					else
					{			
							model.addAttribute("user",validatedUser);
							model.addAttribute("loggedUserName",validatedUser.getUserName());
							session.setAttribute("user", validatedUser);
							return "CustomerHome";
					}
						
	
				}catch(CustomException e){
					model.addAttribute("message", e.getMessage());
					return "Error";
				}
	
		}
	
	/**
	 * Redirects to register form 
	 * @param model Used to store and pass data between jsp and controller in string format 
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/registerUserForm")
	public String redirectRegister(Model model)
	{
		model.addAttribute("register",new UserBean());
		model.addAttribute("roles",new String[]{"customer","employee"});
		return "RegisterUser";
	}
	
	
	/**
	 * Registers the user in the database
	 * @param user Used to store user details in object 
	 * @param bindingResult Binds the user details to its bean and used for validation 
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/register")
	public String registerUser(@ModelAttribute("register")@Valid UserBean user,BindingResult bindingResult, Model model,HttpServletRequest req)
	{
		session = req.getSession();
		String view="";
		if(bindingResult.hasErrors())
		{
			model.addAttribute("register",user);
			model.addAttribute("roles",new String[]{"customer","employee"});
			return "RegisterUser";
		}
		else{
		try {
			if(service.addUser(user))
			{	
				
				model.addAttribute("loggedUserName", user.getUserName());
				model.addAttribute("loggedUserId", user.getUserId());
				model.addAttribute("user",user);
				session.setAttribute("user",user);
				view= "CustomerHome";
			}
			else{
				view= "Login"; 
			}
		} catch (CustomException e) {
			
			e.printStackTrace();
			model.addAttribute("errorMessage",e.getMessage());
			view= "Error.jsp";
			
		}
		return view;		
		}
	}
	
	
	/**
	 * Used to invalidate the session
	 * @return Returns to the directed page
	 */
	@RequestMapping("/logout")
	public String logout()
	{
		session.invalidate();
		return "Homepage";
		
	}

	
	/**
	 * Directs to the add hotel form
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/addHotelForm")
	public String addhotelForm(Model model)
	{
		model.addAttribute(HotelBookingConstants.HOTEL, new HotelBean());
		model.addAttribute("cities",new String[]{"pune","kolkata", "mumbai", "shimla"});
		model.addAttribute("stars",new String[]{"1","2", "3", "4", "5"});
		return "AddHotelForm";
		
	}
	
	/**
	 * Admin adds the hotel details in the database
	 * @param hotel Form object which stores the details 
	 * @param bindingResult Binds the hotel details to its bean and used for validation
	 * @param model Used to store and pass data between jsp and controller in string format 
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/addHotel")
	public String addhotel(@ModelAttribute("hotel")@Valid HotelBean hotel,BindingResult bindingResult, Model model)
	{
		String view="";
		if(bindingResult.hasErrors()){
			model.addAttribute(HotelBookingConstants.HOTEL, hotel);
			model.addAttribute("cities",new String[]{"pune","kolkata", "mumbai", "shimla"});
			model.addAttribute("stars",new String[]{"1","2", "3", "4", "5"});
			view = "AddHotelForm";
		}
		else{
			try{
				
				HotelBean addedHotel = service.addHotel(hotel);
				model.addAttribute("hotel", addedHotel);
				view = "showHotel";
			} catch (CustomException e) {
				model.addAttribute("errorMessage",e.getMessage());
				view= "Error";
			}
		}
		return view;
	}
	
	/**
	 * Redirects to the admin home page
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/AdminHome")
	public String adminHome(Model model)
	{
		return "AdminHome";
		
	}
	
	/**
	 * Directs to the customer home page
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/CustomerHome")
	public String customerHome(Model model)
	{
		return "CustomerHome";
		
	}
	
	
	/**
	 * Directs to the add room form page
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/addRoomForm")
	public String addRoomForm(Model model){
		RoomDetailsBean room = new RoomDetailsBean();
		model.addAttribute("room",room );
		return "AddRoom";
		
	}
	
	/**
	 * Admin adds room details in the database
	 * @param room Form object which stores the details 
	 * @param bindingResult Binds the hotel details to its bean and used for validation
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/addRoom")
	public String addRoom(@ModelAttribute("room")RoomDetailsBean room,BindingResult bindingResult, Model model)
	{
		String view="";
		if(bindingResult.hasErrors())
		{
			model.addAttribute("room",room);
			return "AddRoom";
		}
		else{
		try {
			service.addRoom(room);
			view = "showRoom";
		} catch (CustomException e) {
			
			model.addAttribute("errorMessage",e.getMessage());
			view= "Error";
		}
		return view;		
		}
		
	}
	
	/**
	 * Redirects to the update room form page
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/updateHotelForm")
	public String updateHotelForm(Model model)
	{
		model.addAttribute("hotel",new HotelBean());
		model.addAttribute("fetchedHotel",new HotelBean());
		return "UpdateHotelForm";
		
	}
	
	/**
	 * Fetched the data from the database
	 * @param hotel accept hotel details from jsp
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/fetchUpdateHotel")
	public String fetchUpdateHotel(@ModelAttribute("hotel")HotelBean hotel, Model model){	
		HotelBean fetchedHotel = null;
		try {
			fetchedHotel = service.getHotelById(hotel.getHotelId());
			model.addAttribute("fetchedHotel",fetchedHotel);
			return "UpdateHotelForm";
		} catch (CustomException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "Error";
		}
		
		
	}
	
	
	/**
	 * Admin update hotel details in the database
	 * @param hotel Form object which stores the details
	 * @param res Binds the hotel details to its bean and used for validation
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/updateHotel")
	public String updateHotel(@ModelAttribute("hotel")HotelBean hotel, BindingResult bindingResult, Model model){
		if(bindingResult.hasErrors()){
			model.addAttribute("fetchedHotel",hotel);
			return "UpdateHotelForm";
		}
		try {
			service.updateHotel(hotel);
			return "showHotel";
		} catch (CustomException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "Error";
		}
	}
	
	/**
	 * Redirects to update room form
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/updateRoomForm")
	public String updateRoomForm(Model model)
	{
		model.addAttribute("room",new RoomDetailsBean());
		model.addAttribute("fetchedRoom",new RoomDetailsBean());
		return "UpdateRoomForm";
		
	}
	
	/**
	 * Fetches room details from the database
	 * @param room accepts updated room details from jsp
	 * @param req 
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping(name="/fetchUpdateRoom")
	public String fetchUpdateRoom(@ModelAttribute("room")RoomDetailsBean room,HttpServletRequest req, Model model){		
				
		RoomDetailsBean fetchedRoom = null;
		try {			
			fetchedRoom = service.getRoomById(room.getRoomId());
			model.addAttribute("fetchedRoom",fetchedRoom);
			return "UpdateRoomForm";
		} catch (CustomException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "Error";
		}
	}

	/**
	 * Admin updates the room details in the database
	 * @param room accept room details from database
	 * @param bindingResult Binds the room details to its bean and used for validation
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/updateRoom")
	public String updateRoom(@ModelAttribute("room")RoomDetailsBean room, BindingResult res, Model model){
		if(res.hasErrors()){
			model.addAttribute("fetchedRoom",room);
			return "UpdateRoomForm";
		}
		try {
			service.updateRoom(room);
			model.addAttribute("room",room);
			return "showRoom";
		} catch (CustomException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "Error";
		}
	}

	/**
	 * Redirects to the delete hotel form
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/deleteHotelForm")
	public String deleteHotelForm(Model model)	{
		model.addAttribute("hotel",new HotelBean());
		model.addAttribute("fetchedHotel",new HotelBean());
		return "deleteHotelForm";
		
	}
	
	/**
	 * Fetches hotel details from database
	 * @param hotel accept hotel details from database
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */ 
	@RequestMapping("/fetchHotelDelete")
	public String fetchdeleteHotel(@ModelAttribute("hotel")HotelBean hotel, Model model){	
		HotelBean fetchedHotel = null;
		try {
			fetchedHotel = service.getHotelById(hotel.getHotelId());
			model.addAttribute("fetchedHotel",fetchedHotel);
			return "deleteHotelForm";
		} catch (CustomException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "Error";
		}
	}
	
	/**
	 * Admin delete hotel details from the database
	 * @param hotel Form object which stores the details
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 * @throws ServletException 
	 */
	@RequestMapping("/deleteHotel")
	public String deleteHotel(@ModelAttribute("hotel")HotelBean hotel, Model model) throws ServletException
	{
		
		try {
			service.removeHotel(hotel.getHotelId());
			return "AdminHome";
		} catch (CustomException e) {
			model.addAttribute("errorMessage",e.getMessage());
			throw new ServletException("Booking Exists, Deletion failed",e);
		}
		
		
	}

	/** 
	 * Redirects to remove room form page
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/removeRoomForm")
	public String deleteroomForm(Model model){
		model.addAttribute("room",new RoomDetailsBean());
		model.addAttribute("fetchedRoom",new RoomDetailsBean());
		return "removeRoomForm";
	}
	
	/**
	 * Fetches details from the database
	 * @param room accept room details from the database
	 * @param req Used to accept a httpServletrequest parameter and set the target object as request attribute directly
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/fetchRoomRemove")
	public String fetchRemoveRoom(@ModelAttribute("room")RoomDetailsBean room,HttpServletRequest req, Model model){	
		
		RoomDetailsBean fetchedRoom = null;
		try {
			fetchedRoom = service.getRoomById(room.getRoomId());
			model.addAttribute("fetchedRoom",fetchedRoom);
			return "removeRoomForm";
		} catch (CustomException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "Error";
		}
	}
	
	/**
	 * Removes room from database
	 * @param room accept room details from the database
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/removeRoom")
	public String removeRoom(@ModelAttribute("room")RoomDetailsBean room, Model model){
		try {
			service.removeRoom(room.getRoomId());
			return "AdminHome";
		} 
		catch (CustomException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "Error";
		}
	}

	/**
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/ViewHotels")
	public String fetchAllHotels(Model model)
	{
		try {
			List<HotelBean> hotelList=service.getHotelList();
			model.addAttribute("hotelList",hotelList);
			//System.out.println(hotelList);
			return "getHotelList";
		} catch (CustomException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "Error";
		}		
	}

	/**
	 * Redirects to getBookingByHotel jsp page
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/getBookingForHotel.do") 
	public String redirectGetBooking(Model model){
	model.addAttribute("hotel",new HotelBean());	
	return "getBookingByHotel";
	
	}
	
	
	@RequestMapping("showBookingsByHotels.do")
	public String getBooking(@ModelAttribute("hotel")HotelBean hotel, Model model){
		
		List<BookingDetailsBean> bookingList;
		try {
			bookingList = service.getBookingByHotel(hotel.getHotelId());
			model.addAttribute("bookingList", bookingList);
			System.out.println(bookingList);
			return "bookingList";
		} catch (CustomException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "Error";
		}
		
	}
	
	@RequestMapping("getBookingByDateForm.do")
	public String getBookingByDate(Model model)
	{
		return "getBookingByDate";
	}
	
	@RequestMapping("/getBookingByDate.do") 
	public String showBookingByDate(@RequestParam("date") String reqdate,Model model){
	SimpleDateFormat format=new SimpleDateFormat("DD-MM-YYYY");
	
	
	
		Date date;
		try {
			date = format.parse(reqdate);
			List<BookingDetailsBean> bookingList=service.getBookingByDate(date);
			model.addAttribute("bookingList", bookingList);
			return "bookingList.jsp";
		}catch (java.text.ParseException | CustomException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "Error";
		}		
	}
	
	@RequestMapping("getCustomersByHotelForm.do")
	public String getCustomersByHotel(Model model){
		return "getCustomerByHotel";
	}

	@RequestMapping("/getCustomersByHotel.do")
	public String showCustomerByHotel(@RequestParam("hotelId") String reqhotelId,Model model){
	
	try {
		int hotelId= Integer.parseInt(reqhotelId);
		List<UserBean> userList=service.getCustomersByHotel(hotelId);
		model.addAttribute("userList", userList);
		return "userList.jsp";
		
		} catch (CustomException e) {
		
			model.addAttribute("errorMessage",e.getMessage());
			return "Error";
		}
	
	}
	
	@RequestMapping( "/getPastBookings.do") 
	public String getPastBooking(Model model){
	int userId=((UserBean) session.getAttribute("user")).getUserId();
	try {
		List<BookingDetailsBean> bookings=service.getBookingByUser(userId);
		model.addAttribute("bookingList", bookings);
		return "userbookingList";
		
	} catch (CustomException e) {
		
		model.addAttribute("errorMessage",e.getMessage());
		return "Error";
	}
	
	}
	
	
	/**
	 * Redirects to the search hotel form page
	 * @param model makes a booking object
	 * @return redirects to the jsp page
	 */
	@RequestMapping("/searchHotelForm")
	public String searchHotelForm(Model model)
	{
		model.addAttribute("booking",new BookingDetailsBean());
		return "searchHotel";
		
	}
	
	/**
	 * @param booking accepts booking details from database
	 * @param city accepts city from customer
	 * @param reqbookFrom accepts date from customer
	 * @param reqbookTo accepts date from customer
	 * @param bindingResult Binds the user details to its bean and used for validation
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @param request
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/searchHotel.do")
	public String searchHotel(@ModelAttribute("booking") BookingDetailsBean booking,@RequestParam("city") String city,@RequestParam("bookFrom") String reqbookFrom,@RequestParam("bookTo") String reqbookTo,BindingResult res,Model model,HttpServletRequest request){
		int numberOfRooms=booking.getNoOfrooms();
		session=request.getSession();
		SimpleDateFormat format=new SimpleDateFormat("dd/MM/yyyy");	
		Date bookFrom=null;
		Date bookTo=null;	
		String tempBookFrom=(reqbookFrom.substring(reqbookFrom.lastIndexOf("-")+1, reqbookFrom.length())+"/"+reqbookFrom.substring(reqbookFrom.indexOf("-")+1, reqbookFrom.lastIndexOf("-"))+"/"+reqbookFrom.substring(0, reqbookFrom.indexOf("-")));
		String tempBookTo=(reqbookTo.substring(reqbookTo.lastIndexOf("-")+1, reqbookTo.length())+"/"+reqbookTo.substring(reqbookTo.indexOf("-")+1, reqbookTo.lastIndexOf("-"))+"/"+reqbookTo.substring(0, reqbookTo.indexOf("-")));
		try {
			bookFrom = format.parse(tempBookFrom);
			bookTo = format.parse(tempBookTo);
		} 
		catch (java.text.ParseException e) {
			e.printStackTrace();
		}	
		
		booking.setBookedFrom(bookFrom);
		booking.setBookedTo(bookTo);
		
		try {
			List<HotelBean> hotelList=service.getHotelsBasedOnCriteria(numberOfRooms,bookFrom,bookTo,city);	
			model.addAttribute("hotelList", hotelList);	
			session.setAttribute("booking",booking);
			return "ViewHotel"; //to view hotels
		} 
		catch (CustomException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "Error";
		}
	}
	
	/**
	 * @param value accepts value from jsp
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */

	@RequestMapping("/BookRooms")
	public String bookRooms(@RequestParam("value") String value, Model model){
		int hotelId=Integer.parseInt(value);	//getting hotelId from viewHotel.jsp
		model.addAttribute("hotelId",hotelId);
		List<RoomDetailsBean> rooms;
		try{
			rooms = service.getRoomsList(hotelId);
			model.addAttribute("roomList", rooms);			
			return "BookRooms";
		} 
		catch (CustomException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return "Error";
		}
	}

	/**
	 * @param reqroomId  accpets roomId from jsp
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @param request
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/makePayment") 
	public String makePayment(@RequestParam("roomId") String reqroomId,@ModelAttribute("hotelId") String reqHotelId,Model model,HttpServletRequest request){
		String view="";
		int roomId = Integer.parseInt(reqroomId);
		session=request.getSession(false);
		RoomDetailsBean room;
		try {
			room = service.getRoomById(roomId);
		
		BookingDetailsBean booking=(BookingDetailsBean) session.getAttribute("booking");
		booking.setRoom(room);
		UserBean user=(UserBean) session.getAttribute("user");
		booking.setUser(user);		
		session.setAttribute("booking", booking);			
		double payment = service.getPayment(booking);
		booking.setAmount(payment);	
		model.addAttribute("booking", booking);
		System.out.println(booking);
		view = "makePayment";
		} catch (CustomException e) {
			view = "Error";
		}
		return view;
	}

	/**
	 * @param booking accepts booking details from database
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @return Returns to the directed jsp page
	 */
	@RequestMapping("/addBook") 
	public String addBooking(Model model){
		String view="";
		BookingDetailsBean booking=(BookingDetailsBean) session.getAttribute("booking");
		try {
			booking.setBookingId(service.addBooking(booking));
			model.addAttribute("booking",booking);
			view = "Invoice";
		} 
		catch (CustomException e) {				
			e.printStackTrace();
			view="Error";
		}
		return view;
	}
	
	/**
	 * @param model Used to store and pass data between jsp and controller in string format
	 * @param reqbookingId Used to send the booking id passed as a request parameter
	 * @return
	 */
	@RequestMapping("/deleteBooking") 
	public String deleteBooking(Model model, @RequestParam("bookingId") String reqbookingId){
		String view="";
		int bookingId=Integer.parseInt(reqbookingId);
		try {
			service.deleteBooking(bookingId);
			view = "CustomerHome";
		} catch (CustomException e) {
			view = "Error";
		}
		return view;
	}
}