package com.cg.utility;


/**
 * @author usanyal
 *
 */
public class HotelBookingConstants {
	
	public static final String HOTEL = "hotel";
	public static final String REGISTER_USER = "RegisterUser";
	
	public static final int TIME_CONVERSION_FACTOR = 60*60*1000*24;
	
	
	
	
	
	
}
