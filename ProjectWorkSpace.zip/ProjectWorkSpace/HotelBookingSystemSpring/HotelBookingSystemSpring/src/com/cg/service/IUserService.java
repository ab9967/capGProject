
package com.cg.service;

import java.util.Date;
import java.util.List;

import com.cg.entities.BookingDetailsBean;
import com.cg.entities.HotelBean;
import com.cg.entities.RoomDetailsBean;
import com.cg.entities.UserBean;
import com.cg.exception.CustomException;



public interface IUserService {
	
	public UserBean validateLogin(UserBean user) throws CustomException;

	public boolean addUser(UserBean user)throws CustomException;

	public List<HotelBean> getHotelsBasedOnCriteria(int numberOfRooms,
			Date bookFrom, Date bookTo, String city) throws CustomException;
	
	public int addBooking(BookingDetailsBean booking)throws CustomException;
	
	public boolean deleteBooking(int bookingId)throws CustomException;
	public List<BookingDetailsBean> getBookingByUser(int userId)throws CustomException;
	
	
	//shared
	public BookingDetailsBean getBooking(int bookingId)throws CustomException;
	public HotelBean getHotelById(int hotelId) throws CustomException;
	public UserBean getUserByEmail(String email) throws CustomException;
	
	
	/*ADMIN FUNCTIONS*/
	
	/**
	 * @param hotel
	 * @return
	 * @throws CustomException
	 */
	public HotelBean addHotel(HotelBean hotel)throws CustomException;
	
	public int getHotelSeq()throws CustomException;
	
	public void updateHotel(HotelBean hotel) throws CustomException;
	
	public boolean removeHotel(int hotelId)throws CustomException;

	public int addRoom(RoomDetailsBean room) throws CustomException;

	public boolean updateRoom(RoomDetailsBean room)throws CustomException;

	public RoomDetailsBean getRoomById(int id)throws CustomException;

	public void removeRoom(int roomId)throws CustomException;

	public List<RoomDetailsBean> getRoomsList(int hotelId)throws CustomException;

	public double getPayment(BookingDetailsBean booking)throws CustomException;

	public List<HotelBean> getHotelList()throws CustomException;

	public List<BookingDetailsBean> getBookingByHotel(int hotelId)throws CustomException;

	public List<BookingDetailsBean> getBookingByDate(Date date)throws CustomException;

	public List<UserBean> getCustomersByHotel(int hotelId)throws CustomException;

	
}
