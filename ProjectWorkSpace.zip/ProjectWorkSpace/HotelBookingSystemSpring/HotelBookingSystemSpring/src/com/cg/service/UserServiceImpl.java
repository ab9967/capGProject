package com.cg.service;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.daos.ILoginDao;
import com.cg.daos.IUserDao;
import com.cg.entities.BookingDetailsBean;
import com.cg.entities.HotelBean;
import com.cg.entities.RoomDetailsBean;
import com.cg.entities.UserBean;
import com.cg.exception.CustomException;
import com.cg.utility.HotelBookingConstants;

@Service
@Transactional
public class UserServiceImpl implements IUserService {

	@Autowired
	private ILoginDao loginDao;
	
	@Autowired
	private IUserDao userDao;
	
	
	public UserServiceImpl() {
	}

	@Override
	public UserBean validateLogin(UserBean user)
			throws CustomException {
		
		return loginDao.validateLogin(user);
	}

	@Override
	public boolean addUser(UserBean user)
			throws CustomException {		
		return userDao.addUser(user);
	}

	@Override
	public List<HotelBean> getHotelsBasedOnCriteria(int numberOfRooms,
			Date bookFrom, Date bookTo, String city) throws CustomException {

		return userDao.getHotelsBasedOnCriteria(numberOfRooms, bookFrom, bookTo, city);
	}

	@Override
	public int addBooking(BookingDetailsBean booking) throws CustomException {
		return userDao.addBooking(booking);
	}

	@Override
	public boolean deleteBooking(int bookingId) throws CustomException {
		return userDao.deleteBooking(bookingId);
	}

	@Override
	public List<BookingDetailsBean> getBookingByUser(int userId)
			throws CustomException {
		
		return userDao.getBookingByUser(userId);
	}

	@Override
	public BookingDetailsBean getBooking(int bookingId) throws CustomException {
		
		return userDao.getBooking(bookingId);
	}

	@Override
	public HotelBean getHotelById(int hotelId) throws CustomException {
		return userDao.getHotelById(hotelId);
	}

	@Override
	public UserBean getUserByEmail(String email) throws CustomException {
		
		return userDao.getUserByEmail(email);
	}

	/* (non-Javadoc)
	 * @see com.cg.service.IUserService#addHotel(com.cg.entities.HotelBean)
	 */
	@Override
	public HotelBean addHotel(HotelBean hotel) throws CustomException {
		return userDao.addHotel(hotel);
	}

	@Override
	public int getHotelSeq() throws CustomException {
		return 0;
	}

	@Override
	public void updateHotel(HotelBean hotel)
			throws CustomException {
	
		userDao.updateHotel(hotel);
	}

	@Override
	public boolean removeHotel(int hotelId) throws CustomException {
	
		return userDao.removeHotel(hotelId);
	}

	@Override
	public int addRoom(RoomDetailsBean room) throws CustomException {
		
		return userDao.addRoom(room);
	}

	@Override
	public boolean updateRoom(RoomDetailsBean room)
			throws CustomException {
		// TODO Auto-generated method stub
		return userDao.updateRoom(room);
	}

	@Override
	public RoomDetailsBean getRoomById(int id) throws CustomException {
		
		return userDao.getRoomById(id);
	}

	@Override
	public void removeRoom(int roomId) throws CustomException {
		userDao.removeRoom(roomId);

	}

	@Override
	public List<RoomDetailsBean> getRoomsList(int hotelId)
			throws CustomException {
	
		return userDao.getRoomList(hotelId);
	}

	@Override
	public double getPayment(BookingDetailsBean booking) throws CustomException {
		
		double roomPrice = userDao.getPayment(booking.getRoom().getRoomId());
		int noOfRooms = booking.getNoOfrooms();					
		int noOfDays =(int) (((booking.getBookedTo().getTime())-(booking.getBookedFrom().getTime()))/HotelBookingConstants.TIME_CONVERSION_FACTOR);
		double payment= roomPrice*(noOfRooms)*(noOfDays);
		return payment;
	}

	@Override
	public List<HotelBean> getHotelList() throws CustomException {
		
		return userDao.getHotels();
	}

	@Override
	public List<BookingDetailsBean> getBookingByHotel(int hotelId)
			throws CustomException {
	
		return null;
	}

	@Override
	public List<BookingDetailsBean> getBookingByDate(Date date)
			throws CustomException {
		
		return getBookingByDate(date);
	}

	@Override
	public List<UserBean> getCustomersByHotel(int hotelId)
			throws CustomException {
		// TODO Auto-generated method stub
		return null;
	}

}
