create table userMP(
user_id number PRIMARY KEY, 
password varchar(7), 
role varchar(10),  
user_name varchar (20), 
mobile_no varchar(10), 
phone varchar(10), 
address varchar(25), 
email varchar(15));


select * from userMP;

drop table userMP;

insert into userMP values(1,'123','admin','Rivu','123','123','abc','abc@a.com');

create table hotelMP( 
hotel_id number PRIMARY KEY, 
city  varchar(10), 
hotel_name varchar (20), 
address varchar(25), 
description varchar(50), 
avg_rate_per_night number(6,2), 
phone_no1 varchar(10), 
phone_no2 varchar(10), 
rating varchar(4), 
email varchar(15), 
fax varchar(15));

drop table hotelMP;


create table roomDetailsMP(   
room_id number PRIMARY KEY,  
hotel_id number references hotelMP(hotel_id),
room_no varchar(3), 
room_type varchar(20), 
per_night_rate number(6,2), 
availability varchar2(5), 
photo varchar2(100));

drop table roomDetailsMP;


create table bookingDetails( 
booking_id number PRIMARY KEY, 
room_id number references roomDetailsMP(room_id),  
user_id number references userMP(user_id), 
booked_from  date, 
booked_to date, 
no_of_adults number, 
no_of_children number, 
amount number(6,2));

drop table bookingDetails;




