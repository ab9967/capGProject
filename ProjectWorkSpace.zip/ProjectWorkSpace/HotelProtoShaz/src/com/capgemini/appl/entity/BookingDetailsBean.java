package com.capgemini.appl.entity;

import java.io.Serializable;
import java.util.Date;



public class BookingDetailsBean implements Serializable{

	private static final long serialVersionUID = 1L;
	int bookingId;
	RoomDetailsBean room;  
	UserBean user;
	Date bookedFrom; 
	Date bookedTo; 
	int noOfAdults;
	int noOfChild; 
	double amount;
	public BookingDetailsBean() {
		super();
	}
	public BookingDetailsBean(int bookingId, int roomId, int userId,
			Date bookedFrom, Date bookedTo, int noOfAdults, int noOfChild,
			double amount) {
		super();
		this.bookingId = bookingId;
		this.room.setRoomId(roomId);
		this.user.setUserId(userId);
		this.bookedFrom = bookedFrom;
		this.bookedTo = bookedTo;
		this.noOfAdults = noOfAdults;
		this.noOfChild = noOfChild;
		this.amount = amount;
	}

	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public RoomDetailsBean getRoom() {
		return room;
	}
	public void setRoom(RoomDetailsBean room) {
		this.room = room;
	}

	public UserBean getUser() {
		return user;
	}
	public void setUserId(UserBean userId) {
		this.user = user;
	}
	
	public Date getBookedFrom() {
		return bookedFrom;
	}
	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}

	public Date getBookedTo() {
		return bookedTo;
	}
	public void setBookedTo(Date bookedTo) {
		this.bookedTo = bookedTo;
	}
	
	public int getNoOfAdults() {
		return noOfAdults;
	}
	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}
	
	public int getNoOfChild() {
		return noOfChild;
	}
	public void setNoOfChild(int noOfChild) {
		this.noOfChild = noOfChild;
	}

	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "BookingDetailsBean [bookingId=" + bookingId + ", roomId="
				+ room.getRoomId() + ", userId=" + user.getUserId() + ", bookedFrom=" + bookedFrom
				+ ", bookedTo=" + bookedTo + ", noOfAdults=" + noOfAdults
				+ ", noOfChild=" + noOfChild + ", amount=" + amount + "]";
	}
	
	
}
