package com.capgemini.appl.entity;

import java.io.Serializable;


// *********************INCOMPLETE***************************\

public class RoomDetailsBean implements Serializable{


	private static final long serialVersionUID = 1L;
	int hotelId;
	int roomId;
	String roomNo;
	String roomType;
	double perNightRate;
	boolean availability;
	//photo (blob);
	public RoomDetailsBean() {
		super();
	}
	
	public RoomDetailsBean(int hotelId, int roomId, String roomNo,
			String roomType, double perNightRate, boolean availability) {
		super();
		this.hotelId = hotelId;
		this.roomId = roomId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.perNightRate = perNightRate;
		this.availability = availability;
	}
	
	//parameterized Constructor with Photo
	
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	
	public int getRoomId() {
		return roomId;
	}
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	
	public String getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}
	
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	
	public double getPerNightRate() {
		return perNightRate;
	}
	public void setPerNightRate(double perNightRate) {
		this.perNightRate = perNightRate;
	}
	
	public boolean isAvailability() {
		return availability;
	}
	public void setAvailability(boolean availability) {
		this.availability = availability;
	}
	
	//Getter setter for photo type	
	
	@Override
	public String toString() {
		return "RoomDetailsBean [hotelId=" + hotelId + ", roomId=" + roomId
				+ ", roomNo=" + roomNo + ", roomType=" + roomType
				+ ", perNightRate=" + perNightRate + ", availability="
				+ availability + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + roomId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RoomDetailsBean other = (RoomDetailsBean) obj;
		if (roomId != other.roomId)
			return false;
		return true;
	}


	
	
	
}
