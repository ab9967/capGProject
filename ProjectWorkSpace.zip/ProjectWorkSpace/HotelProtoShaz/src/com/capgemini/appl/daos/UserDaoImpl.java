package com.capgemini.appl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import javax.sql.DataSource;

import com.capgemini.appl.entity.BookingDetailsBean;
import com.capgemini.appl.entity.HotelBean;
import com.capgemini.appl.entity.RoomDetailsBean;
import com.capgemini.appl.entity.UserBean;
import com.capgemini.appl.exception.CustomException;
import com.capgemini.appl.util.DBUtil;


public class UserDaoImpl implements IUserDao{
	 
	DataSource dataSource;
	Connection connection;
	
	public UserDaoImpl() {
		
	}

	//userfunction
	@Override
	public boolean addUser(UserBean user) throws CustomException{
		
		dataSource=DBUtil.getDataSource();
		
		try{
			connection=dataSource.getConnection();
			
			
			String sql="INSERT INTO userMP VALUES(?,?,?,?,?,?,?,?)";
			PreparedStatement pstm=connection.prepareStatement(sql);
			pstm.setInt(1, user.getUserId());
			pstm.setString(2, user.getPassword());
			pstm.setString(3, user.getRole());
			pstm.setString(4, user.getUserName());
			pstm.setString(5, user.getMobileNo());
			pstm.setString(6, user.getPhone());
			pstm.setString(7, user.getAddress());
			pstm.setString(8, user.getEmail());
			
			pstm.execute();
			return true;
			
		}catch(SQLException e)
		{
			e.printStackTrace();
			System.out.println("Exception occured");
			throw new CustomException(e.getMessage());
		}finally{
			if(connection!=null)
			{
				try{
					connection.close();
				}catch(SQLException e)
				{
					e.printStackTrace();
					throw new RuntimeException();
				}
			}
		}
		
	}

	//userFunction
	@Override
	public List<HotelBean> getHotelsBasedOnCriteria(int numberOfRooms,
			Date bookFrom, Date bookTo, String city) throws CustomException {
	
dataSource=DBUtil.getDataSource();
		
		try{
			connection=dataSource.getConnection();
			
			
			String sql="SELECT * FROM hotelMP  WHERE city = ? and h.hotel_id IN (SELECT hotelId from roomDetailsMP group by hotelId having count(hotelId > ?) ";
			PreparedStatement pstm=connection.prepareStatement(sql);
			pstm.setString(1, city);
			pstm.setInt(2, numberOfRooms);
			List<HotelBean> hotelList=new ArrayList<>();
			
			ResultSet rs=pstm.executeQuery();
			while(rs.next())
			{
				HotelBean hoteltemp=new HotelBean();
				hoteltemp.setHotelId(rs.getInt("hotel_id"));
				hoteltemp.setHotelName(rs.getString("hotel_name"));
				hoteltemp.setCity(rs.getString("city"));
				hoteltemp.setAddress(rs.getString("address"));
				hoteltemp.setDescription(rs.getString("description"));
				hoteltemp.setAvgRatePerNight(rs.getDouble("avg_rate_per_night"));
				hoteltemp.setPhoneNo1(rs.getString("phone_no1"));
				hoteltemp.setPhoneNo2(rs.getString("phone_no2"));
				hoteltemp.setRating(rs.getString("rating"));
				hoteltemp.setEmail(rs.getString("email"));
				hoteltemp.setFax(rs.getString("fax"));
				hotelList.add(hoteltemp);				
			}
			
			return hotelList;
			
		}catch(SQLException e)
		{
			e.printStackTrace();
			System.out.println("Exception occured");
			throw new CustomException(e.getMessage());
		}finally{
			if(connection!=null)
			{
				try{
					connection.close();
				}catch(SQLException e)
				{
					e.printStackTrace();
					throw new RuntimeException();
				}
			}
		}	
	}//end of funtion getHotelsbasedoncriteria

	@Override
	public boolean addBooking(BookingDetailsBean booking)
			throws CustomException {
			dataSource=DBUtil.getDataSource();
		
		try{
			connection=dataSource.getConnection();
			
			
			String sql="INSERT INTO bookingDetails VALUES(//nextval,?,?,?,?,?,?,?)";
			PreparedStatement pstm=connection.prepareStatement(sql);
			pstm.setInt(1, booking.getRoom().getRoomId());
			pstm.setInt(2, booking.getUser().getUserId());
			java.sql.Date bookedFrom=new java.sql.Date(booking.getBookedFrom().getTime());
			pstm.setDate(3, bookedFrom);
			java.sql.Date bookedTo=new java.sql.Date(booking.getBookedTo().getTime());
			pstm.setDate(4, bookedTo);
			pstm.setInt(5, booking.getNoOfAdults());
			pstm.setInt(6, booking.getNoOfChild());
			pstm.setDouble(7, booking.getAmount());
			
			pstm.execute();
			return true;
			
		}catch(SQLException e)
		{
			e.printStackTrace();
			System.out.println("Exception occured");
			throw new CustomException(e.getMessage());
		}finally{
			if(connection!=null)
			{
				try{
					connection.close();
				}catch(SQLException e)
				{
					e.printStackTrace();
					throw new RuntimeException();
				}
			}
		}
		
		
		
		
	}

	@Override
	public boolean deleteBooking(int bookingId) throws CustomException {
		
		dataSource=DBUtil.getDataSource();
		
		try{
			connection=dataSource.getConnection();
			
			
			String sql="DELETE FROM bookingDetails WHERE booking_id=?";
			PreparedStatement pstm=connection.prepareStatement(sql);
			pstm.setInt(1, bookingId);			
			pstm.executeUpdate();
			return true;
			
		}catch(SQLException e)
		{
			e.printStackTrace();
			System.out.println("Exception occured");
			throw new CustomException(e.getMessage());
		}finally{
			if(connection!=null)
			{
				try{
					connection.close();
				}catch(SQLException e)
				{
					e.printStackTrace();
					throw new RuntimeException();
				}
			}
		}
	}	// end of deleteBooking

	@Override
	public BookingDetailsBean getBooking(int bookingId) throws CustomException {
dataSource=DBUtil.getDataSource();
		
		try{
			connection=dataSource.getConnection();
			
			String sql="SELECT * FROM bookingDetails WHERE booking_id=?";
			PreparedStatement pstm=connection.prepareStatement(sql);
			pstm.setInt(1, bookingId);	
			
			ResultSet rs=pstm.executeQuery();
			
			if(rs.next())
			{
				BookingDetailsBean booking=new BookingDetailsBean();
				booking.setBookingId(rs.getInt("booking_id"));
				RoomDetailsBean room=new RoomDetailsBean();
				room.setRoomId(rs.getInt("room_id"));
				booking.setRoom(room);
				UserBean user=new UserBean();
				user.setUserId(rs.getInt("user_id"));
				booking.setUserId(user);
				booking.setBookedFrom(new Date(rs.getDate("booked_from ").getTime()));
				booking.setBookedTo(new Date(rs.getDate("booked_to").getTime()));
				booking.setNoOfAdults(rs.getInt("no_of_adults"));
				booking.setNoOfChild(rs.getInt("no_of_children"));
				booking.setAmount(rs.getDouble("amount"));		
				
				return booking;
			}
			else
				throw new CustomException("Cant Get Booking");
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			System.out.println("Exception occured");
			throw new CustomException(e.getMessage());
		}
		finally
		{
			if(connection!=null)
			{
				try{
					connection.close();
				}catch(SQLException e)
				{
					e.printStackTrace();
					throw new RuntimeException();
				}
			}
		}
		
	}

	

	@Override
	public boolean addHotel(HotelBean hotel) throws CustomException {
         
		dataSource=DBUtil.getDataSource();
		
		try
		{
			connection=dataSource.getConnection();
			String sql="INSERT INTO hotelMP VALUES(//nextval,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstm=connection.prepareStatement(sql);
			
			pstm.setString(1, hotel.getCity());
			pstm.setString(2, hotel.getHotelName());
			pstm.setString(3, hotel.getAddress());
			pstm.setString(4, hotel.getDescription());
		    pstm.setDouble(5, hotel.getAvgRatePerNight());
			pstm.setString(6, hotel.getPhoneNo1());
			pstm.setString(7, hotel.getPhoneNo2());
			pstm.setString(8, hotel.getRating());
			pstm.setString(9, hotel.getEmail());
			pstm.setString(10, hotel.getFax());
			
			pstm.execute();
			return true;
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			System.out.println("Exception occured");
			throw new CustomException(e.getMessage());
		}
		finally
		{
			if(connection!=null)
			{
				try
				{
					connection.close();
				}
				catch(SQLException e)
				{
					e.printStackTrace();
					throw new RuntimeException();
				}
			}
		}
		
	}

	@Override
	public boolean updateHotel(HotelBean hotel) throws CustomException {
		
		
	
		dataSource=DBUtil.getDataSource();
		try {
			
			connection=dataSource.getConnection();
			String sql = "update hotelMP set city =?,hotel_name=?,address=?,description=?, avg_rate_per_night=?,phone_no1=?,phone_no2=?, rating=?,email=?,fax=? where hotel_id=?";
			PreparedStatement pstm = connection.prepareStatement(sql);
			
			pstm.setString(1, hotel.getCity());
			pstm.setString(2, hotel.getHotelName());
			pstm.setString(3, hotel.getAddress());	
			pstm.setString(4, hotel.getDescription());
			pstm.setDouble(5, hotel.getAvgRatePerNight());
			pstm.setString(6, hotel.getPhoneNo1());
			pstm.setString(7, hotel.getPhoneNo2());
			pstm.setString(8, hotel.getRating());
			pstm.setString(9, hotel.getEmail());
			pstm.setString(10, hotel.getFax());
			pstm.setInt(11, hotel.getHotelId());
			
			pstm.executeUpdate();	
			return true;
		}catch(Exception e) {			
			//e.printStackTrace();
			throw new CustomException("Connection not Established");
		}finally{
			if(connection!=null){
				try {
					connection.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}

	@Override
	public boolean removeHotel(int hotelId) throws CustomException
	{
        dataSource=DBUtil.getDataSource();
		 try 
		{
			connection=dataSource.getConnection();
			String sql="DELETE FROM hotelMP WHERE hotel_id=?";
			PreparedStatement pstm=connection.prepareStatement(sql);
			pstm.setInt(1, hotelId);			
			pstm.executeUpdate();
			return true;
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			System.out.println("Exception occured");
			throw new CustomException(e.getMessage());
		}
		finally
		{
			if(connection!=null)
			{
				try{
					connection.close();
				}catch(SQLException e)
				{
					e.printStackTrace();
					throw new RuntimeException();
				}
			}
		}
		
	}
	
	
	
	
	/*ADMIN FUNCTIONS*/
	
	
	
	
	
	
	

}
