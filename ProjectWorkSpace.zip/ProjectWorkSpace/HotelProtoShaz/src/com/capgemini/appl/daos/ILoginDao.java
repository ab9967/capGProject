package com.capgemini.appl.daos;

import com.capgemini.appl.exception.CustomException;

public interface ILoginDao {

	String validateLogin(String userName, String password) throws CustomException;

}
