package com.capgemini.appl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.capgemini.appl.exception.CustomException;
import com.capgemini.appl.util.DBUtil;

public class LoginDaoImpl implements ILoginDao {

	private DataSource dataSource;
	private Connection connection;
	
	@Override
	public String validateLogin(String userName, String password) throws CustomException{
		
		dataSource=DBUtil.getDataSource();
		
		try{
			
			connection=dataSource.getConnection();
			
			String sql="Select * from userMP where user_id=? and password=?";
			
			PreparedStatement pstm=connection.prepareStatement(sql);
			pstm.setString(1, userName);
			pstm.setString(2, password);
			
			ResultSet rs=pstm.executeQuery();
			if(rs.next())
				{return rs.getString("role");
				}
			else	throw new CustomException("User Not found");
			
		}catch(SQLException e)
		{
			e.printStackTrace();
			throw new CustomException("Something went wrong while logging in");
		}finally
		{
			if(connection!=null)
			{
				try {
					connection.close();
				} catch (SQLException e) {					
					e.printStackTrace();
					throw new RuntimeException();
				}
			}
		}
		
	}
	
	

}
