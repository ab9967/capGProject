package com.capgemini.appl.util;



import java.util.ResourceBundle;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
//factory class
//Singleton
public class DBUtil {
	private static DataSource dataSource;
	
	public static DataSource getDataSource(){
		if(dataSource==null)
		{	
			ResourceBundle bundle=ResourceBundle.getBundle("resources/jndi");
			InitialContext context;
			
			try {
				
				context=new InitialContext();
				dataSource=(DataSource) context.lookup(bundle.getString("jndi"));
				//dataSource=(DataSource) context.lookup("java:jboss/datasources/myDS");
			} catch (NamingException e) {
				e.printStackTrace();
			}
		}
		return dataSource;
	}
}