package com.capgemini.appl.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.appl.entity.HotelBean;
import com.capgemini.appl.entity.UserBean;
import com.capgemini.appl.exception.CustomException;
import com.capgemini.appl.services.IUserService;
import com.capgemini.appl.services.UserServiceImpl;





@WebServlet("*.do")
public class ProcessController extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	private IUserService service;   
	HttpSession session;

	//Init method override for creating a single object of the service layer that will be used for all the MVC process calls
	@Override
	public void init() throws ServletException {
		service=new UserServiceImpl();
		super.init();
		
	}



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	
	
	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		String value=request.getRequestURI();
		String action=value.substring(value.lastIndexOf("/"),value.length());
		session=request.getSession();
		
		switch (action) {
		
		case "/loginform.do" :	//start of loginform.do
		{
			response.sendRedirect("/HotelProtoShaz/view/Login.jsp");
			break;
		}//end of loginform.do
		
		
		case "/login.do" : 
		{
			String userName=request.getParameter("userName");
			String password=request.getParameter("password");
			String role;
			try {
				role =service.validateLogin(userName,password);
				if(role.equalsIgnoreCase("customer"))	//Validating and login user (true if valid and redirect)(false goto login page)
				{
					//set the username in session and redirect
					
					response.sendRedirect("/HotelProtoShaz/view/ViewHotel.jsp");
				}
				else if (role.equalsIgnoreCase("admin"))
				
				{
					response.sendRedirect("/HotelProtoShaz/view/AdminHome.jsp");
				}
				else
					response.sendRedirect("/HotelProtoShaz/view/Login.jsp");
					
			} catch (CustomException e) {				
				e.printStackTrace();
				throw new ServletException(e.getMessage(),e);
			}
			break;	
		}
		
		case "/registerUserForm.do" : 
		{
			response.sendRedirect("/HotelProtoShaz/view/RegisterUser.jsp");			
			break;	
		}
		
case "/register.do" : {
			
			
			String userName=request.getParameter("userName");
			String mobileNumber=request.getParameter("mobileNumber");
			String role=request.getParameter("role");
			String password=request.getParameter("password");
			String phone=request.getParameter("phone");
			String address=request.getParameter("address");
			String email=request.getParameter("email");
			
			try {
				if(service.addUser(userName,mobileNumber,role,password,phone,address,email))
				{	
					session.setAttribute("userName",userName);
					response.sendRedirect("/HotelProtoShaz/view/searchHotel.jsp");// to search hotel
				}
				else{
					response.sendRedirect(""); //login.jsp
				}
			} catch (CustomException e) {
				
				e.printStackTrace();
				throw new ServletException(e.getMessage(),e);
			}
			break;
		}
		case "/searchHotel.do" :{
				int numberOfRooms=Integer.parseInt(request.getParameter(""));
				int numberOfAdult=Integer.parseInt(request.getParameter(""));
				int numberOfChild=Integer.parseInt(request.getParameter(""));
				String city=request.getParameter("");
				SimpleDateFormat format=new SimpleDateFormat("DD-MM-YYYY");
				
				Date bookFrom=new Date();
				Date bookTo=new Date();
				try {
					bookFrom = format.parse(request.getParameter("bookFrom"));
					bookTo = format.parse(request.getParameter("bookTo"));
				} catch (ParseException e) {
					
					e.printStackTrace();
				}
				
				
				
				/*session.setAttribute("numberOfRooms",numberOfRooms);
				session.setAttribute("numberOfAdult",numberOfAdult);
				session.setAttribute("numberOfChild",numberOfChild);
				session.setAttribute("bookTo",bookTo);
				session.setAttribute("bookFrom",bookFrom);
				session.setAttribute("city",city);*/
				
				try {
					List<HotelBean> hotelList=service.getHotelsBasedOnCriteria(numberOfRooms,bookFrom,bookTo,city);
					session.setAttribute("hotelList", hotelList);
					response.sendRedirect("/HotelProtoShaz/view/ViewHotel.jsp"); //to view hotels
				} catch (CustomException e) {
					e.printStackTrace();
					throw new ServletException(e.getMessage(),e);
				}
				 
			break;
		}
		
		case "/viewHotels.do" :{
			//get hotelId from viewHotel.jsp
			//get hotel + room details from database
			//set the details in session 
			
			response.sendRedirect("/HotelProtoShaz/view/HotelDetails.jsp");	//create HotelDetails.jsp
			
			
			break;
		}
		
		case "/bookRoomForm.do": {
			
			response.sendRedirect("/HotelProtoShaz/view/BookRooms.jsp");
			break;
		}
		
		case "/bookRoom.do": {
			
			//take details from bookingForm and insert into bookingDetails table
			//fetch booking details from bookingDetails table 
			//set bookingdetails into session
			response.sendRedirect("/HotelProtoShaz/view/Invoice.jsp");
			break;
		}
		
		case "/addHotelForm.do": {
			
			
			response.sendRedirect("/HotelProtoShaz/view/AddHotelForm.jsp");
			break;
		}
		
		case "/addHotel.do": {
			
			//take details from addHotelForm and insert into hotelMP table
			response.sendRedirect("/HotelProtoShaz/view/showHotel.jsp");
			break;
		}
		
		case "/updateHotelForm.do": {
			
			
			response.sendRedirect("/HotelProtoShaz/view/UpdateHotelForm.jsp");
			break;
		}
		
		case "/updateHotel.do": {
			
			//take details from hotelUpdateForm  and update into hotelMP table
			//and set it on session and redirect it to showHotel.jsp 
			response.sendRedirect("/HotelProtoShaz/view/showHotel.jsp");
			break;
		}
		
		case "/fetchHotel.do": {
			
			//take hotelId from updateHotelForm then fetch hotelDetails from database
			//and set it on session and redirect it to updateHotelForm
			response.sendRedirect("/HotelProtoShaz/view/UpdateHotelForm.jsp");
			break;
		}
		
		case "/deleteHotelForm.do": {
			
			
			response.sendRedirect("/HotelProtoShaz/view/DeleteHotelForm.jsp");
			break;
		}
		
		case "/fetchHotelDelete.do": {
			
			//take hotelId from deleteHotelForm then fetch hotelDetails from database
			//and set it on session and redirect it to deleteHotelForm
			response.sendRedirect("/HotelProtoShaz/view/deleteHotelForm.jsp");
			break;
		}
		
		case "/deleteHotel.do": {
			
			//take details from deleteHotelForm and delete it from hotelMP table
			response.sendRedirect("/HotelProtoShaz/view/AdminHome.jsp");
			break;
		}
		
		
		//Test case ignore for now
		/*case "/abc.do":{
			UserBean user=new UserBean(100, "12345", "customer", "arai", "9874563120", "1234567890", "Shivaji Nagar", "arai@gmail.com");
			service.addUser(user);
			response.getWriter().print("User "+user.toString()+" added");
			break;
		}*/
		default:
			break;
		}
		
	}
	

}
