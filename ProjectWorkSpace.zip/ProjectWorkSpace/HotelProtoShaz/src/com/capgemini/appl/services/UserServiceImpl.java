package com.capgemini.appl.services;

import java.util.Date;
import java.util.List;

import com.capgemini.appl.daos.ILoginDao;
import com.capgemini.appl.daos.IUserDao;
import com.capgemini.appl.daos.LoginDaoImpl;
import com.capgemini.appl.daos.UserDaoImpl;
import com.capgemini.appl.entity.BookingDetailsBean;
import com.capgemini.appl.entity.HotelBean;
import com.capgemini.appl.entity.UserBean;
import com.capgemini.appl.exception.CustomException;
import com.capgemini.appl.factory.ProcessFactory;

public class UserServiceImpl implements IUserService{
	private IUserDao dao;
	
	private ProcessFactory factory;	
	public UserServiceImpl() {
		super();
		dao=new UserDaoImpl();
		factory=new ProcessFactory();
	}



	



	@Override
	public String validateLogin(String userName, String password) throws CustomException {
		ILoginDao loginDao = new LoginDaoImpl();	
		
		return loginDao.validateLogin(userName,password);
	}



	@Override
	public boolean addUser(String userName,
			String mobileNumber, String role, String password, String phone,
			String address, String email) throws CustomException {
		UserBean user=factory.createUser(password, role, userName, mobileNumber, address);
		return dao.addUser(user);
	}







	@Override
	public List<HotelBean> getHotelsBasedOnCriteria(int numberOfRooms,
			Date bookFrom, Date bookTo, String city) throws CustomException {
		
		return dao.getHotelsBasedOnCriteria(numberOfRooms,
				bookFrom, bookTo, city);
	}







	@Override
	public boolean addBooking(BookingDetailsBean booking)
			throws CustomException {
		
		return dao.addBooking(booking);
	}







	@Override
	public boolean deleteBooking(int bookingId) throws CustomException {
		
		return dao.deleteBooking(bookingId);
	}







	@Override
	public BookingDetailsBean getBooking(int bookingId) throws CustomException {
	
		return dao.getBooking(bookingId);
	}







	@Override
	public boolean addHotel(HotelBean hotel) throws CustomException {
		
		return dao.addHotel(hotel);
	}







	@Override
	public boolean updateHotel(HotelBean hotel) throws CustomException {
	
		return dao.updateHotel(hotel);
	}







	@Override
	public boolean removeHotel(int hotelId) throws CustomException {
	
		return dao.removeHotel(hotelId);
	}

}
