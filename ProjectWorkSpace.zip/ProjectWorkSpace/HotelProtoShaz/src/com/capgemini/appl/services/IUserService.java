package com.capgemini.appl.services;

import java.util.Date;
import java.util.List;

import com.capgemini.appl.entity.BookingDetailsBean;
import com.capgemini.appl.entity.HotelBean;
import com.capgemini.appl.entity.UserBean;
import com.capgemini.appl.exception.CustomException;

public interface IUserService {
	
	public String validateLogin(String userName, String password) throws CustomException;

	public boolean addUser(String userName,
			String mobileNumber, String role, String password, String phone,
			String address, String email)throws CustomException;

	public List<HotelBean> getHotelsBasedOnCriteria(int numberOfRooms,
			Date bookFrom, Date bookTo, String city) throws CustomException;
	
	public boolean addBooking(BookingDetailsBean booking)throws CustomException;
	
	public boolean deleteBooking(int bookingId)throws CustomException;
	
	
	//shared
	public BookingDetailsBean getBooking(int bookingId)throws CustomException;
	
	
	
	/*ADMIN FUNCTIONS*/
	
	public boolean addHotel(HotelBean hotel)throws CustomException;
	
	public boolean updateHotel(HotelBean hotel) throws CustomException;
	
	public boolean removeHotel(int hotelId)throws CustomException;
}
