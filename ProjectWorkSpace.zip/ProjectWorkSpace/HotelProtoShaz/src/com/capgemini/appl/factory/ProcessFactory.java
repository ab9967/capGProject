package com.capgemini.appl.factory;

import java.util.Date;

import com.capgemini.appl.entity.BookingDetailsBean;
import com.capgemini.appl.entity.HotelBean;
import com.capgemini.appl.entity.RoomDetailsBean;
import com.capgemini.appl.entity.UserBean;

public class ProcessFactory {

	//Create user with all the attributes
	public UserBean createUser(int userId, String password, String role,
			String userName, String mobileNo, String phone, String address,
			String email)
	{
		return new UserBean(userId, password, role, userName, mobileNo, phone, address, email);
		
	}
	//create user without phone and email address
	public UserBean createUser(int userId, String password, String role,
			String userName, String mobileNo, String address)
	{
		UserBean user=new UserBean();
		user.setUserId(userId);
		user.setPassword(password);
		user.setRole(role);
		user.setUserName(userName);
		user.setMobileNo(mobileNo);
		user.setAddress(address);
		return user;		
	}
	
	public UserBean createUser(String password, String role,
			String userName, String mobileNumber, String address) {
		UserBean user=new UserBean();
		
	
		user.setPassword(password);
		user.setRole(role);
		user.setUserName(userName);
		user.setMobileNo(mobileNumber);
		user.setAddress(address);
		return user;
	}
	
	//create room details with all attributes
	public RoomDetailsBean createRoom(int hotelId, int roomId, String roomNo,
			String roomType, double perNightRate, boolean availability)
	{
		return new RoomDetailsBean(hotelId,roomId,roomNo,roomType,perNightRate,availability);
	}
	//create hotel with all the attributes
	public HotelBean createHotel(int hotelId, String city, String hotelName,
			String address, String description, double avgRatePerNight,
			String phoneNo1, String phoneNo2, String rating, String email,
			String fax){
		return new HotelBean(hotelId,city,hotelName,address,description,avgRatePerNight,phoneNo1,phoneNo2,rating,email,fax);
	}
	//create hotel without phone2
	public HotelBean createHotel(int hotelId, String city, String hotelName,
			String address, String description, double avgRatePerNight,
			String phoneNo1,  String rating, String email,
			String fax){
		
		HotelBean hotel=new HotelBean();
		hotel.setHotelId(hotelId);
		hotel.setCity(city);
		hotel.setHotelName(hotelName);
		hotel.setAddress(address);
		hotel.setDescription(description);
		hotel.setAvgRatePerNight(avgRatePerNight);
		hotel.setPhoneNo1(phoneNo1);
		hotel.setRating(rating);
		hotel.setEmail(email);
		hotel.setFax(fax);
		return hotel;
	}
	
	//create hotel without description
	
	//create hotel without rating
	
	//create hotel without fax
	
	//create booking with all the attributes
	public BookingDetailsBean createBooking(int bookingId, int roomId, int userId,
			Date bookedFrom, Date bookedTo, int noOfAdults, int noOfChild,
			double amount){
		
		return new BookingDetailsBean(bookingId,roomId,userId,bookedFrom,bookedTo,noOfAdults,noOfChild,amount);
	}
	
}
