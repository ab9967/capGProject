package com.cg.appl.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity(name="book")
@Table(name="Booking_Details")
@NamedQueries({
@NamedQuery(name="qryAllBooking", query = "select h from book h"),
@NamedQuery(name="qryHotelwiseBooking", query = "select b from book b where room_id in (select r.room_id from roomDetails r where r.hotel.hotel_id= :hid)")
})
@SequenceGenerator(name = "book_generate", sequenceName = "seq_booking_Id" , allocationSize=1, initialValue=8004)

public class BookingDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	private String booking_id;
	//private String room_id;
	//private String user_id;
	private Date booked_from;
	private Date booked_to;
	private int no_of_adults;
	private int no_of_children;
	private int amount;
	//private String hotel_id;
	//private Users user;
	private Hotel hotel;
	private Users user;
	private RoomDetails room;
	public BookingDetails() {
		super();
	}
	
	
	@Id
	@Column(name="booking_id")
	@GenericGenerator(name = "book_generate", strategy = "com.cg.appl.identifierGeneration.StringSequenceGenerator")
	@GeneratedValue(generator="book_generate", strategy = GenerationType.SEQUENCE)
	public String getBooking_id() {
		return booking_id;
	}
	public void setBooking_id(String booking_id) {
		this.booking_id = booking_id;
	}
	
	/*@Column(name="room_id")
	public String getRoom_id() {
		return room_id;
	}
	public void setRoom_id(String room_id) {
		this.room_id = room_id;
	}*/
	
	/*@Column(name="user_id")
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	*/
	@Column(name="booked_from")
	public Date getBooked_from() {
		return booked_from;
	}
	public void setBooked_from(Date booked_from) {
		this.booked_from = booked_from;
	}
	
	@Column(name="booked_to")
	public Date getBooked_to() {
		return booked_to;
	}
	public void setBooked_to(Date booked_to) {
		this.booked_to = booked_to;
	}
	
	@Column(name="no_of_adults")
	public int getNo_of_adults() {
		return no_of_adults;
	}
	public void setNo_of_adults(int no_of_adults) {
		this.no_of_adults = no_of_adults;
	}
	
	@Column(name="no_of_children")
	public int getNo_of_children() {
		return no_of_children;
	}
	public void setNo_of_children(int no_of_children) {
		this.no_of_children = no_of_children;
	}
	
	@Column(name="amount")
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	/*@Column(name="")
	public Users getUser() {
		return user;
	}
	public void setUser(Users user) {
		this.user = user;
	}*/
	
	/*@Column(name="hotel_id")
	public String getHotel_id() {
		return hotel_id;
	}
	public void setHotel_id(String hotel_id) {
		this.hotel_id = hotel_id;
	}*/

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="hotel_id")
	public Hotel getHotel() {
		return hotel;
	}
	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="user_id")
	public Users getUser() {
		return user;
	}
	public void setUser(Users user) {
		this.user = user;
	}
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="room_id")
	public RoomDetails getRoom() {
		return room;
	}
	public void setRoom(RoomDetails room) {
		this.room = room;
	}


	@Override
	public String toString() {
		return "BookingDetails [booking_id=" + booking_id + ", booked_from="
				+ booked_from + ", booked_to=" + booked_to + ", no_of_adults="
				+ no_of_adults + ", no_of_children=" + no_of_children
				+ ", amount=" + amount + ", hotel=" + hotel + ", user=" + user
				+ ", room=" + room + "]";
	}


	
		
	
	

}
