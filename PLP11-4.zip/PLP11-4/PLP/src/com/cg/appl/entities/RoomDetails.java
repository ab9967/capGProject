package com.cg.appl.entities;

import java.io.Serializable;
import java.sql.Blob;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;
@Entity(name="roomDetails")
@Table(name="ROOM_DETAILS")
@NamedQueries({

@NamedQuery(name="qryRoomOnIds", query = "select r from roomDetails r where hotel_id is :hotelid and room_id is :roomid"),
@NamedQuery(name="checkAvailability", query = " select distinct r from roomDetails r, book b  where r.hotel.hotel_id=:hotelid and b.booked_from not between :userFrmDate and :userToDate and b.booked_to not between :userFrmDate and :userToDate"),
//@NamedQuery(name="checkAvailability2",query="select distinct r.room_id  from booking_details b,room_details r where r.hotel.hotel_id=:hotelID1 and r.hotel.room_id NOT IN (select b.room_id from booking_details b,room_details r where r.room_id!=b.room_id and b.hotel_id=:hotelID2)"),
@NamedQuery(name="qryAllRooms", query = "select r from roomDetails r")
})
@SequenceGenerator(name = "room_generate", sequenceName = "room_id_seq" , allocationSize=1, initialValue=3013)
public class RoomDetails implements Serializable{
	
	private static final long serialVersionUID = 1L;
	//private String hotel_id;
	private String room_id;
	private String room_no;
	private String room_type;
	private int per_night_rate;
	private int availability;
	private String photo;
	private Hotel hotel;
	private BookingDetails book;
	public RoomDetails() {
		super();
	}
	public RoomDetails(/*String hotel_id, */String room_id, String room_no,
			String room_type, int per_night_rate, int availability, String photo) {
		super();
//		this.hotel_id = hotel_id;
		this.room_id = room_id;
		this.room_no = room_no;
		this.room_type = room_type;
		this.per_night_rate = per_night_rate;
		this.availability = availability;
		this.photo = photo;
	}
	/*@Column(name="hotel_id")
	public String getHotel_id() {
		return hotel_id;
	}
	public void setHotel_id(String hotel_id) {
		this.hotel_id = hotel_id;
	}*/
	@Id
	@Column(name="room_id")
	@GenericGenerator(name = "room_generate", strategy = "com.cg.appl.identifierGeneration.StringSequenceGenerator")
	@GeneratedValue(generator="room_generate", strategy = GenerationType.SEQUENCE)
	public String getRoom_id() {
		return room_id;
	}
	public void setRoom_id(String room_id) {
		this.room_id = room_id;
	}
	@Column(name="room_no")
	@Size(min=1,max=3,message="roomno should be 1-3 characters")
	public String getRoom_no() {
		return room_no;
	}
	public void setRoom_no(String room_no) {
		this.room_no = room_no;
	}
	@Column(name="room_type")
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	@Column(name="per_night_rate")
	@NotNull(message="avg_rate_per_night is required")
	@Max(value=9999, message="Price Per night should be ranging from 500 - 9999")
	@Min(value=500, message="Price Per night should be ranging from 500 - 9999")
	public int getPer_night_rate() {
		return per_night_rate; 
	}
	public void setPer_night_rate(int per_night_rate) {
		this.per_night_rate = per_night_rate;
	}
	@Column(name="availability")
	@Max(value=1, message="Availability should be either 0 or 1")
	@Min(value=0, message="Availability should be either 0 or 1")
	public int getAvailability() {
		return availability;
	}
	public void setAvailability(int availability) {
		this.availability = availability;
	}
	@Column(name="photo")
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	@OneToOne(cascade=CascadeType.ALL)
	//#############################
	@JoinColumn(name="hotel_id")
	public Hotel getHotel() {
		return hotel;
	}
	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}
	@OneToOne(mappedBy="room")
	public BookingDetails getBook() {
		return book;
	}
	public void setBook(BookingDetails book) {
		this.book = book;
	}
	@Override
	public String toString() {
		return "RoomDetails [ room_id=" + room_id
				+ ", room_no=" + room_no + ", room_type=" + room_type
				+ ", per_night_rate=" + per_night_rate + ", availability="
				+ availability + ", photo=" + photo + "]";
	}	
}

/*package com.cg.appl.entities;

import java.io.Serializable;
import java.sql.Blob;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity(name="roomDetails")
@Table(name="ROOM_DETAILS")
@NamedQueries({

@NamedQuery(name="qryRoomOnIds", query = "select r from roomDetails r where hotel_id is :hotelid and room_id is :roomid"),
@NamedQuery(name="checkAvailability", query = " select distinct r from roomDetails r, book b  where r.hotel.hotel_id=:hotelid and b.booked_from not between :userFrmDate and :userToDate and b.booked_to not between :userFrmDate and :userToDate"),
@NamedQuery(name="qryAllRooms", query = "select r from roomDetails r")
})
@SequenceGenerator(name = "room_generate", sequenceName = "room_id_seq" , allocationSize=1, initialValue=3013)
public class RoomDetails implements Serializable{
	
	private static final long serialVersionUID = 1L;
	//private String hotel_id;
	private String room_id;
	private String room_no;
	private String room_type;
	private int per_night_rate;
	private int availability;
	private String photo;
	private Hotel hotel;
	private BookingDetails book;
	public RoomDetails() {
		super();
	}
	public RoomDetails(String hotel_id, String room_id, String room_no,
			String room_type, int per_night_rate, int availability, String photo) {
		super();
//		this.hotel_id = hotel_id;
		this.room_id = room_id;
		this.room_no = room_no;
		this.room_type = room_type;
		this.per_night_rate = per_night_rate;
		this.availability = availability;
		this.photo = photo;
	}
	@Column(name="hotel_id")
	public String getHotel_id() {
		return hotel_id;
	}
	public void setHotel_id(String hotel_id) {
		this.hotel_id = hotel_id;
	}
	@Id
	@Column(name="room_id")
	@GenericGenerator(name = "room_generate", strategy = "com.cg.appl.identifierGeneration.StringSequenceGenerator")
	@GeneratedValue(generator="room_generate", strategy = GenerationType.SEQUENCE)

	public String getRoom_id() {
		return room_id;
	}
	public void setRoom_id(String room_id) {
		this.room_id = room_id;
	}
	@Column(name="room_no")
	public String getRoom_no() {
		return room_no;
	}
	public void setRoom_no(String room_no) {
		this.room_no = room_no;
	}
	@Column(name="room_type")
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	@Column(name="per_night_rate")
	public int getPer_night_rate() {
		return per_night_rate; 
	}
	public void setPer_night_rate(int per_night_rate) {
		this.per_night_rate = per_night_rate;
	}
	@Column(name="availability")
	public int getAvailability() {
		return availability;
	}
	public void setAvailability(int availability) {
		this.availability = availability;
	}
	@Column(name="photo")
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	@OneToOne(cascade=CascadeType.ALL)
	//#############################
	@JoinColumn(name="hotel_id")
	public Hotel getHotel() {
		return hotel;
	}
	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}
	@OneToOne(mappedBy="room")
	public BookingDetails getBook() {
		return book;
	}
	public void setBook(BookingDetails book) {
		this.book = book;
	}
	@Override
	public String toString() {
		return "RoomDetails [ room_id=" + room_id
				+ ", room_no=" + room_no + ", room_type=" + room_type
				+ ", per_night_rate=" + per_night_rate + ", availability="
				+ availability + ", photo=" + photo + "]";
	}	
}*/