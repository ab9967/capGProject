package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Emp;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.util.DBUtil;

@Repository("hotelDao")
public class HotelDaoImpl implements IHotelDao {
	
	@PersistenceContext
	private EntityManager manager;

	//static final Logger logs = Logger.getLogger(HotelDaoImpl.class);
	
	@Override
	public List<Hotel> showAllHotel() throws BookingException {

		Query qry =  manager.createNamedQuery("qryAllHotel", Hotel.class);
		System.out.println("In showAllHotel()");
		return qry.getResultList();
	}//String query = "SELECT * FROM HOTEL";

	@Override
	public Hotel getHotel(String hotelID) throws BookingException {
		TypedQuery<Hotel> qry = manager.createNamedQuery("qryHotelOnId", Hotel.class);
		qry.setParameter("hotelid", hotelID);
		return qry.getSingleResult();
	}//String query = "SELECT * FROM HOTEL where hotel_id=?";
		
	
	
	@Override
	public Users isUserAuthenticated(String userName, String password) throws BookingException {
		// to authenticate user
		Users user = getUserDetails(userName);
		if (password.equals(user.getPassword())) {
			System.out.println(user.getRole());
			//logs.info("User "+user.getUser_name()+"is logged in.");
			return user;
		} else {
			//logs.info("User "+user.getUser_name()+"is unable log in.");
			user.setUser_id("error");		//???????
			return user;
		}
	}

	@Override
	public Users getUserDetails(String userName) throws BookingException {
		TypedQuery<Users> qry = manager.createNamedQuery("getUserDetails", Users.class);
		qry.setParameter("userNm", userName);
		System.out.println(qry.getSingleResult());
		
		return qry.getSingleResult();
	}//String query = "SELECT USER_ID, PASSWORD, ROLE FROM USERS WHERE user_name=?";
	
	@Override
	public String getUserDetailsOld(String userName) throws BookingException {
		TypedQuery<Users> qry = manager.createNamedQuery("getUserPassword", Users.class);
		qry.setParameter("userNm", userName);
		System.out.println(qry.getSingleResult());
		Users user = qry.getSingleResult();
		System.out.println(user);
		//return qry.getSingleResult();
		return user.getPassword();
	}//String query = "SELECT PASSWORD FROM USERS WHERE USER_NAME=?";

	/*@Override
 6	public List<RoomDetails> checkAvailability(String hotelId)  throws BookingException {
		Connection con=DBUtil.obtainConnection();
		PreparedStatement pst=null;
		List<RoomDetails> roomList=new ArrayList<RoomDetails>();
		String query="SELECT * FROM ROOM_DETAILS WHERE AVAILABILITY=1 AND HOTEL_ID=?";
		try {
			pst=con.prepareStatement(query);
			pst.setString(1,hotelId);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				RoomDetails room=new RoomDetails();
				room.setRoom_id(rs.getString("room_id"));
				room.setRoom_type(rs.getString("room_type"));
				room.setPer_night_rate(rs.getInt("per_night_rate"));
				room.setRoom_no(rs.getString("room_no"));
				roomList.add(room);
			}
		} catch (SQLException e) {
			throw new BookingException("checkAvailability failed!!",e);
		}
		System.out.println(roomList);
		return roomList;
		}
	*/
	@Override
	public String AddHotel(Hotel hotel) throws BookingException {
		//public int AddHotel(Hotel hotel) throws BookingException {
		System.out.println(hotel);
		//@trasactional in serviceImpl
		manager.persist(hotel);						//persistent obj
		System.out.println(hotel);
		return hotel.getHotel_id();
	}//String query = "INSERT INTO HOTEL VALUES(?,?,?,?,?,?,?,?,?,?,?)";
	

	@Override
	public boolean deleteHotel(String hotel_id) throws BookingException {
		Hotel hotel = manager.find(Hotel.class, hotel_id);
		System.out.println(hotel);
		manager.remove(hotel);
		System.out.println("hotel deleted with id"+hotel_id); 		// delete
		return true; // or return obj of hotel
	}//String Query = "delete from hotel where hotel_id=?";
		
	@Override
	public boolean updateHotel(Hotel hotel) {
		System.out.println(hotel);
		manager.merge(hotel);				
		System.out.println("---------------");
		System.out.println(hotel);
		return true;
}//String Query = "update Hotel set hotel_name=?,avg_rate_per_night=?,phone_no1=?,phone_no2=?,rating=?,email=?,fax=? where hotel_id=?";

	
	// insert booking details
		@Override
		public String addbook(BookingDetails book) throws BookingException {
			System.out.println(book);
			try {
				//manager.getTransaction().begin();
				manager.persist(book);	
				// String query = "INSERT INTO booking_details VALUES(?,?,?,?,?,?,?,?)";
				System.out.println(book);
				String bookingId = book.getBooking_id();
				if(bookingId != null) {
					makeRoomUnavailable(book.getRoom_id());
				} else {
					manager.getTransaction().rollback(); //test this later 
					throw new BookingException("Error in inserting new records");
				}
				//manager.getTransaction().commit();
				return bookingId;
			}
			catch (RollbackException e) {
				throw new BookingException("Failed insertion in addbook()..",e);
			}
		}	
		
		private void makeRoomUnavailable(String room_id) {
			try {
				//manager.getTransaction().begin();
				RoomDetails room = manager.find(RoomDetails.class, room_id);
				int availability = 0;
				room.setAvailability(availability);
				//manager.getTransaction().commit();
				return;
			} catch (RollbackException e) {
				throw new BookingException("Failed updation in makeroomUnavailable()..",e);
			}
		}

	
	public boolean makeRoomAvailable(String rid) {
		try {
				//manager.getTransaction().begin();
				RoomDetails room = manager.find(RoomDetails.class, rid);
				int availability = 1;
				room.setAvailability(availability);
				//manager.getTransaction().commit();
				return true;
			} catch (RollbackException e) {
				throw new BookingException("Failed updation in makeroomavailable()..",e);
			}
		}	//String Query = "update Room_Details set availability=1 where room_id=?";
					
		/*private String getBookingId() {
			Connection connect = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			Integer bId = 0;
			String query = "SELECT seq_booking_Id.NEXTVAL from dual";
			try {
				connect = DBUtil.obtainConnection();
				stmt = connect.prepareStatement(query);
				rs = stmt.executeQuery();
				
				if (rs.next()) {
					bId = rs.getInt(1);
				} 
			} catch (BookingException |SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return bId.toString();
		
		}
		
		@Override
		public List<RoomDetails> showAllRooms(String hotel_id)
				throws BookingException {
			// show all rooms based on hotel id
			Connection connect = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			List<RoomDetails> roomlist = new ArrayList<RoomDetails>();
			String query = "SELECT ROOM_ID, ROOM_NO, ROOM_TYPE, PER_NIGHT_RATE, AVAILABILITY FROM ROOM_DETAILS";
			try {
				connect = DBUtil.obtainConnection();
				stmt = connect.prepareStatement(query);
				rs = stmt.executeQuery();
				while (rs.next()) {
					RoomDetails room = new RoomDetails();
					room.setRoom_id(rs.getString("ROOM_ID"));
					room.setRoom_no(rs.getString("ROOM_NO"));
					room.setRoom_type(rs.getString("ROOM_TYPE"));
					room.setPer_night_rate(rs.getInt("PER_NIGHT_RATE"));
					room.setAvailability(rs.getInt("AVAILABILITY"));

					roomlist.add(room);

				}
				return roomlist;
			} catch (SQLException e) {
				e.printStackTrace();
				throw new BookingException("Unable to display room details!!");
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (stmt != null) {
						stmt.close();
					}
					if (connect != null) {
						connect.close();
					}
				} catch (SQLException e) {
					throw new BookingException(" JDBC connection closing failed!!");
				}
			}

		}
	*/	

	
		@Override
		public RoomDetails showRoom(String hotel_id, String room_id) throws BookingException {
			TypedQuery<RoomDetails> qry = manager.createNamedQuery("qryRoomOnIds", RoomDetails.class);
			qry.setParameter("hotelid", hotel_id);
			qry.setParameter("roomid", room_id);
			System.out.println(qry.getSingleResult());
			return qry.getSingleResult();
		}//String query = "SELECT ROOM_ID, ROOM_NO, ROOM_TYPE, PER_NIGHT_RATE, AVAILABILITY 
		//FROM ROOM_DETAILS where hotel_id=? and room_id=?";
				
		@Override
		public List<Hotel> GetHotelNames() throws BookingException {
			Query qry =  manager.createNamedQuery("qryAllHotelNm", Hotel.class);
			System.out.println("In GetHotelNames()");
			System.out.println(qry.getResultList());
			return qry.getResultList();
		} //String query = "SELECT HOTEL_NAME FROM HOTEL";
		
		@Override
		public String GetHotelName(String hotelID) throws BookingException {
			TypedQuery<Hotel> qry = manager.createNamedQuery("qryHotelNm", Hotel.class);
			qry.setParameter("hotelid", hotelID);
			System.out.println(qry.getSingleResult());
			Hotel h = qry.getSingleResult();
			String hotelNm = h.getHotel_name();
			System.out.println("output:" + hotelNm);
			return hotelNm;
		}//String query = "SELECT HOTEL_NAME FROM HOTEL where hotel_id=?";
		
		
		/*@Override
		public String addRoom(RoomDetails room) throws BookingException {
			String room_id = getroomid();
			Connection conn = null;
			PreparedStatement pstm = null;
			String msg = null;
			String query = "INSERT INTO Room_Details VALUES(?,?,?,?,?,?,?)";

			try {
				conn = DBUtil.obtainConnection();
				pstm = conn.prepareStatement(query);
				pstm.setString(1,room.getHotel_id() );
				pstm.setString(2,room_id );
				pstm.setString(3, room.getRoom_no());
				pstm.setString(4, room.getRoom_type());
				pstm.setInt(5, room.getPer_night_rate());
				pstm.setInt(6,room.getAvailability());
				pstm.setString(7, room.getPhoto());
				int status = pstm.executeUpdate();
				if (status == 1) {
					msg = room_id;
				}
			} catch (BookingException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new BookingException("problem in insert");
			} finally {
				try {
					pstm.close();
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			System.out.println(msg);

			return msg;
			
		}
		
		private String getroomid() throws BookingException {
			String room_id  = null;
			Connection conn = null;
			PreparedStatement pstm = null;
			String Query = "select room_id_seq.nextval from dual";
			try {
				conn = DBUtil.obtainConnection();
				pstm = conn.prepareStatement(Query);
				ResultSet rs = pstm.executeQuery();
				while (rs.next()) {
					room_id = rs.getString(1);
				}
			} catch (BookingException | SQLException e) {
				e.printStackTrace();
				throw new BookingException("problem in insert");
			} finally {
				try {
					pstm.close();
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return room_id;

		}

		@Override
		public boolean deleterooms(String room_id) throws BookingException {
			Connection conn = null;
			PreparedStatement pstm = null;

			String Query = "delete from room_details where room_id=?";
			try {
				conn = DBUtil.obtainConnection();
				pstm = conn.prepareStatement(Query);
				pstm.setString(1, room_id);

				int i = pstm.executeUpdate();
				if (i == 1) {
					return true;
				} else {
					return false;
				}

			} catch (BookingException | SQLException e) {
				e.printStackTrace();
				try {
					throw new BookingException("problem in delete", e);
				} catch (BookingException e1) {

					e1.printStackTrace();
				}
			} finally {
				if (pstm != null) {
					try {
						pstm.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}

			return false;
			
		}
		
		@Override
		public boolean updateRoom(RoomDetails room, String hotel_id) throws BookingException {
			Connection conn = null;
			PreparedStatement pstm = null;

			String Query = "update Room_Details set room_type=?,per_night_rate=?,availability=? where hotel_id=? AND ROOM_ID=?";

			try {
				conn = DBUtil.obtainConnection();
				pstm = conn.prepareStatement(Query);
				pstm.setString(1, room.getRoom_type());
				pstm.setInt(2, room.getPer_night_rate());
				pstm.setInt(3, room.getAvailability());
				pstm.setString(4, hotel_id);
				pstm.setString(5, room.getRoom_id());
				
				int i = pstm.executeUpdate();
				if (i >= 1) {
					return true;
				} else {
					return false;
				}

			} catch (BookingException | SQLException e) {
				throw new BookingException("problem in update Room",e);
				
			} finally {
				if (pstm != null) {
					try {
						pstm.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
*/
		@Override
		public List<BookingDetails> viewHotelwiseBooking(String hotel_id) throws BookingException {
			System.out.println("in viewHotelwiseBooking()");
		}
			// View Hotel wise booking details based on hotel id
			/*Connection connect = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			List<BookingDetails> blist = new ArrayList<BookingDetails>();
			String query = "SELECT BOOKING_ID, ROOM_ID, USER_ID, BOOKED_FROM, BOOKED_TO, NO_OF_ADULTS, NO_OF_CHILDREN, AMOUNT from booking_details where room_id IN (select room_id from room_details where hotel_id=?)";
			try {
				connect = DBUtil.obtainConnection();
				stmt = connect.prepareStatement(query);
				stmt.setString(1, hotel_id);
				rs = stmt.executeQuery();
				while (rs.next()) {
					BookingDetails bdetail = new BookingDetails();
					bdetail.setBooking_id(rs.getString("BOOKING_ID"));
					bdetail.setRoom_id(rs.getString("ROOM_ID"));
					bdetail.setUser_id(rs.getString("USER_ID"));
					bdetail.setBooked_from(rs.getDate("BOOKED_FROM"));
					bdetail.setBooked_to(rs.getDate("BOOKED_TO"));
					bdetail.setNo_of_adults(rs.getInt("NO_OF_ADULTS"));
					bdetail.setNo_of_children(rs.getInt("NO_OF_CHILDREN"));
					bdetail.setAmount(rs.getInt("AMOUNT"));

					blist.add(bdetail);
					System.out.println(blist);
					
					 * //???????????????????????? is if() required?? String userid =
					 * rs.getString("USER_ID"); String qry =
					 * "SELECT USER_NAME FROM USERS WHERE USER_ID=?"; connect =
					 * DBUtil.obtainConnection(); stmt =
					 * connect.prepareStatement(qry); stmt.setString(1, userid);
					 * ResultSet res = stmt.executeQuery(); if(rs.next()) { String
					 * username = res.getString("USER_NAME"); return username; }
					 

				}
				return blist;

			} catch (SQLException e) {
				e.printStackTrace();
				throw new BookingException("Unable to display hotel wise booing details !!");
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (stmt != null) {
						stmt.close();
					}
					if (connect != null) {
						connect.close();
					}
				} catch (SQLException e) {
					throw new BookingException(" JDBC connection closing failed!!");
				}
			}

		}*/
	
		// to view guestList:
		//call viewHotelwiseBooking(String hotel_id) +  viewGuestList(String user_id)
		//user_id from list<bookingDetails>
		@Override
		public Users getUserDetailsForReport(String UserID) throws BookingException {
			TypedQuery<Users> qry = manager.createNamedQuery("qryUserDetailsForReport", Users.class);
			qry.setParameter("uId", UserID);
			System.out.println(qry.getResultList());
			return qry.getSingleResult();
		} // String query = "SELECT USER_ID, user_name, PASSWORD, ROLE FROM USERS WHERE user_id=?";
			
		@Override
		public List<BookingDetails> viewBookingDatewise(Date fromDate, Date toDate) throws BookingException {
			TypedQuery<BookingDetails> qry = manager.createNamedQuery("qryBookingDatewise", BookingDetails.class);
			qry.setParameter("frmDate", fromDate);
			//qry.setParameter("frmDate", TO_DATE("fromDate","dd/mm/yyyy"));
			
			qry.setParameter("toDate", toDate);
			System.out.println(qry.getResultList());
			return qry.getResultList();
		}	//String qry ="select * from booking_details 
			//where booked_from >= TO_DATE('?','dd/mm/yyyy') and booked_to <= TO_DATE('?', 'dd/mm/yyyy')"; 
		
			/*Connection connect = null;
			PreparedStatement stmt = null;
			ResultSet res = null;
			List<BookingDetails> blist = new ArrayList<BookingDetails>();
			
			String qry ="select * from booking_details where booked_from >= TO_DATE('?','dd/mm/yyyy') and booked_to <= TO_DATE('?', 'dd/mm/yyyy')"; 
			try {
			connect=DBUtil.obtainConnection(); 
			stmt = connect.prepareStatement(qry); 
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate fromDateLocal  = LocalDate.parse(fromDate,formatter);
			java.util.Date utilFromDate = new java.util.Date();
			try {
				utilFromDate = new SimpleDateFormat("yyyy-MM-dd").parse(fromDateLocal.toString());
			} catch (ParseException e1) {
				e1.printStackTrace();
			}
			java.sql.Date fromDate2 = new java.sql.Date(utilFromDate.getTime());
			
			formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate toDateLocal  = LocalDate.parse(toDate,formatter);
			java.util.Date utilToDate = new java.util.Date();
			try {
				utilToDate = new SimpleDateFormat("yyyy-MM-dd").parse(toDateLocal.toString());
			} catch (ParseException e1) {
				e1.printStackTrace();
			}
			java.sql.Date toDate2 = new java.sql.Date(utilToDate.getTime());			
			
			stmt.setDate(1, fromDate2);
			stmt.setDate(2, toDate2);
			res = stmt.executeQuery(); 
			while(res.next()) {
				BookingDetails bdetail = new BookingDetails();
				bdetail.setBooking_id(res.getString("BOOKING_ID"));
				bdetail.setRoom_id(res.getString("ROOM_ID"));
				bdetail.setUser_id(res.getString("USER_ID"));
				bdetail.setBooked_from(res.getDate("BOOKED_FROM"));
				bdetail.setBooked_to(res.getDate("BOOKED_TO"));
				bdetail.setNo_of_adults(res.getInt("NO_OF_ADULTS"));
				bdetail.setNo_of_children(res.getInt("NO_OF_CHILDREN"));
				bdetail.setAmount(res.getInt("AMOUNT"));

				blist.add(bdetail);
				System.out.println(blist);
						
				}
				return blist;
			} catch (SQLException e) {
				e.printStackTrace();
				throw new BookingException("Unable to get booking details!!");
			} finally {
				try {
					if (res != null) {
						res.close();
					}
					if (stmt != null) {
						stmt.close();
					}
					if (connect != null) {
						connect.close();
					}
				} catch (SQLException e) {
					throw new BookingException(" JDBC connection closing failed!!");
				}
			}
	}*/
		
	/*	@Override
		public List<BookingDetails> viewBookingDatewise(String fromDate, String toDate) throws BookingException {
				Connection connect = null;
				PreparedStatement stmt = null;
				ResultSet rs = null;
				List<BookingDetails> blist = new ArrayList<BookingDetails>();
				
				String qry ="select * from booking_details where booked_from >= TO_DATE(?,'yyyy/mm/dd') and booked_to <= TO_DATE(?, 'yyyy/mm/dd')"; 
				try {
					System.out.println("abc");
				connect=DBUtil.obtainConnection(); 
				System.out.println(fromDate);
				stmt = connect.prepareStatement(qry);
				System.out.println(toDate);
				stmt.setString(1, fromDate);
				System.out.println("abc");
				stmt.setString(2, toDate);
				System.out.println("abc");
				ResultSet res = stmt.executeQuery(); 
				while(res.next()) {
					BookingDetails bdetail = new BookingDetails();
					bdetail.setBooking_id(res.getString("BOOKING_ID"));
					bdetail.setRoom_id(res.getString("ROOM_ID"));
					bdetail.setUser_id(res.getString("USER_ID"));
					bdetail.setBooked_from(res.getDate("BOOKED_FROM"));
					bdetail.setBooked_to(res.getDate("BOOKED_TO"));
					bdetail.setNo_of_adults(res.getInt("NO_OF_ADULTS"));
					bdetail.setNo_of_children(res.getInt("NO_OF_CHILDREN"));
					bdetail.setAmount(res.getInt("AMOUNT"));

					blist.add(bdetail);
					System.out.println("abc");
							
					}
				System.out.println("abc");
					return blist;
				} catch (SQLException e) {
					e.printStackTrace();
					throw new BookingException("Unable to get user details!!");
				} finally {
					try {
						if (rs != null) {
							rs.close();
						}
						if (stmt != null) {
							stmt.close();
						}
						if (connect != null) {
							connect.close();
						}
					} catch (SQLException e) {
						throw new BookingException(" JDBC connection closing failed!!");
					}
				}			
		}*/
		
		@Override
		public String addUser(Users user) throws BookingException {
			System.out.println(user);
			manager.persist(user);						
			System.out.println(user);
			return user.getUser_name();
		}//String query = "INSERT INTO users VALUES(?,?,?,?,?,?,?,?)";
		
	/*	private String getuserid() throws BookingException {
			String user_id  = null;
			Connection conn = null;
			PreparedStatement pstm = null;
			String Query = "select user_id_seq.nextval from dual";
			try {
				conn = DBUtil.obtainConnection();
				pstm = conn.prepareStatement(Query);
				ResultSet rs = pstm.executeQuery();
				while (rs.next()) {
					user_id = rs.getString(1);
				}
			} catch (BookingException | SQLException e) {
				e.printStackTrace();
				throw new BookingException("problem in insert");
			} finally {
				try {
					pstm.close();
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return user_id;

		}
	*/	
		@Override
		public List<Users> viewGuestList(String user_id) throws BookingException {
			TypedQuery<Users> qry = manager.createNamedQuery("qryGuestListOnUId", Users.class);
			qry.setParameter("uId", user_id);
			System.out.println(qry.getResultList());
			return qry.getResultList();
		} // String qry ="SELECT USER_NAME FROM USERS WHERE USER_ID=?"; 
			
		
}