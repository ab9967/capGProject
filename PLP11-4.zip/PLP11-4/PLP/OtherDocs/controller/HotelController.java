package com.cg.appl.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;
import com.cg.appl.services.HotelServicesImpl;
import com.cg.appl.services.IHotelServices;

@WebServlet("*.do")
public class HotelController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private RequestDispatcher dispatch;
    ServletContext ctx = null;
    IHotelServices services;   
    
    private String nextJsp;
    
    public HotelController() {
      services = new HotelServicesImpl();
    }

	
	public void init() throws ServletException
	{
		ctx = super.getServletContext();
		services= (IHotelServices) ctx.getAttribute("services");
		services = new HotelServicesImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			this.processRequest(request, response);
		} catch (Exception e) {
			dispatch = request.getRequestDispatcher("/error.jsp");
			dispatch.forward(request,response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			this.processRequest(request, response);
		} catch (Exception e) {
			dispatch = request.getRequestDispatcher("/error.jsp");
			dispatch.forward(request,response);
		}
	}
	
	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, BookingException
	{
		String command = request.getServletPath();
		System.out.println("Command : "+command);
		ctx.log("Command : "+command);
		String message;
		BookingDetails booking;
		
		switch(command)
		{
			/*case "/login.do":
			{//User : admin, customer
				System.out.println("ASDasdasd");
				nextJsp = "/Login.jsp";
				break;
			}//end of case for login.do
			*/
		case "/registerNewUser.do":
			{//User : admin, customer
				
				String userName = request.getParameter("username");
				String password = request.getParameter("password");
				String mobno = request.getParameter("mobno");
				String phno = request.getParameter("phno");
				String address = request.getParameter("address");
				String emailid = request.getParameter("emailid");
				
				Users user = new Users();
				user.setUser_name(userName);
				user.setPassword(password);
				user.setMobile_no(mobno);
				user.setPhone(phno);
				user.setAddress(address);
				user.setEmail(emailid);
				
				String uName = services.addUser(user);
				if(uName.equals(userName))
					{
						request.setAttribute("oprStatus", "User "+uName+" is Registered to system !!!");					
					}
				else
					{
						request.setAttribute("oprStatusFailed", "Unable to register New User "+uName);
					}
				
				nextJsp = "/Register.jsp";
				break;
			}//end of case for login.do		
		 case "/authenticate.do":
			{//User : admin, customer
				String userName = request.getParameter("userid");
				String pwd = request.getParameter("password");
				
				Users user = new Users();
				
				user.setUser_name(userName);
				user.setPassword(pwd);
				
				try {
					Users authenticatedUser = services.isUserAuthenticated(userName, pwd);
					if(!authenticatedUser.getUser_id().equals("error"))
					{
						System.out.println("Yes");
												
						//code for starting new session
						//Users user =  services.getUserDetails(userName);
						//getUserDetails service reqd
						HttpSession session = request.getSession(true);
						//System.out.println(session.getId());
						//session.setAttribute("user", user);
						String UserRole = authenticatedUser.getRole();
						if(UserRole.equals("Customer")||UserRole.equals("HotelEmp")||UserRole.equals("n/a"))
						{
							session.setAttribute("userID",authenticatedUser.getUser_id());
							nextJsp = "showCustomerMenu.do";
						}
						else if(UserRole.equals("Admin"))
						{
							session.setAttribute("userID",authenticatedUser.getUser_id());
							
							nextJsp = "showAdminMenu.do";
						}
						
					}
					else
					{
						System.out.println("No");
						
						message = "Wrong Credentials Entered !!!";
						request.setAttribute("errorMsg", message);
						ctx.log("error Message : "+message);
						nextJsp = "/index.jsp";
					}
					
				} catch (BookingException e) {
					
					/*dispatch = request.getRequestDispatcher("/error.jsp");
					dispatch.forward(request, response);*/
					nextJsp = "/index.jsp";
					System.out.println(e);
					ctx.log(e.getMessage());
					message = "User Name does not exist !!!";
					request.setAttribute("errorMsg", message);
				}
				break;
			} //end of case for authenticate.do
		 /*case "/loadHotelDetails.do":
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
		 		String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 		
		 		String hotelID = request.getParameter("hotelID");
		 		
		 		Hotel hotel = services.getHotel(hotelID);
		 		
		 		session.setAttribute("hotel", hotel);
		 		
		 		nextJsp = "/updateHotel.jsp";
		 		break;
		 	}	*/		
		case "/showAdminMenu.do":
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
		 		String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 		List<Hotel> hotelList = services.showAllHotel();
		 		session.setAttribute("list", hotelList);
		 		nextJsp = "/adminMenu.jsp";
		 		break;
		 	}
		case "/showAddRoom.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("show add room user Id : "+user_id);
	 		
	 		List<Hotel> list = services.showAllHotel();
	 		session.setAttribute("list", list);
	 		
	 		nextJsp = "/addRoom.jsp";
	 		break;
	 	}
		case "/addRoom.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("add room user Id : "+user_id);
	 		
	 		RoomDetails room = new RoomDetails();
	 		room.setAvailability(1);
	 		room.setHotel_id(request.getParameter("hotelName"));
	 		room.setPer_night_rate(Integer.parseInt(request.getParameter("roomPrice")));
	 		room.setRoom_no((request.getParameter("roomNo")));
	 		room.setRoom_type(request.getParameter("roomType"));
	 		
	 		String roomID = services.addRoom(room);
	 		
	 		session.setAttribute("oprStatus","Room: "+roomID+" is added successfully to Hotel "+services.GetHotelName(room.getHotel_id()));
	 		
	 		nextJsp = "/adminMenu.jsp";
	 		break;
	 	}
	 	
		case "/showUpdateRoom.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("roomDetailsForUpdate user Id : "+user_id);
	 		
	 		nextJsp = "/updateRoom.jsp";
	 		break;
	 	}
		case "/showNPopulateUpdateRoom.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("show update room user Id : "+user_id);
	 		
	 		String hotelID = request.getParameter("hotelid");
	 		String roomID = request.getParameter("roomID");
	 		
	 		session.setAttribute("hotelIDForUpdate", hotelID);
	 		
	 		RoomDetails room = services.showRoom(hotelID, roomID);
	 		System.out.println();
	 		if(room.getRoom_type()==null)
	 		{
	 			session.setAttribute("oprStatusUpdateRoom","Room id/Hotel id does not exist ");
	 			nextJsp = "/updateRoom.jsp";
	 		}
	 		else
	 		{ 
	 			session.setAttribute("roomDetails", room);
	 			session.setAttribute("roomID", roomID);
	 			session.setAttribute("roomIDForRoomUpdate", roomID);
	 			session.setAttribute("roomType",room.getRoom_type());
	 			nextJsp = "/updatePopulateRoom.jsp";
	 		}
	 		
	 		
	 		
	 		break;
	 	}
		case "/updateRoom.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("update room user Id : "+user_id);
	 		
	 		RoomDetails room = new RoomDetails();
	 		room.setAvailability(1);
	 		room.setHotel_id(request.getParameter("hotelName"));
	 		room.setPer_night_rate(Integer.parseInt(request.getParameter("roomPrice")));
	 		room.setRoom_no((request.getParameter("roomNo")));
	 		
	 		if(request.getParameter("roomType").equals("blank"))
	 		{
	 			room.setRoom_type(request.getParameter("roomTypeOld"));
	 		}
	 		else
	 		{
	 			room.setRoom_type(request.getParameter("roomType"));
	 		}	 		
	 		
	 		System.out.println(room.getRoom_type());
	 		
	 		room.setRoom_id(session.getAttribute("roomIDForRoomUpdate").toString());
	 		
	 		boolean isUpdated = services.updateRoom(room, session.getAttribute("hotelIDForUpdate").toString());
	 		
	 		if(isUpdated)
	 		{
	 			session.setAttribute("oprStatus","Room: "+session.getAttribute("roomID")+" is updated successfully for Hotel "+services.GetHotelName(session.getAttribute("hotelIDForUpdate").toString()));
	 		}
	 		else
	 		{
	 			session.setAttribute("oprStatusFailed","Room: "+session.getAttribute("roomID")+" is Unable to update for Hotel "+services.GetHotelName(session.getAttribute("hotelIDForUpdate").toString()));
	 		}
	 		nextJsp = "/adminMenu.jsp";
	 		break;
	 	}	 	
		case "/showDeleteRoom.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("show Delete room user Id : "+user_id);
	 		nextJsp = "/deleteRoom.jsp";
	 		break;
	 	}
		case "/deleteRoom.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String hotelID = request.getParameter("hotelName");
	 		String roomID = request.getParameter("roomId");
	 		
	 		System.out.println("roonID " +roomID);

	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("delete room user Id : "+user_id);
	 			 		
	 		boolean isDeleted = services.deleterooms(roomID);
	 		
	 		if(isDeleted)
	 		{
	 			session.setAttribute("oprStatus", "Room "+roomID+"is Deleted successfully from Hotel "+services.GetHotelName(hotelID));
	 			nextJsp = "/adminMenu.jsp";
	 		}
	 		else
	 		{
	 			session.setAttribute("deleteException","Invalid Room ID : "+roomID);
	 			nextJsp = "/deleteRoom.jsp";
	 		}
	 		
	 		break;
	 	}	 
		case "/showAddHotel.do":
	 	{//User : admin
	 		HttpSession session = request.getSession(false);
	 		String  user_id  = session.getAttribute("userID").toString();
	 		System.out.println("user Id : "+user_id);
	 		nextJsp = "/addHotel.jsp";
	 		break;
	 	}
		 case "/addHotel.do":
			{//User : admin
				Hotel hotel = new Hotel();
				
				HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
				/*String hotelID = "1102";
				hotel.setHotel_id(hotelID);*/
				String hotelName =  request.getParameter("hotelName");
				hotel.setHotel_name(hotelName);
				String city = request.getParameter("hotelCity");
				hotel.setCity(city);
				String address = request.getParameter("address");
				hotel.setAddress(address);
				String desc = request.getParameter("desc");
				hotel.setDescription(desc);
				int price =Integer.parseInt(request.getParameter("price"));
				hotel.setAvg_rate_per_night(price);
				String contact1 = request.getParameter("phno");
				hotel.setPhone_no1(contact1);
				String contact2 = request.getParameter("phno2");
				hotel.setPhone_no2(contact2);
				int rating =Integer.parseInt(request.getParameter("rate"));
				hotel.setRating(rating);
				String email =request.getParameter("email");
				hotel.setEmail(email);
				String fax =request.getParameter("fax");
				hotel.setFax(fax);
								
				int count =services.AddHotel(hotel);
				if(count >= 1)
				{
					System.out.println("hotel added !!!");
					session.setAttribute("hotel", hotel);
				}
				else
				{
					message = "Unable to add new hotel !!!";
					session.setAttribute("errorMsg", message);
					ctx.log("error Message : "+message);
					nextJsp = "/addHotel.jsp";
				}
				
				break;
			} //end of case for authenticate.do
		 case "/showUpdateHotel.do" :
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
		 		nextJsp = "/updateHotel.jsp";
		 		break;
		 	}
		 case "/populateUpdateHotel.do" :
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
		 		//getting hotel id from form
		 		String hotelID = request.getParameter("hotelID");
		 		//getting hotel details from dao
		 		Hotel hotel = new Hotel();		 		
		 		
		 		hotel = services.getHotel(hotelID);
		 		
		 		if(hotel==null)
		 		{
		 			session.setAttribute("updateHotelIDInvalid", "Invalid Hotel ID !!!");
		 			nextJsp = "/updateHotel.jsp";
		 			dispatch = request.getRequestDispatcher(nextJsp);
					dispatch.forward(request,response);
		 		}
		 		else
		 		{
		 			session.setAttribute("hotel", hotel);
		 			//setting attribute of session for populating form
			 		nextJsp="/updateHotel.jsp";
		 		}
		 		
		 		break;
		 		//nextJsp
		 	}
		 case "/updateHotel.do":
		 	{//User : admin
		 		System.out.println("In Update Hotel.do");
		 		HttpSession session = request.getSession(false);
		 		
		 		Hotel hotel = new Hotel();
		 		String hotelID = request.getParameter("hotelID2").toString();
		 		hotel.setHotel_id(hotelID);
		 		String hotelName = request.getParameter("updateHotelName").toString();
		 		hotel.setHotel_name(hotelName);
		 		String description = request.getParameter("description").toString();
		 		hotel.setDescription(description);
		 		int price = Integer.parseInt(request.getParameter("price"));
		 		hotel.setAvg_rate_per_night(price);
		 		String phno1 = request.getParameter("phno1").toString();
		 		hotel.setPhone_no1(phno1);
		 		String phno2 = request.getParameter("phno2").toString();
		 		hotel.setPhone_no2(phno2);
		 		int rating = Integer.parseInt(request.getParameter("rating"));
		 		hotel.setRating(rating);
		 		String email = request.getParameter("email").toString();
		 		hotel.setEmail(email);
		 		String fax = request.getParameter("fax").toString();
		 		hotel.setFax(fax);
		 		
		 		boolean isUpdated = services.updateHotel(hotel);
		 		System.out.println(isUpdated);
		 		if(isUpdated)
		 		{
		 			nextJsp="/adminMenu.jsp";
		 		}
		 		else
		 		{		 			
		 			nextJsp="/updateHotel.jsp";
		 			message = "Unable to update Hotel !!!";
		 			session.setAttribute("errorMsg", message);
		 		}
		 		break;
		 	}
		 case "/delete.do":
		 {//User : admin
			 	System.out.println("In delete.do");
			 	
			 	HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 		
				nextJsp = "/deleteHotel.jsp";
				break;
				//upnext command deleteHotel.do
		 }
		 case "/deleteHotel.do":
		 	{//User : admin
		 	 	 System.out.println("In deleteHotel.do");
				 String hotelId=request.getParameter("hotelId");
				 boolean flag=services.deleteHotel(hotelId);
				 if(flag)
				 {
					 System.out.println("Deleted Hotel Successfully");
					 nextJsp="/deleteHotel.jsp";
				 }
				 else
				 {
					 System.out.println("Hotel Not Deleted");
					 request.setAttribute("errorMsg","Unable To delete");
					 nextJsp="/deleteHotel.jsp";
				 }					
		 		break;
		 		//upnext command  
		 	}
		 case "/showReportsMenu.do":
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 		
		 		nextJsp = "/reportsMenu.jsp";
		 		break;
		 	}
		 case "/showHotels.do":
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 		
		 		List<Hotel> hotelList = services.showAllHotel();
		 		session.setAttribute("list", hotelList);
		 		
		 		nextJsp = "/HotelListReport.jsp";
		 		break;
		 	}
		 case "/getHotelIDForReport.do":
		 	{//User : admin
		 		
		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 				 		
		 		nextJsp = "/hotelIDForReport.jsp";
		 		break;
		 	}
		 case "/showHotelwiseBooking.do":
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);		 		

		 		String hotelID= request.getParameter("hid");
		 		List<BookingDetails> bookingList = services.viewHotelwiseBooking(hotelID);
		 		
		 		for(BookingDetails index : bookingList)
		 		{
		 			index.setUser(services.getUserDetailsForReport(index.getUser_id()));
		 		}
		 		if(bookingList.isEmpty())
		 		{
		 			session.setAttribute("dateErrorForHotelwiseBooking","Hotel ID does not exist !!!");
				    
		 			nextJsp = "/acceptHotelIdForReport.jsp";
		 			dispatch = request.getRequestDispatcher(nextJsp);
					dispatch.forward(request,response);
		 		}
		 		else
		 		{
		 			session.setAttribute("bookingList", bookingList);		 		
		 			nextJsp = "/BookingListReport.jsp";
			 		dispatch = request.getRequestDispatcher(nextJsp);
					dispatch.forward(request,response);	 			
		 		}
		 		break;
		 	}
		 case "/getHotelIDForGuestListReport.do":
		 	{//User : admin
		 		
		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 				 		
		 		nextJsp = "/acceptHotelIdForReport.jsp";
		 		break;
		 	}		 	
		 case "/showHotelwiseUsers.do":
		 	{//User : admin	

		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 				 		
		 		String hotelID = request.getParameter("hid");
		 		
		 		List<BookingDetails> bookingList = services.viewHotelwiseBooking(hotelID);
		 		
		 		for(BookingDetails index : bookingList)
		 		{
		 			index.setUser(services.getUserDetailsForReport(index.getUser_id()));
		 		}
		 		
		 		if(bookingList.isEmpty())
		 		{
		 			session.setAttribute("dateErrorForHotelwiseBooking","Hotel ID does not exist !!!");
				    
		 			nextJsp = "/acceptHotelIdForReport.jsp";
		 			dispatch = request.getRequestDispatcher(nextJsp);
					dispatch.forward(request,response);
		 		}
		 		else
		 		{
		 		
			 		session.setAttribute("bookingList", bookingList);		 		
			 		nextJsp = "/GuestListReport.jsp";
			 		dispatch = request.getRequestDispatcher(nextJsp);
					dispatch.forward(request,response);
		 		}
		 		break;
		 	}
		 case "/getDatesForReport.do":
		 	{//User : admin
		 		
		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 				 		
		 		nextJsp = "/specifiedDateReport.jsp";
		 		break;
		 	}				 
		 case "/showDatewiseBooking.do":		
		 	{//User : admin
		 		HttpSession session = request.getSession(false);
				String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 		String hotelID= request.getParameter("hotelid");
		 		String fromDate = request.getParameter("from");
		 		String toDate = request.getParameter("to");
		 		//#####################################
		 		try {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					Date datefrom = sdf.parse(request.getParameter("from"));
					Date dateto = sdf.parse(request.getParameter("to"));
					 Date sysdate = new Date();

					if (dateto.before(datefrom)) {
					    System.out.println("Date1 is before Date2");
					    session.setAttribute("dateErrorForDateReport","check-in date must be before check-out Date");
					    dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
						dispatch.forward(request,response);
					} else
						if (datefrom.equals(dateto)) {
					    System.out.println("Date1 is equal to Date2");
					    session.setAttribute("dateErrorForDateReport","check-in date must be different from check-out Date");
					    dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
						dispatch.forward(request,response);
					}
					else
								if (dateto.before(sysdate)||datefrom.before(sysdate)) {
							    System.out.println("Date1 is equal to Date2");
							    session.setAttribute("dateErrorForDateReport","check-in /check-out date cannot be before today");
							    dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
								dispatch.forward(request,response);
					}else 
								if (dateto.after(datefrom)) {
							    System.out.println("Date1 is after Date2");
							    List<BookingDetails> bookingList = services.viewBookingDatewise(fromDate, toDate);	 		
						 		
							    if(bookingList.isEmpty())
							    {
							    	session.setAttribute("dateErrorForDateReport","Hotel ID does not exist !!!");
								    dispatch = request.getRequestDispatcher("/specifiedDateReport.jsp");
									dispatch.forward(request,response);
							    }else
							    {
							    
							 		session.setAttribute("bookingList",bookingList);
							 		
							 		nextJsp="/dateReport.jsp";
							 		
								    dispatch = request.getRequestDispatcher(nextJsp);
									dispatch.forward(request,response);
							    }
							}
					
				} catch (ParseException e) {
					
					e.printStackTrace();
				}
		 		//#####################################
		 		
		 		break;
		 	}
		 case "/showCustomerMenu.do":
		 	{//User : customer
		 		HttpSession session = request.getSession(false);
		 		String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println("user Id : "+user_id);
		 		
		 		List<Hotel> list = services.showAllHotel();
		 		session.setAttribute("list", list);
		 		
		 		System.out.println(list);
		 		
		 		nextJsp = "/book.jsp";
		 		break;
		 	}
		 case "/showBookingStatus.do"/*"/showBookingHistory.do"*/:
		 	{//User : customer
		 		HttpSession session = request.getSession(false);		 		
		 		
		 		break;
		 	}
		 case "/booking.do":
		 {//User : customer
			 	HttpSession session = request.getSession(false);
			 	
			 			 		String  user_id  = session.getAttribute("userID").toString();
			 		System.out.println(user_id);
				 	
			 		
				 	System.out.println("In booking.do");
					nextJsp = "/book.jsp";
			 	
				break;
			//upnext command showRoomDetails.do
		 }
		 
		 case "/checkAvailability.do":
			 {
				 HttpSession session = request.getSession(false);

				 	 String  user_id  = session.getAttribute("userID").toString();
			 		System.out.println(user_id);
				 
			 		String hotelID = request.getParameter("hotelName").toString();
			 		Hotel hotel = new Hotel();
			 		hotel.setHotel_id(hotelID);
			 		
			 		session.setAttribute("hotelName", services.GetHotelName(hotelID));
			 		
			 		session.setAttribute("fromDate", request.getParameter("from"));
			 		session.setAttribute("toDate", request.getParameter("to"));
			 		
			 		session.setAttribute("noOfRooms", request.getParameter("noOfRooms"));
			 		session.setAttribute("noOfAdults", request.getParameter("noOfAdults"));
			 		session.setAttribute("noOfChildren", request.getParameter("noOfChildren"));
			 		
			 		try {
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
						Date datefrom = sdf.parse(request.getParameter("from"));
						Date dateto = sdf.parse(request.getParameter("to"));
						 Date sysdate = new Date();

						if (dateto.before(datefrom)) {
						    System.out.println("Date1 is before Date2");
						    session.setAttribute("dateError","check-in date must be before check-out Date");
						    dispatch = request.getRequestDispatcher("booking.do");
							dispatch.forward(request,response);
						} else
							if (datefrom.equals(dateto)) {
						    System.out.println("Date1 is equal to Date2");
						    session.setAttribute("dateError","check-in date must be different from check-out Date");
						    dispatch = request.getRequestDispatcher("booking.do");
							dispatch.forward(request,response);
						}
						else
									if (dateto.before(sysdate)||datefrom.before(sysdate)) {
								    System.out.println("Date1 is equal to Date2");
								    session.setAttribute("dateError","check-in /check-out date cannot be before today");
								    dispatch = request.getRequestDispatcher("booking.do");
									dispatch.forward(request,response);
						}else 
									if (dateto.after(datefrom)) {
								    System.out.println("Date1 is after Date2");
								    List<RoomDetails> rooms = services.checkAvailability(hotel.getHotel_id());					 		
							 		session.setAttribute("RoomList", rooms);
								    dispatch = request.getRequestDispatcher("/roomDetails.jsp");
									dispatch.forward(request,response);
								}
						
					} catch (ParseException e) {
						
						e.printStackTrace();
					}
			 		
			 		List<RoomDetails> rooms = services.checkAvailability(hotel.getHotel_id());
			 		
			 		session.setAttribute("RoomList", rooms);
			 		nextJsp = "/roomDetails.jsp";
				 	
					break;
			 		//next jsp roomdetails.jsp
			 }
		 
		 case "/bookHotelRoom.do":
		 	{//User : customer
		 		HttpSession session = request.getSession(false);
		 		String  room_no  = request.getParameter("rno");
		 		System.out.println(room_no);
		 		
		 		String  user_id  = session.getAttribute("userID").toString();
		 		System.out.println(user_id);
		 		
		 		BookingDetails bookingDetails = new BookingDetails();
		 		
		 		bookingDetails.setUser_id(session.getAttribute("userID").toString());
		 		bookingDetails.setRoom_id(request.getParameter("id").toString());
		 		bookingDetails.setNo_of_adults(Integer.parseInt(session.getAttribute("noOfAdults").toString()));
		 		bookingDetails.setNo_of_children(Integer.parseInt(session.getAttribute("noOfChildren").toString()));
		 		
		 		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate fromDate  = LocalDate.parse(session.getAttribute("fromDate").toString(),formatter);
				java.util.Date utilFromDate;
				try {
					utilFromDate = new SimpleDateFormat("yyyy-MM-dd").parse(fromDate.toString());
					bookingDetails.setBooked_from(utilFromDate);
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		 		
		 		
				LocalDate toDate  = LocalDate.parse(session.getAttribute("toDate").toString(),formatter);
				java.util.Date utilToDate;
				try {
					utilToDate = new SimpleDateFormat("yyyy-MM-dd").parse(toDate.toString());
					bookingDetails.setBooked_to(utilToDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				Period period = fromDate.until(toDate);
				int days  = period.getDays();
		 		int amount = (Integer.parseInt(request.getParameter("price"))*days);
		 		
		 		bookingDetails.setAmount(amount);
		 		
		 		System.out.println(bookingDetails);
		 		
		 		String bookingID = services.addbook(bookingDetails);
		 		
		 		System.out.println(bookingID);
		 		session.setAttribute("roomNo", room_no);
		 		session.setAttribute("id", bookingID);
		 		nextJsp = "/success.jsp";
		 		
		 		break;
				//upnext command confirmBooking.do
		 	}
		 case "/showRoomDetails.do":
		 {//User : customer
			 	HttpSession session = request.getSession(false);	
			 	List<RoomDetails> rooms = services.showAllRooms("1103");
			 	session.setAttribute("rooms", rooms);
				nextJsp = "/roomDetails.jsp";
				break;
			//upnext command bookHotelRoom.do
		 }
		 case "/logout.do":
			{
				HttpSession session = request.getSession(false);
				session.invalidate(); //destroying session
				
				nextJsp = "/index.jsp";
				break;
			}//end of case for logout.do
		}
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request,response);
	}
	public void destroy() {
		services = null;
		dispatch = null;
	}
}
