package com.cg.appl.junit;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.appl.daos.HotelDaoImpl;
import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;

public class TestHotelDaoDelete {
	
	HotelDaoImpl h;
	Hotel hotelBean;
	BookingDetails book;
	RoomDetails room;
	Users user;

	@Before
	public void setUp() throws Exception {
    	 h=new HotelDaoImpl();
    	 hotelBean=new Hotel();
    	 user= new Users();
	}

	@After
	public void tearDown() throws Exception {
	h=null;
	hotelBean=null;
	book=null;
	user=null;
	room=null;
	
	}
	
	@Test
	public void testdeleteHotel() throws BookingException {
		try {
			String hotel_id = "1101";
			assertTrue(h.deleteHotel(hotel_id));
		} catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testdeleterooms() throws BookingException {
		try {
			String room_id = "F10A";
			assertTrue(h.deleterooms(room_id));
		} catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
