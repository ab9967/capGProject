package com.cg.appl.util;
/*
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.appl.exception.BookingException;


public class DBUtil {


		public static Connection obtainConnection() throws BookingException{
			Connection conn = null;
			Context context;
			try {
				context = new InitialContext();
				DataSource source = (DataSource) context.lookup("java:/OracleDS1");
				conn = source.getConnection();
			} catch (NamingException | SQLException e) {
				e.printStackTrace();
				throw new BookingException("Problem in connection");
			
			}		
			return conn;
		}
	}
*/


import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.appl.exception.BookingException;

public class DBUtil {

	static Connection conn = null;
	private static DataSource dataSource;
	
	public static Connection obtainConnection() throws BookingException
	{
		Context ctx;
		try {
			ctx = new InitialContext();  //get reference to remote JNDI
			
			dataSource = (DataSource)ctx.lookup("java:/OracleDS"); //proxy of dataSource
			
			conn =  dataSource.getConnection();
			
		} catch (NamingException e) {
			
			e.printStackTrace();
			throw new BookingException("Exception in Connection"+e);
		} 		
		catch (SQLException e) {
			
			e.printStackTrace();
			throw new BookingException("Exception in Connection"+e);
		}
		return conn;	
	}
}
