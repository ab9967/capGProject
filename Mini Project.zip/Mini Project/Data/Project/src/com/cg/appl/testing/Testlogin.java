package com.cg.appl.testing;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.appl.daos.HotelDaoImpl;
import com.cg.appl.exception.BookingException;

public class Testlogin {

	HotelDaoImpl dao = new HotelDaoImpl();
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testIsUserAuthenticated() throws BookingException {
		System.out.println("Scott Password");
		System.out.println(dao.getUserDetails("Scott"));
		assertNotNull(dao.getUserDetails("Scott"));
		
	}

}
