package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.exception.BookingException;

public interface IBookingDao {
	
	List<Hotel> showAllHotel() throws BookingException;
	public boolean updateRoom(RoomDetails room)throws BookingException ;
	public int addbook(BookingDetails book) throws BookingException;
}
