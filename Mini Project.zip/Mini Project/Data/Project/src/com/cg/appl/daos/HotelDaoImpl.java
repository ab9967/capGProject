package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;
import com.cg.appl.util.DBUtil;

public class HotelDaoImpl implements IHotelDao {
	private DBUtil util;

	public HotelDaoImpl() {
		util = new DBUtil();
	}

	@Override
	public boolean isUserAuthenticated(String userName, String password) throws BookingException {
		// to authenticate user
		Users user = new Users();
		user.setUser_name(userName);
		user.setPassword(password);
		String dbpass = getUserDetails(userName);
		System.out.println(dbpass);
		System.out.println(user.getPassword());
		System.out.println(dbpass.equals(user.getPassword()));
		if (dbpass.equals(user.getPassword())) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public String getUserDetails(String userName) throws BookingException {
		// To get password from database
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String query = "SELECT PASSWORD FROM USERS WHERE USER_NAME=?";
		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			stmt.setString(1, userName);

			rs = stmt.executeQuery();

			if (rs.next()) {
				String password = rs.getString("PASSWORD");
				System.out.println(password);
				return password;
			} else {
				throw new BookingException("User Name Wrong!!");
			}
		} catch (SQLException e) {
			throw new BookingException("Jndi failed", e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new BookingException(" Jndi connection closing failed!!");
			}
		}
	}

	@Override
	public int AddHotel(Hotel hotel) throws BookingException {
		Connection connect = null;
		PreparedStatement pstm = null;
		int msg=0;
		int hid = getHotelId();
		String query = "INSERT INTO HOTEL VALUES(?,?,?,?,?,?,?,?,?,?,?)";

		try {
			connect = DBUtil.obtainConnection();
			pstm = connect.prepareStatement(query);
			
			pstm.setInt(1,hid);
			pstm.setString(2, hotel.getCity());
			pstm.setString(3, hotel.getHotel_name());
			pstm.setString(4, hotel.getAddress());
			pstm.setString(5, hotel.getDescription());
			pstm.setInt(6, hotel.getAvg_rate_per_night());
			pstm.setString(7, hotel.getPhone_no1());
			pstm.setString(8, hotel.getPhone_no2());
			pstm.setInt(9, hotel.getRating());
			pstm.setString(10, hotel.getEmail());
			pstm.setString(11, hotel.getFax());
			int status = pstm.executeUpdate();
			if(status > 0 ){
				msg = hid;
			}else{
				System.out.println("failed insertion");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return msg;
	}


	@Override
	public boolean deleteHotel(String hotel_id) throws BookingException {
		Connection conn = null;
		PreparedStatement pstm = null;

		String Query = "delete from hotel where hotel_id=?";
		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			pstm.setString(1, hotel_id);

			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			} else {
				return false;
			}

		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			try {
				throw new BookingException("problem in delete", e);
			} catch (BookingException e1) {

				e1.printStackTrace();
			}
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		}

		return false;
	}

	@Override
	public boolean updateHotel(Hotel hotel) {
		Connection conn = null;
		PreparedStatement pstm = null;

		String Query = "update Hotel set city=?,hotel_name=?,address=?,description=?,avg_rate_per_night=?,rating=?,email=?,fax=? where hotel_id=?";

		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			pstm.setString(1, hotel.getCity());
			pstm.setString(2, hotel.getHotel_name());
			pstm.setString(3, hotel.getAddress());
			pstm.setString(4, hotel.getDescription());
			pstm.setInt(5, hotel.getAvg_rate_per_night());
			pstm.setInt(6, hotel.getRating());
			pstm.setString(7, hotel.getEmail());
			pstm.setString(8, hotel.getFax());
			pstm.setString(9, hotel.getHotel_id());
			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			} else {
				return false;
			}

		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			try {
				throw new BookingException("problem in update");
			} catch (BookingException e1) {

				e1.printStackTrace();
			}
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return false;
	}
	public int getHotelId(){
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int hotelId=0;
		String query = "SELECT seq_hotel_Id.NEXTVAL from dual";
		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			rs = stmt.executeQuery();
			
			if (rs.next()) {
				hotelId = rs.getInt(1);
			} 
		} catch (BookingException |SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return hotelId;
	
	}
}
