package com.cg.appl.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;
import com.cg.appl.services.HotelServicesImpl;
import com.cg.appl.services.IHotelServices;

@WebServlet("*.do")
public class HotelController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private RequestDispatcher dispatch;
    ServletContext ctx = null;
    IHotelServices services;
    
    
    
    private String nextJsp;
    
    public HotelController() {
      services = new HotelServicesImpl();
    }

	
	public void init() throws ServletException
	{
		ctx = super.getServletContext();
		services= (IHotelServices) ctx.getAttribute("services");
		services = new HotelServicesImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			this.processRequest(request, response);
		} catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			this.processRequest(request, response);
		} catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, BookingException 
	{
		String command = request.getServletPath();
		System.out.println("Command : "+command);
		ctx.log("Command : "+command);
		String message;
		
		switch(command)
		{
			case "/login.do":
			{
				System.out.println("ASDasdasd");
				nextJsp = "/Login.jsp";
				break;
			}//end of case for login.do
			
		 case "/authenticate.do":
			{
				String userName = request.getParameter("userName");
				String pwd = request.getParameter("password");
				
				try {
					boolean isAuthenticated = services.isUserAuthenticated(userName, pwd);
					if(isAuthenticated)
					{
						System.out.println("Yes");
						/*						
						//code for starting new session
						Users user =  services.getUserDetails(userName);
						//getUserDetails service reqd
						HttpSession session = request.getSession(true);
						System.out.println(session.getId());
						session.setAttribute("user", user);*/
						
						boolean temp = services.isUserAuthenticated(userName, pwd);
						System.out.println(temp);
						nextJsp = "/BookingPage.jsp";
						
					}
					else
					{
						System.out.println("No");
						
						message = "Wrong Credentials Entered !!!";
						request.setAttribute("errorMsg", message);
						ctx.log("error Message : "+message);
						nextJsp = "/Login.jsp";
					}
					
				} catch (BookingException e) {
					
					/*dispatch = request.getRequestDispatcher("/error.jsp");
					dispatch.forward(request, response);*/
					nextJsp = "/Login.jsp";
					ctx.log(e.getMessage());
					message = "User Name does not exist !!!";
					request.setAttribute("errorMsg", message);
				}
				break;
			} //end of case for authenticate.do
		 case "/addHotel.do":
			{
				Hotel hotel = new Hotel();
				
				String hotelID = "1102";
				hotel.setHotel_id(hotelID);
				String hotelName =  request.getParameter("hotelName");
				hotel.setHotel_name(hotelName);
				String city = request.getParameter("hotelCity");
				hotel.setCity(city);
				String address = request.getParameter("address");
				hotel.setAddress(address);
				String desc = request.getParameter("desc");
				hotel.setDescription(desc);
				int price =Integer.parseInt(request.getParameter("price"));
				hotel.setAvg_rate_per_night(price);
				String contact1 = request.getParameter("phno");
				hotel.setPhone_no1(contact1);
				String contact2 = request.getParameter("phno2");
				hotel.setPhone_no2(contact2);
				int rating =Integer.parseInt(request.getParameter("rate"));
				hotel.setRating(rating);
				String email =request.getParameter("email");
				hotel.setEmail(email);
				String fax =request.getParameter("fax");
				hotel.setFax(fax);
				
				int count = services.AddHotel(hotel);
				if(count >= 1)
				{
					System.out.println("hotel added !!!");
				}
				
				break;
			} //end of case for addhotel.do
		 case "/delete.do":
		 {
			 System.out.println("In delete.do");
				nextJsp = "/deleteHotel.jsp";
				break;
		 }
		 case "/deleteHotel.do":
		 {
			 System.out.println("In deleteHotel.do");
			 String hotelId=request.getParameter("hotelId");
			 boolean value=services.deleteHotel(hotelId);
			 if(value)
			 {
				 System.out.print("Deleted Hotel Successfully");
				 nextJsp="deleteHotel.jsp";
			 }
			 else
			 {
				 System.out.print("Hotel Not Deleted");
				 request.setAttribute("errorMsg","Unable To delete");
				 nextJsp="error.jsp";
			 }
				break;
		 }
		 case "/booking.do":
		 {
			 System.out.println("In booking.do");
				nextJsp = "/BookingPage.jsp";
				break;
		 }
		}
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request,response);
	}
	public void destroy() {
		
	}
}
