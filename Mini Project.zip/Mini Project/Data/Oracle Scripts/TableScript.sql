DROP TABLE Users;
Create Table Users
(
	user_id varchar2(4),
	password varchar2(10),
	role varchar2(10),
	user_name varchar2(20),
	mobile_no varchar2(10),
	phone varchar2(10),
	address varchar2(25),
	email varchar2(25),
	CONSTRAINT user_id_PK PRIMARY KEY (user_id)
);

INSERT INTO Users VALUES ('1001','admin123','Admin','Scott','9638527410','235689','street no 5, Mumbai','scott@abc.com');
INSERT INTO Users VALUES ('1002','cust123','Customer','King','9966338451','223355','street no 11, Banglore','king@gmail.com');
INSERT INTO Users VALUES ('1003','hotel123','HotelEmp','Smith','8956230174','568921','street no 2, Mumbai','smith@abc.com');

DROP TABLE Hotel;
Create Table Hotel
(
hotel_id varchar2(4),
city varchar2(10),
hotel_name varchar2(10),
address varchar2(25),
description varchar2(200),
avg_rate_per_night number(10,2),
phone_no1 varchar2(10),
phone_no2 varchar2(10),
rating number(2),
email varchar2(25),
fax varchar2(15),
CONSTRAINT hotel_id_PK PRIMARY KEY (hotel_id)
);

INSERT INTO hotel VALUES ('1101','Mumbai','ABC','Nariman, Mumbai','Nestled in the heart of vibrant and bustling Mumbai lies our hotel Trident, Nariman Point.',5000.00,'256535','253478',5,'contactus@abc.com','+912266325000');

DROP TABLE Room_Details;
CREATE TABLE Room_Details
(
hotel_id varchar2(4),
room_id varchar2(4),
room_no varchar2(3),
room_type varchar2(40),
per_night_rate number(6,2),
availability number,
--1 for available and 0 for not available
photo varchar2(40),
CONSTRAINT room_id_PK PRIMARY KEY (room_id),
CONSTRAINT chk_room_type
	CHECK (room_type IN ('Standard non A/C room','Standard A/C room','Executive A/C room','Deluxe A/C room')),
CONSTRAINT hotel_id_FK
	FOREIGN KEY (hotel_id)
	REFERENCES Hotel(hotel_id)
);

INSERT INTO Room_Details VALUES ('1101','F01A','FA1','Standard non A/C room',4000.00,1,'');
INSERT INTO Room_Details VALUES ('1101','F02A','FA2','Standard A/C room',4000.00,1,'');
INSERT INTO Room_Details VALUES ('1101','F01B','FB1','Executive A/C room',2000.00,1,'');
INSERT INTO Room_Details VALUES ('1101','F02B','FB2','Deluxe A/C room',2000.00,1,'');

DROP TABLE Booking_Details;
CREATE TABLE Booking_Details
(
booking_id varchar2(4),
room_id varchar2(4),
user_id varchar2(4),
booked_from date,
booked_to date,
no_of_adults number(2),
no_of_children number(2),
amount number(6,2),
CONSTRAINT booking_id_PK PRIMARY KEY (booking_id),
CONSTRAINT user_id_FK
	FOREIGN KEY (user_id)
	REFERENCES Users(user_id),
CONSTRAINT room_id_FK
	FOREIGN KEY (room_id)
	REFERENCES Room_Details(room_id)
);
INSERT INTO Booking_Details VALUES ('0001','F01A','1002','12-MAY-2016','21-MAY-2016',2,1,4000.00);

SELECT constraint_name, constraint_type, column_name
from user_constraints natural join user_cons_columns
where table_name = 'hotel';

