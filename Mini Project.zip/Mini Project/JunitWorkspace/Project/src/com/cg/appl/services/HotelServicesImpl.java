package com.cg.appl.services;

import java.util.List;

import com.cg.appl.daos.HotelDaoImpl;
import com.cg.appl.daos.IHotelDao;
import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;

public class HotelServicesImpl implements IHotelServices{

private IHotelDao dao;
	
	public HotelServicesImpl(){
		dao = new HotelDaoImpl(); 
	}

	@Override
	public List<RoomDetails> showAllRooms(String hotel_id)
			throws BookingException {
		// TODO Auto-generated method stub
		return dao.showAllRooms(hotel_id);
	}

	@Override
	public List<Hotel> showAllHotel() throws BookingException {
		// TODO Auto-generated method stub
		return dao.showAllHotel();
	}

	@Override
	public Users isUserAuthenticated(String userName, String password)
			throws BookingException {
		return dao.isUserAuthenticated(userName, password);
	}

	@Override
	public Users getUserDetails(String userName) throws BookingException {
		// TODO Auto-generated method stub
		return dao.getUserDetails(userName);
	}

	@Override
	public int AddHotel(Hotel hotel) throws BookingException {
		// TODO Auto-generated method stub
		return dao.AddHotel(hotel);
	}

	@Override
	public boolean deleteHotel(String hotel_id) throws BookingException {
		// TODO Auto-generated method stub
		return dao.deleteHotel(hotel_id);
	}

	@Override
	public boolean updateHotel(Hotel hotel) throws BookingException {
		// TODO Auto-generated method stub
		return dao.updateHotel(hotel);
	}

	@Override
	public boolean updateRoom(RoomDetails room) throws BookingException {
		// TODO Auto-generated method stub
		return dao.updateRoom(room);
	}

	@Override
	public String addbook(BookingDetails book) throws BookingException {
		// TODO Auto-generated method stub
		return dao.addbook(book);
	}

	@Override
	public boolean makeRoomUnAvailable(String rid) throws BookingException {
		// TODO Auto-generated method stub
		return dao.makeRoomUnAvailable(rid);
	}

	@Override
	public List<BookingDetails> viewBookingHistory(String user_id)
			throws BookingException {
	
		return dao.viewBookingHistory(user_id);
	}

	@Override
	public List<BookingDetails> viewHotelwiseBooking(String hotel_id)
			throws BookingException {
		// TODO Auto-generated method stub
		return dao.viewHotelwiseBooking(hotel_id);
	}

	@Override
	public List<Users> viewGuestList(String user_id) throws BookingException {
		// TODO Auto-generated method stub
		return dao.viewGuestList(user_id);
	}

	@Override
	public List<BookingDetails> viewBookingDatewise(String fromDate,
			String toDate) throws BookingException {
		// TODO Auto-generated method stub
		return dao.viewBookingDatewise(fromDate, toDate);
	}

	@Override
	public String GetHotelName(String hotelID) throws BookingException {
		// TODO Auto-generated method stub
		return dao.GetHotelName(hotelID);
	}

	@Override
	public List<Hotel> GetHotelNames() throws BookingException {
		// TODO Auto-generated method stub
		return dao.GetHotelNames();
	}

	@Override
	public boolean deleterooms(String room_id) throws BookingException {
		// TODO Auto-generated method stub
		return dao.deleterooms(room_id);
	}

	@Override
	public String addRoom(RoomDetails room) throws BookingException {
		// TODO Auto-generated method stub
		return dao.addRoom(room);
	}

	@Override
	public String addUser(Users user) throws BookingException {
		// TODO Auto-generated method stub
		return dao.addUser(user);
	}

	@Override
	public Hotel getHotel(String hotelID) throws BookingException {
		// TODO Auto-generated method stub
		return dao.getHotel(hotelID);
	}

	@Override
	public List<RoomDetails> checkAvailability(String hotelId)
			throws BookingException {
		// TODO Auto-generated method stub
		return dao.checkAvailability(hotelId);
	}

	@Override
	public Boolean dateWiseroomAvailability(String fromDate, String toDate,
			String room_id) throws BookingException {
		// TODO Auto-generated method stub
		return dao.dateWiseroomAvailability(fromDate, toDate, room_id);
	}





}
