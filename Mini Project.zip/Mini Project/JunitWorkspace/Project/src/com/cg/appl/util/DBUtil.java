package com.cg.appl.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.cg.appl.exception.BookingException;


/*

		public static Connection obtainConnection() throws BookingException{
			Connection conn = null;
			InitialContext context;
			try {
				context = new InitialContext();
				DataSource source = (DataSource) context.lookup("java:/OracleDS");
				conn = source.getConnection();
			} catch (NamingException | SQLException e) {
				e.printStackTrace();
				throw new BookingException("Problem in connection");
			
			}		
			return conn;
		}
	}
*/



	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.IOException;
	import java.io.InputStream;
	import java.sql.DriverManager;
	import java.util.Properties;

	public class DBUtil {

		private DataSource datasource;
		static Connection conn=null;
		
	public static Properties loadProperty(){
			
			Properties prop= new Properties();
			InputStream in = null;
			
			try {
				in= new FileInputStream("oracle.properties");
			} catch (FileNotFoundException e) {
				
				e.printStackTrace();
			}
			 try {
				prop.load(in);
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			 finally{
				 try {
					in.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			 }
			 return prop;
			 
		  
			
		}
		

		
		public static Connection obtainConnection() throws BookingException 
		{
			
			/*String url, usernm, pass, driver;*/
			Connection con= null;
			/*Properties prop= loadProperty();*/
			
			/* driver= prop.getProperty("oracle.driver");
			 url= prop.getProperty("oracle.url");
			 usernm= prop.getProperty("oracle.uname");
			 pass= prop.getProperty("oracle.upass");
			 */
			 //PropertyConfigurator.configure("log4j.properties");
			String url = "jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G";
			String driver ="oracle.jdbc.driver.OracleDriver"; // prop.getProperty("oracle.driver");
			String user = "labg104trg16";
			String password = "labg104oracle";
			 try {
				Class.forName(driver);
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			 
			 try {
				con= DriverManager.getConnection(url, user, password);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				
				throw new BookingException("Connection problem");
				
				
			}  
			 return con;
			 
		
			//dataSource.setURL("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G");
			
			
			
			/*InitialContext context;
			try {
				context=new InitialContext();
				DataSource source=(DataSource) context.lookup("java:/OracleDS"); //jdbc/ConPool
				conn=source.getConnection();
			} catch (NamingException e) {
				
				e.printStackTrace();
				//throw new EmployeeException("Problem in Connection");
			} catch (SQLException e) {
				
				e.printStackTrace();
				//throw new EmployeeException("Problem in Connection");
			}
			
			return conn;
			*/
		}
	}
