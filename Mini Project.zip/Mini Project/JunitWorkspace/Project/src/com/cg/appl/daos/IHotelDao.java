package com.cg.appl.daos;


import java.util.List;

import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;

public interface IHotelDao {
	
	List<RoomDetails> showAllRooms(String hotel_id) throws BookingException;
	List<Hotel> showAllHotel() throws BookingException;
	Users isUserAuthenticated(String userName, String password) throws BookingException;
	Users getUserDetails(String userName) throws BookingException;		//returns password and role
	int AddHotel(Hotel hotel) throws BookingException;
	boolean deleteHotel(String hotel_id) throws BookingException;
	boolean updateHotel(Hotel hotel) throws BookingException;;
	boolean updateRoom(RoomDetails room)throws BookingException ;
	String addbook(BookingDetails book) throws BookingException;
	public boolean makeRoomUnAvailable(String rid) throws BookingException;
	List<BookingDetails> viewBookingHistory(String user_id) throws BookingException; //user_id from session
	List<BookingDetails> viewHotelwiseBooking(String hotel_id) throws BookingException;
	List<Users> viewGuestList(String user_id) throws BookingException;
	List<BookingDetails> viewBookingDatewise(String fromDate, String toDate)throws BookingException; 
	String GetHotelName(String hotelID) throws BookingException;
	List<Hotel> GetHotelNames() throws BookingException;
	boolean deleterooms(String room_id) throws BookingException;
	String addRoom(RoomDetails room) throws BookingException;
	String addUser(Users user) throws BookingException;
	Hotel getHotel(String hotelID) throws BookingException;
	List<RoomDetails> checkAvailability(String hotelId)  throws BookingException;
	Boolean dateWiseroomAvailability(String fromDate, String toDate, String room_id) throws BookingException;
	//String cancelBooking(String booking_id) throws BookingException;
}
