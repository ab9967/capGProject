package com.cg.appl.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.appl.exception.BookingException;
import com.cg.appl.services.HotelServicesImpl;
import com.cg.appl.services.IHotelServices;

public class TestShowfunctions {

IHotelServices service;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		service=new HotelServicesImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testshowAllHotel() throws BookingException {
	
		try {
	
			assertNotNull(service.showAllHotel());
		} catch (Exception e) {
			// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	@Test
	public void testGetHotelName() throws BookingException {
	
		try {
			String hotelID = "1101";
			assertEquals("Oberoi", service.GetHotelName(hotelID));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	@Test
	public void testGetHotelNames() throws BookingException {
	
		try {
			// String hotelID = "1101";
			assertNotNull(service.GetHotelNames());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	@Test
	public void testviewBookingHistory() throws BookingException {
	
		try {
			String user_id = "1001";
			assertNotNull(service.viewBookingHistory(user_id));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}
