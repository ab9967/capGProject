package com.cg.appl.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.appl.entities.RoomDetails;
import com.cg.appl.exception.BookingException;
import com.cg.appl.services.HotelServicesImpl;
import com.cg.appl.services.IHotelServices;

public class TestUpdateFunctions {

IHotelServices service;
RoomDetails room = new RoomDetails();
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		service=new HotelServicesImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testupdateRoom()  throws BookingException{
		room = new RoomDetails("","4001","401","Deluxe A/C room",5000,1,"");
		try {
			assertFalse(service.updateRoom(room));
		   } catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
