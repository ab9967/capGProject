package com.cg.appl.test;

import static org.junit.Assert.*;

import java.util.Date;

import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;
import com.cg.appl.services.HotelServicesImpl;
import com.cg.appl.services.IHotelServices;

public class TestAddfunctions {
	IHotelServices service;
	Users user=new Users();
	RoomDetails room = new RoomDetails();
	Hotel hotel = new Hotel();
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		service=new HotelServicesImpl();
	}

	@After
	public void tearDown() throws Exception {
		service = null;
		user = null;
		room=null;
		hotel =null;
	}

	@Test
	public void testaddRoom() throws BookingException {
	room = new RoomDetails("","4001","401","Deluxe A/C room",5000,1,"");
		try {
			assertNotNull(service.addRoom(room));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	@Test
	public void testaddUser() throws BookingException {
			user = new Users("","cust123","Customer","user1","9809921","768686", "Mumbai mumbai","ada@ghg.com" );
			try {
				assertNotNull(service.addUser(user));
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
			}

	@Test
	public void testaddHotel() throws BookingException {
		hotel = new Hotel("","Jaipur","Mango","Pune","abcvc", 4300, "84848484","75854",5,"ahaj@gmail.com","8958595");
		try {
		assertNotNull(service.AddHotel(hotel));
	} catch (Exception e) {
		// TODO Auto-generated catch block
	e.printStackTrace();
	}


	}
	


}