package com.cg.appl.services;

import java.util.List;

import com.cg.appl.entities.Hotel;
import com.cg.appl.exception.BookingException;

public interface IHotelServices {
	boolean isUserAuthenticated(String userName, String password) throws BookingException;
	/*List<Hotel> showAllHotel() throws BookingException;*/
	int AddHotel(Hotel hotel) throws BookingException;
	boolean deleteHotel(String hotel_id) throws BookingException;
	boolean updateHotel(Hotel hotel);
}
