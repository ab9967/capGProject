package com.cg.appl.services;

import java.util.List;

import com.cg.appl.daos.HotelDaoImpl;
import com.cg.appl.daos.IHotelDao;
import com.cg.appl.entities.Hotel;
import com.cg.appl.exception.BookingException;

public class HotelServicesImpl implements IHotelServices{

private IHotelDao dao;
	
	public HotelServicesImpl(){
		dao = new HotelDaoImpl(); 
	}


	@Override
	public boolean isUserAuthenticated(String userName, String password)
			throws BookingException {
		return dao.isUserAuthenticated(userName, password);
	}
	@Override
	public boolean deleteHotel(String hotel_id) throws BookingException {
		return dao.deleteHotel(hotel_id);
	}

	@Override
	public boolean updateHotel(Hotel hotel) {
		return dao.updateHotel(hotel);
	}

	@Override
	public int AddHotel(Hotel hotel) throws BookingException {
		return dao.AddHotel(hotel);
	}


}
