package com.cg.appl.controller;

public class HotelController {

	public static void main(String[] args) {
		

	}

}
