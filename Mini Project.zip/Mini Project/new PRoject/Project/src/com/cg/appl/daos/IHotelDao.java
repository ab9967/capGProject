package com.cg.appl.daos;


import java.util.List;

import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;

public interface IHotelDao {
	
	List<RoomDetails> showAllRooms(String hotel_id) throws BookingException;
	List<Hotel> showAllHotel() throws BookingException;
	List<BookingDetails> ViewBookingHistory(String user_id) throws BookingException; //user_id from session
	
	//String cancelBooking(String booking_id) throws BookingException;
	
	String isUserAuthenticated(String userName, String password) throws BookingException;
	Users getUserDetails(String userName) throws BookingException;		//returns password and role
	int AddHotel(Hotel hotel) throws BookingException;
	boolean deleteHotel(String hotel_id) throws BookingException;
	boolean updateHotel(Hotel hotel);
	
	boolean updateRoom(RoomDetails room)throws BookingException ;
	int addbook(BookingDetails book) throws BookingException;
		
}
