package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;
import com.cg.appl.util.DBUtil;

public class HotelDaoImpl implements IHotelDao {
	private DBUtil util;

	public HotelDaoImpl() {
		util = new DBUtil();
	}

	@Override
	public List<RoomDetails> showAllRooms(String hotel_id)
			throws BookingException {
		// show all rooms based on hotel id
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<RoomDetails> roomlist = new ArrayList<RoomDetails>();
		String query = "SELECT ROOM_ID, ROOM_NO, ROOM_TYPE, PER_NIGHT_RATE, AVAILABILITY FROM ROOM_DETAILS";
		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			rs = stmt.executeQuery();
			while (rs.next()) {
				RoomDetails room = new RoomDetails();
				room.setRoom_id(rs.getString("ROOM_ID"));
				room.setRoom_no(rs.getString("ROOM_NO"));
				room.setRoom_type(rs.getString("ROOM_TYPE"));
				room.setPer_night_rate(rs.getInt("PER_NIGHT_RATE"));
				room.setAvailability(rs.getInt("AVAILABILITY"));

				roomlist.add(room);

			}
			return roomlist;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BookingException("Unable to display room details!!");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new BookingException(" JDBC connection closing failed!!");
			}
		}

	}

	@Override
	public List<Hotel> showAllHotel() throws BookingException {
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<Hotel> hlist = new ArrayList<Hotel>();
		String query = "SELECT HOTEL_NAME, CITY, ADDRESS, AVG_RATE_PER_NIGHT, PHONE_NO1, PHONENO2, RATING, EMAIL, FAX FROM HOTEL";

		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			rs = stmt.executeQuery();
			while (rs.next()) {
				Hotel h1 = new Hotel();
				h1.setHotel_name(rs.getString(""));
				h1.setCity(rs.getString("CITY"));
				h1.setAddress(rs.getString("ADDRESS"));
				h1.setAvg_rate_per_night(rs.getInt("AVG_RATE_PER_NIGHT"));
				h1.setPhone_no1(rs.getString("PHONE_NO1"));
				h1.setPhone_no2(rs.getString("PHONE_NO2"));
				h1.setRating(Integer.parseInt(rs.getString("RATING")));
				h1.setEmail(rs.getString("EMAIL"));
				h1.setFax(rs.getString("FAX"));

				hlist.add(h1);
				return hlist;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BookingException("Unable to display hotel details!!");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new BookingException(" JDBC connection closing failed!!");
			}
		}
		return hlist;

	}

	@Override
	public String isUserAuthenticated(String userName, String password)
			throws BookingException {
		// to authenticate user
		Users user = getUserDetails(userName);
		if (password.equals(user.getPassword())) {
			System.out.println(user.getRole());
			return user.getRole();
		} else {
			return null;
		}
	}

	@Override
	public Users getUserDetails(String userName) throws BookingException {
		// To get password and role from database
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String query = "SELECT PASSWORD, ROLE FROM USERS WHERE USERNAME=?";
		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			stmt.setString(1, userName);

			rs = stmt.executeQuery();

			if (rs.next()) {
				Users user = new Users();
				user.setPassword(rs.getString("PASSWORD"));
				user.setRole(rs.getString("ROLE"));

				System.out.println(user);
				return user;
			} else {
				throw new BookingException("User Name Wrong!!");
			}
		} catch (SQLException e) {
			throw new BookingException("JDBC failed", e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new BookingException(" JDBC connection closing failed!!");
			}
		}
	}

	@Override
	public int AddHotel(Hotel hotel) throws BookingException {
		Connection connect = null;
		PreparedStatement pstm = null;
		int msg = 0;
		int hid = getHotelId();
		String query = "INSERT INTO HOTEL VALUES(?,?,?,?,?,?,?,?,?,?,?)";

		try {
			connect = DBUtil.obtainConnection();
			pstm = connect.prepareStatement(query);

			pstm.setInt(1, hid);
			pstm.setString(2, hotel.getCity());
			pstm.setString(3, hotel.getHotel_name());
			pstm.setString(4, hotel.getAddress());
			pstm.setString(5, hotel.getDescription());
			pstm.setInt(6, hotel.getAvg_rate_per_night());
			pstm.setString(7, hotel.getPhone_no1());
			pstm.setString(8, hotel.getPhone_no2());
			pstm.setInt(9, hotel.getRating());
			pstm.setString(10, hotel.getEmail());
			pstm.setString(11, hotel.getFax());
			int status = pstm.executeUpdate();
			if (status > 0) {
				msg = hid;
			} else {
				System.out.println("failed insertion");
			}
		} catch (SQLException e) {
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new BookingException(" JDBC connection closing failed!!");
			}
		}

		return msg;
	}

	@Override
	public boolean deleteHotel(String hotel_id) throws BookingException {
		Connection conn = null;
		PreparedStatement pstm = null;

		String Query = "delete from hotel where hotel_id=?";
		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			pstm.setString(1, hotel_id);

			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			} else {
				return false;
			}

		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			throw new BookingException("problem in delete", e);
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

	@Override
	public boolean updateHotel(Hotel hotel) {
		Connection conn = null;
		PreparedStatement pstm = null;

		String Query = "update Hotel set city=?,hotel_name=?,address=?,description=?,avg_rate_per_night=?,rating=?,email=?,fax=? where hotel_id=?";

		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			pstm.setString(1, hotel.getCity());
			pstm.setString(2, hotel.getHotel_name());
			pstm.setString(3, hotel.getAddress());
			pstm.setString(4, hotel.getDescription());
			pstm.setInt(5, hotel.getAvg_rate_per_night());
			pstm.setInt(6, hotel.getRating());
			pstm.setString(7, hotel.getEmail());
			pstm.setString(8, hotel.getFax());
			pstm.setString(9, hotel.getHotel_id());
			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			} else {
				return false;
			}

		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			try {
				throw new BookingException("problem in update");
			} catch (BookingException e1) {

				e1.printStackTrace();
			}
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	@Override
	public boolean updateRoom(RoomDetails room) throws BookingException {
		Connection conn = null;
		PreparedStatement pstm = null;

		String Query = "update RoomDetails set room_type=?,per_night_rate=?,availability=? where hotel_id=?";

		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			pstm.setString(1, room.getRoom_type());
			pstm.setInt(2, room.getPer_night_rate());
			pstm.setInt(3, room.getAvailability());

			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			} else {
				return false;
			}

		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			try {
				throw new BookingException("problem in update");
			} catch (BookingException e1) {

				e1.printStackTrace();
			}
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	// insert booking details
	@Override
	public int addbook(BookingDetails book) throws BookingException {
		int bId = getBookingId();
		Connection conn = null;
		PreparedStatement pstm = null;
		int msg = 0;
		String rid = book.getRoom_id();
		String query = "INSERT INTO bookingdetails VALUES(?,?,?,?,?,?,?,?)";

		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, bId);
			pstm.setString(2, book.getBooking_id());
			pstm.setString(3, book.getRoom_id());
			pstm.setDate(4, (Date) book.getBooked_from());
			pstm.setDate(5, (Date) book.getBooked_to());
			pstm.setInt(6, book.getNo_of_adults());
			pstm.setInt(7, book.getNo_of_children());
			pstm.setInt(8, book.getAmount());
			int status = pstm.executeUpdate();
			if (status == 1) {
				// update roomdetails table and return booking id
				if (changeRoomAvailability(rid)) {
					System.out.println("Room availability chnaged..!!");
					msg = bId; // return booking id
				} else {
					throw new BookingException("problem in updation");
				}
			} else {
				throw new BookingException("problem in booking..!!");
			}
		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			throw new BookingException("problem in insert");
		} finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		System.out.println(msg);

		return msg;
	}

	private boolean changeRoomAvailability(String rid) {
		Connection conn = null;
		PreparedStatement pstm = null;

		String Query = "update RoomDetails set availability=1 where room_id=?";

		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			pstm.setString(1, rid);
			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			} else {
				return false;
			}

		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			try {
				throw new BookingException("problem in update");
			} catch (BookingException e1) {

				e1.printStackTrace();
			}
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	// generate unique booking id
	private int getBookingId() {
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int bId = 0;
		String query = "SELECT seq_booking_Id.NEXTVAL from dual";
		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			rs = stmt.executeQuery();

			if (rs.next()) {
				bId = rs.getInt(1);
			}
		} catch (BookingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return bId;

	}

	public int getHotelId() {
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int hotelId = 0;
		String query = "SELECT seq_hotel_Id.NEXTVAL from dual";
		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			rs = stmt.executeQuery();

			if (rs.next()) {
				hotelId = rs.getInt(1);
			}
		} catch (BookingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return hotelId;

	}

	@Override
	public List<BookingDetails> ViewBookingHistory(String user_id)
			throws BookingException {
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<BookingDetails> blist = new ArrayList<BookingDetails>();
		String query = "SELECT BOOKING_ID, ROOM_ID, BOOKED_FROM, BOOKED_TO, NO_OF_ADULTS, NO_OF_CHILDREN, AMOUNT FROM BOOKING_DETAILS";
		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			rs = stmt.executeQuery();
			while (rs.next()) {
				BookingDetails bdetail = new BookingDetails();
				bdetail.setBooking_id(rs.getString("BOOKING_ID"));
				bdetail.setRoom_id(rs.getString("ROOM_ID"));
				bdetail.setBooked_from(rs.getDate("BOOKED_FROM"));
				bdetail.setBooked_to(rs.getDate("BOOKED_TO"));
				bdetail.setNo_of_adults(rs.getInt("NO_OF_ADULTS"));
				bdetail.setNo_of_children(rs.getInt("NO_OF_CHILDREN"));
				bdetail.setAmount(rs.getInt("AMOUNT"));

				blist.add(bdetail);
				return blist;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BookingException("Unable to display room details!!");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new BookingException(" JDBC connection closing failed!!");
			}
		}
		return null;
	}

	/*
	 * @Override public String cancelBooking(String booking_id) throws
	 * BookingException { Connection conn = null; PreparedStatement pstm = null;
	 * String roomid = getRoomId(booking_id); String Query =
	 * "delete from BOOKING_DETAILS where BOOKING_ID=?"; try { conn =
	 * DBUtil.obtainConnection(); pstm = conn.prepareStatement(Query);
	 * pstm.setString(1, booking_id);
	 * 
	 * int i = pstm.executeUpdate(); if (i == 1) { //if delete successful then
	 * make that room available } else { return false; }
	 * 
	 * return null; }
	 * 
	 * }
	 * 
	 * private String[] getRoomId(String booking_id) { Connection connect =
	 * null; PreparedStatement stmt = null; ResultSet rs = null;
	 * List<RoomDetails> roomlist = new ArrayList<RoomDetails>(); String query =
	 * "SELECT ROOM_ID FROM BOOKING_DETAILS WHERE BOOKING_ID=?"; try { connect =
	 * DBUtil.obtainConnection(); stmt = connect.prepareStatement(query);
	 * stmt.setString(1, booking_id);
	 * 
	 * rs = stmt.executeQuery(); while (rs.next()) { Room r = List<RoomDetails>
	 * =rs.getArray("ROOM_ID");
	 * 
	 * }return roomlist; } catch (SQLException e) { e.printStackTrace(); throw
	 * new BookingException("Unable to display room details!!"); }finally { try
	 * { if (rs != null) { rs.close(); } if (stmt != null) { stmt.close(); } if
	 * (connect != null) { connect.close(); } } catch (SQLException e) { throw
	 * new BookingException(" JDBC connection closing failed!!"); } }
	 * 
	 * }
	 */
}
