package com.cg.appl.junit;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.appl.daos.HotelDaoImpl;
import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;

public class TestHotelDaoUpdate {
	
	HotelDaoImpl h;
	Hotel hotelBean;
	BookingDetails book;
	RoomDetails room;
	Users user;

	@Before
	public void setUp() throws Exception {
    	 h=new HotelDaoImpl();
    	 hotelBean=new Hotel();
    	 user= new Users();
	}

	@After
	public void tearDown() throws Exception {
	h=null;
	hotelBean=null;
	book=null;
	user=null;
	room=null;
	
	}
	

	@Test
	public void testupdateRoom()  throws BookingException{
		
		try {
			assertTrue(h.updateRoom(room));
		   } catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testupdateHotel() throws BookingException {
		
		try {
			assertTrue(h.updateHotel(hotelBean));
		   } catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void testmakeRoomUnAvailable() throws BookingException {
		
		try {
			String rid = "F10A";
			assertTrue(h.makeRoomUnAvailable(rid));
		   } catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

}
