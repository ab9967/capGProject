package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.exception.BookingException;
import com.cg.appl.util.DBUtil;

public class BookingDaoImpl implements IBookingDao {

	@Override
	public List<Hotel> showAllHotel() throws BookingException {
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<Hotel> hlist = new ArrayList<Hotel>();
		String query = "SELECT * FROM HOTEL";
		
		
		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			rs = stmt.executeQuery();
			while (rs.next()) {
				Hotel h1 = new Hotel();
				h1.setHotel_id(rs.getString("hotel_id"));
				h1.setHotel_name(rs.getString("hotel_name"));
				//System.out.println(rs.getString("hotel_name"));
				h1.setCity(rs.getString("city"));
				h1.setAddress(rs.getString("ADDRESS"));
				h1.setDescription(rs.getString("description"));
				h1.setAvg_rate_per_night(rs.getInt("AVG_RATE_PER_NIGHT"));
				h1.setPhone_no1(rs.getString("PHONE_NO1"));
				h1.setPhone_no2(rs.getString("PHONE_NO2"));
				h1.setRating(Integer.parseInt(rs.getString("RATING")));
				h1.setEmail(rs.getString("EMAIL"));
				h1.setFax(rs.getString("FAX"));
				
				hlist.add(h1);
				System.out.println(hlist);
			}
			
			return hlist;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BookingException("Unable to display hotel details!!");
		}finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new BookingException(" JDBC connection closing failed!!");
			}
		}
		
	}
	
	@Override
	public Hotel getHotel(String hotelID) throws BookingException {
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Hotel h1 = new Hotel();
		String query = "SELECT * FROM HOTEL where hotel_id=?";
		
		
		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			stmt.setString(1,hotelID);
			rs = stmt.executeQuery();
			if(rs.next()) {
				
				h1.setHotel_id(rs.getString("hotel_id"));
				h1.setHotel_name(rs.getString("hotel_name"));
				//System.out.println(rs.getString("hotel_name"));
				h1.setCity(rs.getString("city"));
				h1.setAddress(rs.getString("ADDRESS"));
				h1.setDescription(rs.getString("description"));
				h1.setAvg_rate_per_night(rs.getInt("AVG_RATE_PER_NIGHT"));
				h1.setPhone_no1(rs.getString("PHONE_NO1"));
				h1.setPhone_no2(rs.getString("PHONE_NO2"));
				h1.setRating(Integer.parseInt(rs.getString("RATING")));
				h1.setEmail(rs.getString("EMAIL"));
				h1.setFax(rs.getString("FAX"));
			}
			
			return h1;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BookingException("Unable to display hotel details!!");
		}finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new BookingException(" JDBC connection closing failed!!");
			}
		}
		
	}
	

	@Override
	public boolean updateRoom(RoomDetails room) throws BookingException {
		Connection conn = null;
		PreparedStatement pstm = null;

		String Query = "update RoomDetails set room_type=?,per_night_rate=?,availability=? where hotel_id=?";

		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			pstm.setString(1,room.getRoom_type());
			pstm.setInt(2,room.getPer_night_rate());
			pstm.setInt(3,room.getAvailability());
			
			
			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			} else {
				return false;
			}

		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			try {
				throw new BookingException("problem in update");
			} catch (BookingException e1) {

				e1.printStackTrace();
			}
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	@Override
	public int addbook(BookingDetails book) throws BookingException {
		int bId = getBookingId();
		Connection conn = null;
		PreparedStatement pstm = null;
		int msg = 0;
		String query = "INSERT INTO bookingdetails VALUES(?,?,?,?,?,?,?,?)";

		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, bId);
			pstm.setString(2, book.getBooking_id());
			pstm.setString(3, book.getRoom_id());
			pstm.setDate(4, (Date)book.getBooked_from());
			pstm.setDate(5, (Date)book.getBooked_to());
			pstm.setInt(6, book.getNo_of_adults());
			pstm.setInt(7, book.getNo_of_children());
			pstm.setInt(8, book.getAmount());
			int status = pstm.executeUpdate();
			if (status == 1) {
				msg = bId;
			}
		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			throw new BookingException("problem in insert");
		} finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		System.out.println(msg);

		return msg;
	}

	private int getBookingId() {
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int bId=0;
		String query = "SELECT seq_booking_Id.NEXTVAL from dual";
		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			rs = stmt.executeQuery();
			
			if (rs.next()) {
				bId = rs.getInt(1);
			} 
		} catch (BookingException |SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return bId;
	
	}
	
	
}
