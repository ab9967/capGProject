package com.cg.appl.daos;


import java.util.List;

import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.exception.BookingException;

public interface IHotelDao {
	
	boolean isUserAuthenticated(String userName, String password) throws BookingException;
	
	String getUserDetails(String userName) throws BookingException;
	
	int AddHotel(Hotel hotel) throws BookingException;
	boolean deleteHotel(String hotel_id) throws BookingException;
	boolean updateHotel(Hotel hotel) throws BookingException;
	String addbook(BookingDetails book) throws BookingException;
	List<RoomDetails> showAllRooms(String hotel_id) throws BookingException;
	public List<RoomDetails> checkAvailability(String hotelId)  throws BookingException;
}
