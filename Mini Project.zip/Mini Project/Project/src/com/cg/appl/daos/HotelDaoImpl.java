package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;
import com.cg.appl.util.DBUtil;

public class HotelDaoImpl implements IHotelDao {
	private DBUtil util;

	public HotelDaoImpl() {
		util = new DBUtil();
	}

	@Override
	public boolean isUserAuthenticated(String userName, String password) throws BookingException {
		// to authenticate user
		Users user = new Users();
		user.setUser_name(userName);
		user.setPassword(password);
		String dbpass = getUserDetails(userName);
		System.out.println(dbpass);
		System.out.println(user.getPassword());
		System.out.println(dbpass.equals(user.getPassword()));
		if (dbpass.equals(user.getPassword())) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public String getUserDetails(String userName) throws BookingException {
		// To get password from database
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String query = "SELECT PASSWORD FROM USERS WHERE USER_NAME=?";
		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			stmt.setString(1, userName);

			rs = stmt.executeQuery();

			if (rs.next()) {
				String password = rs.getString("PASSWORD");
				System.out.println(password);
				return password;
			} else {
				throw new BookingException("User Name Wrong!!");
			}
		} catch (SQLException e) {
			throw new BookingException("Jndi failed", e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new BookingException(" Jndi connection closing failed!!");
			}
		}
	}

	@Override
	public List<RoomDetails> checkAvailability(String hotelId)  throws BookingException {
		Connection con=DBUtil.obtainConnection();
		PreparedStatement pst=null;
		List<RoomDetails> roomList=new ArrayList<RoomDetails>();
		String query="SELECT * FROM ROOM_DETAILS WHERE AVAILABILITY=1 AND HOTEL_ID=?";
		try {
			pst=con.prepareStatement(query);
			pst.setString(1,hotelId);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				RoomDetails room=new RoomDetails();
				room.setRoom_id(rs.getString("room_id"));
				room.setRoom_type(rs.getString("room_type"));
				room.setPer_night_rate(rs.getInt("per_night_rate"));
				room.setRoom_no(rs.getString("room_no"));
				roomList.add(room);
			}
		} catch (SQLException e) {
			throw new BookingException("checkAvailability failed!!",e);
		}
		return roomList;
		}
	
	@Override
	public int AddHotel(Hotel hotel) throws BookingException {
		Connection connect = null;
		PreparedStatement pstm = null;
		int msg=0;
		int hid = getHotelId();
		String query = "INSERT INTO HOTEL VALUES(?,?,?,?,?,?,?,?,?,?,?)";

		try {
			connect = DBUtil.obtainConnection();
			pstm = connect.prepareStatement(query);
			
			pstm.setInt(1,hid);
			pstm.setString(2, hotel.getCity());
			pstm.setString(3, hotel.getHotel_name());
			pstm.setString(4, hotel.getAddress());
			pstm.setString(5, hotel.getDescription());
			pstm.setInt(6, hotel.getAvg_rate_per_night());
			pstm.setString(7, hotel.getPhone_no1());
			pstm.setString(8, hotel.getPhone_no2());
			pstm.setInt(9, hotel.getRating());
			pstm.setString(10, hotel.getEmail());
			pstm.setString(11, hotel.getFax());
			int status = pstm.executeUpdate();
			if(status > 0 ){
				msg = hid;
			}else{
				System.out.println("failed insertion");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return msg;
	}


	@Override
	public boolean deleteHotel(String hotel_id) throws BookingException {
		Connection conn = null;
		PreparedStatement pstm = null;

		String Query = "delete from hotel where hotel_id=?";
		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			pstm.setString(1, hotel_id);

			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			} else {
				return false;
			}

		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			try {
				throw new BookingException("problem in delete", e);
			} catch (BookingException e1) {

				e1.printStackTrace();
			}
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		}

		return false;
	}

	@Override
	public boolean updateHotel(Hotel hotel) {
		Connection conn = null;
		PreparedStatement pstm = null;

		String Query = "update Hotel set hotel_name=?,avg_rate_per_night=?,phone_no1=?,phone_no2=?,rating=?,email=?,fax=? where hotel_id=?";

		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			pstm.setString(1, hotel.getHotel_name());
			pstm.setInt(2, hotel.getAvg_rate_per_night());
			pstm.setString(3, hotel.getPhone_no1());
			pstm.setString(4, hotel.getPhone_no2());
			pstm.setInt(5, hotel.getRating());
			pstm.setString(6, hotel.getEmail());
			pstm.setString(7, hotel.getFax());
			System.out.println(hotel.getFax());
			pstm.setString(8, hotel.getHotel_id());
			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			} else {
				return false;
			}

		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			try {
				throw new BookingException("problem in update");
			} catch (BookingException e1) {

				e1.printStackTrace();
			}
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return false;
	}
	public int getHotelId(){
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int hotelId=0;
		String query = "SELECT seq_hotel_Id.NEXTVAL from dual";
		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			rs = stmt.executeQuery();
			
			if (rs.next()) {
				hotelId = rs.getInt(1);
			} 
		} catch (BookingException |SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return hotelId;
	
	}
	// insert booking details
		@Override
		public String addbook(BookingDetails book) throws BookingException {
			String bId = getBookingId();
			
			book.setBooking_id(bId);
			
			Connection conn = null;
			PreparedStatement pstm = null;
			String rid = book.getRoom_id();
			String query = "INSERT INTO booking_details VALUES(?,?,?,?,?,?,?,?)";

			try {
				conn = DBUtil.obtainConnection();
				pstm = conn.prepareStatement(query);
				pstm.setString(1, bId);
				pstm.setString(2, book.getRoom_id());
				pstm.setString(3, book.getUser_id());
				
				java.sql.Date date = new java.sql.Date(book.getBooked_from().getTime());
				pstm.setDate(4, date);
				
				date = new java.sql.Date(book.getBooked_to().getTime());
				pstm.setDate(5, date);
				
				pstm.setInt(6, book.getNo_of_adults());
				pstm.setInt(7, book.getNo_of_children());
				pstm.setInt(8, book.getAmount());
				
				int status = pstm.executeUpdate();
				if (status == 1) {
					// update roomdetails table and return booking id
					if (makeRoomUnavailable(rid)) {
						System.out.println("Room availability chnaged..!!");
					} else {
						throw new BookingException("problem in updation");
					}
				} else {
					throw new BookingException("problem in booking..!!");
				}
			} catch (BookingException | SQLException e) {
				e.printStackTrace();
				throw new BookingException("problem in insert",e);
			} finally {
				try {
					pstm.close();
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			System.out.println(bId);

			return bId;
		}
		
		public boolean makeRoomAvailable(String rid) {
			Connection conn = null;
			PreparedStatement pstm = null;

			String Query = "update Room_Details set availability=1 where room_id=?";

			try {
				conn = DBUtil.obtainConnection();
				pstm = conn.prepareStatement(Query);
				pstm.setString(1, rid);
				int i = pstm.executeUpdate();
				if (i == 1) {
					return true;
				} else {
					return false;
				}

			} catch (BookingException | SQLException e) {
				e.printStackTrace();
				try {
					throw new BookingException("problem in update");
				} catch (BookingException e1) {

					e1.printStackTrace();
				}
			} finally {
				if (pstm != null) {
					try {
						pstm.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			return false;
		}
		
		public boolean makeRoomUnavailable(String rid) {
			Connection conn = null;
			PreparedStatement pstm = null;

			String Query = "update Room_Details set availability=0 where room_id=?";

			try {
				conn = DBUtil.obtainConnection();
				pstm = conn.prepareStatement(Query);
				pstm.setString(1, rid);
				int i = pstm.executeUpdate();
				if (i == 1) {
					return true;
				} else {
					return false;
				}

			} catch (BookingException | SQLException e) {
				e.printStackTrace();
				try {
					throw new BookingException("problem in update");
				} catch (BookingException e1) {

					e1.printStackTrace();
				}
			} finally {
				if (pstm != null) {
					try {
						pstm.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			return false;
		}
		
		private String getBookingId() {
			Connection connect = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			Integer bId = 0;
			String query = "SELECT seq_booking_Id.NEXTVAL from dual";
			try {
				connect = DBUtil.obtainConnection();
				stmt = connect.prepareStatement(query);
				rs = stmt.executeQuery();
				
				if (rs.next()) {
					bId = rs.getInt(1);
				} 
			} catch (BookingException |SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return bId.toString();
		
		}
		
		@Override
		public List<RoomDetails> showAllRooms(String hotel_id)
				throws BookingException {
			// show all rooms based on hotel id
			Connection connect = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			List<RoomDetails> roomlist = new ArrayList<RoomDetails>();
			String query = "SELECT ROOM_ID, ROOM_NO, ROOM_TYPE, PER_NIGHT_RATE, AVAILABILITY FROM ROOM_DETAILS";
			try {
				connect = DBUtil.obtainConnection();
				stmt = connect.prepareStatement(query);
				rs = stmt.executeQuery();
				while (rs.next()) {
					RoomDetails room = new RoomDetails();
					room.setRoom_id(rs.getString("ROOM_ID"));
					room.setRoom_no(rs.getString("ROOM_NO"));
					room.setRoom_type(rs.getString("ROOM_TYPE"));
					room.setPer_night_rate(rs.getInt("PER_NIGHT_RATE"));
					room.setAvailability(rs.getInt("AVAILABILITY"));

					roomlist.add(room);

				}
				return roomlist;
			} catch (SQLException e) {
				e.printStackTrace();
				throw new BookingException("Unable to display room details!!");
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (stmt != null) {
						stmt.close();
					}
					if (connect != null) {
						connect.close();
					}
				} catch (SQLException e) {
					throw new BookingException(" JDBC connection closing failed!!");
				}
			}

		}
		

		@Override
		public RoomDetails showRoom(String hotel_id, String room_id)
				throws BookingException {
			Connection connect = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			RoomDetails room = new RoomDetails();
			String query = "SELECT ROOM_ID, ROOM_NO, ROOM_TYPE, PER_NIGHT_RATE, AVAILABILITY FROM ROOM_DETAILS where hotel_id=? and room_id=?";
			try {
				connect = DBUtil.obtainConnection();
				stmt = connect.prepareStatement(query);
				stmt.setString(1, hotel_id);
				stmt.setString(2, room_id);
				rs = stmt.executeQuery();
				if (rs.next()) {
					
					room.setRoom_id(rs.getString("ROOM_ID"));
					room.setRoom_no(rs.getString("ROOM_NO"));
					room.setRoom_type(rs.getString("ROOM_TYPE"));
					room.setPer_night_rate(rs.getInt("PER_NIGHT_RATE"));
					room.setAvailability(rs.getInt("AVAILABILITY"));
				}
				return room;
			} catch (SQLException e) {
				e.printStackTrace();
				throw new BookingException("Unable to display room details!!");
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (stmt != null) {
						stmt.close();
					}
					if (connect != null) {
						connect.close();
					}
				} catch (SQLException e) {
					throw new BookingException(" JDBC connection closing failed!!");
				}
			}

		}
		
		@Override
		public List<Hotel> GetHotelNames() throws BookingException {
			Connection connect = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			List<Hotel> hlist = new ArrayList<Hotel>();
			String query = "SELECT HOTEL_NAME FROM HOTEL";

			try {
				connect = DBUtil.obtainConnection();
				stmt = connect.prepareStatement(query);
				rs = stmt.executeQuery();
				while (rs.next()) {
					Hotel h1 = new Hotel();
					h1.setHotel_name(rs.getString(""));
					
					hlist.add(h1);
					return hlist;
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new BookingException("Unable to display hotelnames!!");
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (stmt != null) {
						stmt.close();
					}
					if (connect != null) {
						connect.close();
					}
				} catch (SQLException e) {
					throw new BookingException(" JDBC connection closing failed!!");
				}
			}
			return hlist;
		
			
		}
		@Override
		public String GetHotelName(String hotelID) throws BookingException {
			Connection connect = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			String query = "SELECT HOTEL_NAME FROM HOTEL where hotel_id=?";

			String hotelName;
			
			try {
				connect = DBUtil.obtainConnection();
				stmt = connect.prepareStatement(query);
				stmt.setString(1,hotelID);
				rs = stmt.executeQuery();
				if(rs.next()) {
					
					hotelName = rs.getString("hotel_name");
					return hotelName;
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new BookingException("Unable to display hotelnames!!");
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (stmt != null) {
						stmt.close();
					}
					if (connect != null) {
						connect.close();
					}
				} catch (SQLException e) {
					throw new BookingException(" JDBC connection closing failed!!");
				}
			}
			return null;			
		}
		
		@Override
		public String addRoom(RoomDetails room) throws BookingException {
			String room_id = getroomid();
			Connection conn = null;
			PreparedStatement pstm = null;
			String msg = null;
			String query = "INSERT INTO Room_Details VALUES(?,?,?,?,?,?,?)";

			try {
				conn = DBUtil.obtainConnection();
				pstm = conn.prepareStatement(query);
				pstm.setString(1,room.getHotel_id() );
				pstm.setString(2,room_id );
				pstm.setString(3, room.getRoom_no());
				pstm.setString(4, room.getRoom_type());
				pstm.setInt(5, room.getPer_night_rate());
				pstm.setInt(6,room.getAvailability());
				pstm.setString(7, room.getPhoto());
				int status = pstm.executeUpdate();
				if (status == 1) {
					msg = room_id;
				}
			} catch (BookingException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new BookingException("problem in insert");
			} finally {
				try {
					pstm.close();
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			System.out.println(msg);

			return msg;
			
		}
		
		public String getroomid() throws BookingException {
			String room_id  = null;
			Connection conn = null;
			PreparedStatement pstm = null;
			String Query = "select room_id_seq.nextval from dual";
			try {
				conn = DBUtil.obtainConnection();
				pstm = conn.prepareStatement(Query);
				ResultSet rs = pstm.executeQuery();
				while (rs.next()) {
					room_id = rs.getString(1);
				}
			} catch (BookingException | SQLException e) {
				e.printStackTrace();
				throw new BookingException("problem in insert");
			} finally {
				try {
					pstm.close();
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return room_id;

		}

		@Override
		public boolean deleterooms(String room_id) throws BookingException {
			Connection conn = null;
			PreparedStatement pstm = null;

			String Query = "delete from room_details where room_id=?";
			try {
				conn = DBUtil.obtainConnection();
				pstm = conn.prepareStatement(Query);
				pstm.setString(1, room_id);

				int i = pstm.executeUpdate();
				if (i == 1) {
					return true;
				} else {
					return false;
				}

			} catch (BookingException | SQLException e) {
				e.printStackTrace();
				try {
					throw new BookingException("problem in delete", e);
				} catch (BookingException e1) {

					e1.printStackTrace();
				}
			} finally {
				if (pstm != null) {
					try {
						pstm.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}

			return false;
			
		}
		
		@Override
		public boolean updateRoom(RoomDetails room) throws BookingException {
			Connection conn = null;
			PreparedStatement pstm = null;

			String Query = "update Room_Details set room_type=?,per_night_rate=?,availability=? where hotel_id=?";

			try {
				conn = DBUtil.obtainConnection();
				pstm = conn.prepareStatement(Query);
				pstm.setString(1, room.getRoom_type());
				pstm.setInt(2, room.getPer_night_rate());
				pstm.setInt(3, room.getAvailability());

				int i = pstm.executeUpdate();
				if (i == 1) {
					return true;
				} else {
					return false;
				}

			} catch (BookingException | SQLException e) {
				e.printStackTrace();
				try {
					throw new BookingException("problem in update");
				} catch (BookingException e1) {

					e1.printStackTrace();
				}
			} finally {
				if (pstm != null) {
					try {
						pstm.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			return false;
		}

		@Override
		public List<BookingDetails> viewHotelwiseBooking(String hotel_id) throws BookingException {
			// View Hotel wise booking details based on hotel id
			Connection connect = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			List<BookingDetails> blist = new ArrayList<BookingDetails>();
			String query = "SELECT BOOKING_ID, ROOM_ID, USER_ID, BOOKED_FROM, BOOKED_TO, NO_OF_ADULTS, NO_OF_CHILDREN, AMOUNT from booking_details where room_id IN (select room_id from room_details where hotel_id=?)";
			try {
				connect = DBUtil.obtainConnection();
				stmt = connect.prepareStatement(query);
				stmt.setString(1, hotel_id);
				rs = stmt.executeQuery();
				while (rs.next()) {
					BookingDetails bdetail = new BookingDetails();
					bdetail.setBooking_id(rs.getString("BOOKING_ID"));
					bdetail.setRoom_id(rs.getString("ROOM_ID"));
					bdetail.setUser_id(rs.getString("USER_ID"));
					bdetail.setBooked_from(rs.getDate("BOOKED_FROM"));
					bdetail.setBooked_to(rs.getDate("BOOKED_TO"));
					bdetail.setNo_of_adults(rs.getInt("NO_OF_ADULTS"));
					bdetail.setNo_of_children(rs.getInt("NO_OF_CHILDREN"));
					bdetail.setAmount(rs.getInt("AMOUNT"));

					blist.add(bdetail);
					System.out.println(blist);
					/*
					 * //???????????????????????? is if() required?? String userid =
					 * rs.getString("USER_ID"); String qry =
					 * "SELECT USER_NAME FROM USERS WHERE USER_ID=?"; connect =
					 * DBUtil.obtainConnection(); stmt =
					 * connect.prepareStatement(qry); stmt.setString(1, userid);
					 * ResultSet res = stmt.executeQuery(); if(rs.next()) { String
					 * username = res.getString("USER_NAME"); return username; }
					 */

				}
				return blist;

			} catch (SQLException e) {
				e.printStackTrace();
				throw new BookingException("Unable to display hotel wise booing details !!");
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (stmt != null) {
						stmt.close();
					}
					if (connect != null) {
						connect.close();
					}
				} catch (SQLException e) {
					throw new BookingException(" JDBC connection closing failed!!");
				}
			}

		}
		
		// to view guestList:
				//call viewHotelwiseBooking(String hotel_id) +  viewGuestList(String user_id)
				//user_id from list<bookingDetails>
		@Override
		public Users getUserDetailsForReport(String UserID) throws BookingException {
			// To get password and role from database
			Connection connect = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			String query = "SELECT USER_ID, user_name, PASSWORD, ROLE FROM USERS WHERE user_id=?";
			try {
				connect = DBUtil.obtainConnection();
				stmt = connect.prepareStatement(query);
				stmt.setString(1, UserID);

				rs = stmt.executeQuery();

				if (rs.next()) {
					Users user = new Users();
					user.setUser_id(rs.getString("USER_ID"));
					user.setUser_name("user_name");
					user.setPassword(rs.getString("PASSWORD"));
					user.setRole(rs.getString("ROLE"));

					System.out.println(user);
					return user;
				} else {
					throw new BookingException("User ID Wrong!!");
				}
			} catch (SQLException e) {
				throw new BookingException("JDBC failed", e);
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (stmt != null) {
						stmt.close();
					}
					if (connect != null) {
						connect.close();
					}
				} catch (SQLException e) {
					throw new BookingException(" JDBC connection closing failed!!");
				}
			}
		}
		
		@Override
		public List<BookingDetails> viewBookingDatewise(String fromDate, String toDate) throws BookingException {
			Connection connect = null;
			PreparedStatement stmt = null;
			ResultSet res = null;
			List<BookingDetails> blist = new ArrayList<BookingDetails>();
			
			String qry ="select * from booking_details where booked_from >= TO_DATE('?','dd/mm/yyyy') and booked_to <= TO_DATE('?', 'dd/mm/yyyy')"; 
			try {
			connect=DBUtil.obtainConnection(); 
			stmt = connect.prepareStatement(qry); 
			stmt.setString(1, fromDate);
			stmt.setString(2, toDate);
			res = stmt.executeQuery(); 
			while(res.next()) {
				BookingDetails bdetail = new BookingDetails();
				bdetail.setBooking_id(res.getString("BOOKING_ID"));
				bdetail.setRoom_id(res.getString("ROOM_ID"));
				bdetail.setUser_id(res.getString("USER_ID"));
				bdetail.setBooked_from(res.getDate("BOOKED_FROM"));
				bdetail.setBooked_to(res.getDate("BOOKED_TO"));
				bdetail.setNo_of_adults(res.getInt("NO_OF_ADULTS"));
				bdetail.setNo_of_children(res.getInt("NO_OF_CHILDREN"));
				bdetail.setAmount(res.getInt("AMOUNT"));

				blist.add(bdetail);
				System.out.println(blist);
						
				}
				return blist;
			} catch (SQLException e) {
				e.printStackTrace();
				throw new BookingException("Unable to get user details!!");
			} finally {
				try {
					if (res != null) {
						res.close();
					}
					if (stmt != null) {
						stmt.close();
					}
					if (connect != null) {
						connect.close();
					}
				} catch (SQLException e) {
					throw new BookingException(" JDBC connection closing failed!!");
				}
			}
	}
		
		@Override
		public String addUser(Users user) throws BookingException {
				String user_id = getuserid();
				Connection conn = null;
				PreparedStatement pstm = null;
				String msg = null;
				String role = "n/a";
				String query = "INSERT INTO users VALUES(?,?,?,?,?,?,?,?)";

				try {
					conn = DBUtil.obtainConnection();
					pstm = conn.prepareStatement(query);
					pstm.setString(1, user_id);
					pstm.setString(2, user.getPassword());
					pstm.setString(3,role);
					pstm.setString(4,user.getUser_name());
					pstm.setString(5,user.getMobile_no());
					pstm.setString(6, user.getPhone());
					pstm.setString(7, user.getAddress());
					pstm.setString(8, user.getEmail());
					int status = pstm.executeUpdate();
					if (status == 1) {
						msg = user.getUser_name();
					}
				} catch (BookingException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					throw new BookingException("problem in insert");
				} finally {
					try {
						pstm.close();
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				System.out.println(msg);

				return msg;
				
			}
		public String getuserid() throws BookingException {
			String user_id  = null;
			Connection conn = null;
			PreparedStatement pstm = null;
			String Query = "select user_id_seq.nextval from dual";
			try {
				conn = DBUtil.obtainConnection();
				pstm = conn.prepareStatement(Query);
				ResultSet rs = pstm.executeQuery();
				while (rs.next()) {
					user_id = rs.getString(1);
				}
			} catch (BookingException | SQLException e) {
				e.printStackTrace();
				throw new BookingException("problem in insert");
			} finally {
				try {
					pstm.close();
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return user_id;

		}
		
		/*@Override
		public List<Users> viewGuestList(String user_id) throws BookingException {
			Connection connect = null;
			PreparedStatement stmt = null;
			ResultSet res = null;
			List<Users> userlist = new ArrayList<Users>();
			
			String qry ="SELECT USER_NAME FROM USERS WHERE USER_ID=?"; 
			try {
			connect=DBUtil.obtainConnection(); 
			stmt = connect.prepareStatement(qry); 
			stmt.setString(1, user_id);
			res = stmt.executeQuery(); 
			while(res.next()) {
				Users u = new Users();
				u.setUser_name(res.getString("USER_NAME"));
				userlist.add(u);							
				}
				return userlist;
			} catch (SQLException e) {
				e.printStackTrace();
				throw new BookingException("Unable to get user details!!");
			} finally {
				try {
					if (res != null) {
						res.close();
					}
					if (stmt != null) {
						stmt.close();
					}
					if (connect != null) {
						connect.close();
					}
				} catch (SQLException e) {
					throw new BookingException(" JDBC connection closing failed!!");
				}
			}

		}*/
		
}
