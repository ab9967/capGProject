package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.appl.entities.BookingDetails;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.entities.Users;
import com.cg.appl.exception.BookingException;
import com.cg.appl.util.DBUtil;

public class HotelDaoImpl implements IHotelDao {
	private DBUtil util;

	public HotelDaoImpl() {
		util = new DBUtil();
	}

	@Override
	public boolean isUserAuthenticated(String userName, String password) throws BookingException {
		// to authenticate user
		Users user = new Users();
		user.setUser_name(userName);
		user.setPassword(password);
		String dbpass = getUserDetails(userName);
		System.out.println(dbpass);
		System.out.println(user.getPassword());
		System.out.println(dbpass.equals(user.getPassword()));
		if (dbpass.equals(user.getPassword())) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public String getUserDetails(String userName) throws BookingException {
		// To get password from database
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String query = "SELECT PASSWORD FROM USERS WHERE USER_NAME=?";
		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			stmt.setString(1, userName);

			rs = stmt.executeQuery();

			if (rs.next()) {
				String password = rs.getString("PASSWORD");
				System.out.println(password);
				return password;
			} else {
				throw new BookingException("User Name Wrong!!");
			}
		} catch (SQLException e) {
			throw new BookingException("Jndi failed", e);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (connect != null) {
					connect.close();
				}
			} catch (SQLException e) {
				throw new BookingException(" Jndi connection closing failed!!");
			}
		}
	}

	@Override
	public int AddHotel(Hotel hotel) throws BookingException {
		Connection connect = null;
		PreparedStatement pstm = null;
		int msg=0;
		int hid = getHotelId();
		String query = "INSERT INTO HOTEL VALUES(?,?,?,?,?,?,?,?,?,?,?)";

		try {
			connect = DBUtil.obtainConnection();
			pstm = connect.prepareStatement(query);
			
			pstm.setInt(1,hid);
			pstm.setString(2, hotel.getCity());
			pstm.setString(3, hotel.getHotel_name());
			pstm.setString(4, hotel.getAddress());
			pstm.setString(5, hotel.getDescription());
			pstm.setInt(6, hotel.getAvg_rate_per_night());
			pstm.setString(7, hotel.getPhone_no1());
			pstm.setString(8, hotel.getPhone_no2());
			pstm.setInt(9, hotel.getRating());
			pstm.setString(10, hotel.getEmail());
			pstm.setString(11, hotel.getFax());
			int status = pstm.executeUpdate();
			if(status > 0 ){
				msg = hid;
			}else{
				System.out.println("failed insertion");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return msg;
	}


	@Override
	public boolean deleteHotel(String hotel_id) throws BookingException {
		Connection conn = null;
		PreparedStatement pstm = null;

		String Query = "delete from hotel where hotel_id=?";
		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			pstm.setString(1, hotel_id);

			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			} else {
				return false;
			}

		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			try {
				throw new BookingException("problem in delete", e);
			} catch (BookingException e1) {

				e1.printStackTrace();
			}
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		}

		return false;
	}

	@Override
	public boolean updateHotel(Hotel hotel) {
		Connection conn = null;
		PreparedStatement pstm = null;

		String Query = "update Hotel set hotel_name=?,avg_rate_per_night=?,phone_no1=?,phone_no2=?,rating=?,email=?,fax=? where hotel_id=?";

		try {
			conn = DBUtil.obtainConnection();
			pstm = conn.prepareStatement(Query);
			pstm.setString(1, hotel.getHotel_name());
			pstm.setInt(2, hotel.getAvg_rate_per_night());
			pstm.setString(3, hotel.getPhone_no1());
			pstm.setString(4, hotel.getPhone_no2());
			pstm.setInt(5, hotel.getRating());
			pstm.setString(6, hotel.getEmail());
			pstm.setString(7, hotel.getFax());
			System.out.println(hotel.getFax());
			pstm.setString(8, hotel.getHotel_id());
			int i = pstm.executeUpdate();
			if (i == 1) {
				return true;
			} else {
				return false;
			}

		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			try {
				throw new BookingException("problem in update");
			} catch (BookingException e1) {

				e1.printStackTrace();
			}
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return false;
	}
	public int getHotelId(){
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int hotelId=0;
		String query = "SELECT seq_hotel_Id.NEXTVAL from dual";
		try {
			connect = DBUtil.obtainConnection();
			stmt = connect.prepareStatement(query);
			rs = stmt.executeQuery();
			
			if (rs.next()) {
				hotelId = rs.getInt(1);
			} 
		} catch (BookingException |SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return hotelId;
	
	}
	// insert booking details
		@Override
		public int addbook(BookingDetails book) throws BookingException {
			int bId = getBookingId();
			Connection conn = null;
			PreparedStatement pstm = null;
			int msg = 0;
			String rid = book.getRoom_id();
			String query = "INSERT INTO bookingdetails VALUES(?,?,?,?,?,?,?,?)";

			try {
				conn = DBUtil.obtainConnection();
				pstm = conn.prepareStatement(query);
				pstm.setInt(1, bId);
				pstm.setString(2, book.getBooking_id());
				pstm.setString(3, book.getRoom_id());
				pstm.setDate(4, (Date) book.getBooked_from());
				pstm.setDate(5, (Date) book.getBooked_to());
				pstm.setInt(6, book.getNo_of_adults());
				pstm.setInt(7, book.getNo_of_children());
				pstm.setInt(8, book.getAmount());
				int status = pstm.executeUpdate();
				if (status == 1) {
					// update roomdetails table and return booking id
					if (changeRoomAvailability(rid)) {
						System.out.println("Room availability chnaged..!!");
						msg = bId; // return booking id
					} else {
						throw new BookingException("problem in updation");
					}
				} else {
					throw new BookingException("problem in booking..!!");
				}
			} catch (BookingException | SQLException e) {
				e.printStackTrace();
				throw new BookingException("problem in insert");
			} finally {
				try {
					pstm.close();
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			System.out.println(msg);

			return msg;
		}
		
		private boolean changeRoomAvailability(String rid) {
			Connection conn = null;
			PreparedStatement pstm = null;

			String Query = "update RoomDetails set availability=1 where room_id=?";

			try {
				conn = DBUtil.obtainConnection();
				pstm = conn.prepareStatement(Query);
				pstm.setString(1, rid);
				int i = pstm.executeUpdate();
				if (i == 1) {
					return true;
				} else {
					return false;
				}

			} catch (BookingException | SQLException e) {
				e.printStackTrace();
				try {
					throw new BookingException("problem in update");
				} catch (BookingException e1) {

					e1.printStackTrace();
				}
			} finally {
				if (pstm != null) {
					try {
						pstm.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			return false;
		}
		private int getBookingId() {
			Connection connect = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			int bId=0;
			String query = "SELECT seq_booking_Id.NEXTVAL from dual";
			try {
				connect = DBUtil.obtainConnection();
				stmt = connect.prepareStatement(query);
				rs = stmt.executeQuery();
				
				if (rs.next()) {
					bId = rs.getInt(1);
				} 
			} catch (BookingException |SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return bId;
		
		}
		
		@Override
		public List<RoomDetails> showAllRooms(String hotel_id)
				throws BookingException {
			// show all rooms based on hotel id
			Connection connect = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			List<RoomDetails> roomlist = new ArrayList<RoomDetails>();
			String query = "SELECT ROOM_ID, ROOM_NO, ROOM_TYPE, PER_NIGHT_RATE, AVAILABILITY FROM ROOM_DETAILS";
			try {
				connect = DBUtil.obtainConnection();
				stmt = connect.prepareStatement(query);
				rs = stmt.executeQuery();
				while (rs.next()) {
					RoomDetails room = new RoomDetails();
					room.setRoom_id(rs.getString("ROOM_ID"));
					room.setRoom_no(rs.getString("ROOM_NO"));
					room.setRoom_type(rs.getString("ROOM_TYPE"));
					room.setPer_night_rate(rs.getInt("PER_NIGHT_RATE"));
					room.setAvailability(rs.getInt("AVAILABILITY"));

					roomlist.add(room);

				}
				return roomlist;
			} catch (SQLException e) {
				e.printStackTrace();
				throw new BookingException("Unable to display room details!!");
			} finally {
				try {
					if (rs != null) {
						rs.close();
					}
					if (stmt != null) {
						stmt.close();
					}
					if (connect != null) {
						connect.close();
					}
				} catch (SQLException e) {
					throw new BookingException(" JDBC connection closing failed!!");
				}
			}

		}
		
}
