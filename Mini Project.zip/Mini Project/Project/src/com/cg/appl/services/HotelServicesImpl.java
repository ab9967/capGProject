package com.cg.appl.services;

import java.util.List;

import com.cg.appl.daos.BookingDaoImpl;
import com.cg.appl.daos.HotelDaoImpl;
import com.cg.appl.daos.IBookingDao;
import com.cg.appl.daos.IHotelDao;
import com.cg.appl.entities.Hotel;
import com.cg.appl.entities.RoomDetails;
import com.cg.appl.exception.BookingException;

public class HotelServicesImpl implements IHotelServices{

private IHotelDao dao;
private IBookingDao dao2;
	public HotelServicesImpl(){
		dao = new HotelDaoImpl(); 
		dao2 = new BookingDaoImpl();
	}
	/*@Override
	public List<Hotel> showAllHotel() throws BookingException {
		return dao.showAllHotel();
	}*/

	@Override
	public boolean isUserAuthenticated(String userName, String password)
			throws BookingException {
		return dao.isUserAuthenticated(userName, password);
	}
	@Override
	public boolean deleteHotel(String hotel_id) throws BookingException {
		return dao.deleteHotel(hotel_id);
	}

	@Override
	public boolean updateHotel(Hotel hotel) throws BookingException {
		return dao.updateHotel(hotel);
	}

	@Override
	public int AddHotel(Hotel hotel) throws BookingException {
		return dao.AddHotel(hotel);
	}

	@Override
	public List<Hotel> showAllHotel() throws BookingException {
		
		return dao2.showAllHotel();
	}

	@Override
	public String getUserDetails(String userName) throws BookingException {
		// TODO Auto-generated method stub
		return dao.getUserDetails(userName);
	}

	@Override
	public List<RoomDetails> showAllRooms(String hotel_id)
			throws BookingException {
		
		return dao.showAllRooms(hotel_id);
	}
	@Override
	public Hotel getHotel(String hotelID) throws BookingException {
		
		return dao2.getHotel(hotelID);
	}
	


}
