public List<RoomDetails> checkAvailability(String hotelId){
Connection con=DBUtil.obtainConnection();
PreparedStatement pst=null;
List<RoomDetails> roomList=new ArrayList<RoomDetails>();
String query="SELECT * FROM ROOM_DETAILS WHERE AVAILABILITY=1 AND HOTEL_ID=?";
pst=con.preparedStatement(query);
pst.setString(1,hotelId);
ResultSet rs=pst.executeQuery();
while(rs.next())
{
	RoomDetails room=new RoomDetails();
	room.setRoom_id(rs.getString(2));
	room.setRoom_type(rs.getString(3);
	room.setPer_night_rate(rs.getString(4));
	roomList.add(room);
}
return roomList;
}